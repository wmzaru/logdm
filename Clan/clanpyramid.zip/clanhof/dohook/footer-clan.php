<?php
addnav("Pyramid");
addnav("Pyramid Kills","runmodule.php?module=clanhof&op=clankills");
addnav("Clan Points","runmodule.php?module=clanhof&op=clanhofc");
addnav("Player Points","runmodule.php?module=clanhof&op=playerhofc");
?>