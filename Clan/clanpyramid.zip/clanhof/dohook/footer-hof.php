<?php
addnav("Warrior Rankings");
addnav("Pyramid Kills", "runmodule.php?module=clanhof&op=clankillhof");
?>