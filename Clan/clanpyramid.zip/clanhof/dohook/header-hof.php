<?php
addnav("Clan Rankings");
addnav("Clan Points", "runmodule.php?module=clanhof&op=clanhof");
addnav("Player Points","runmodule.php?module=clanhof&op=playerhof");
?>