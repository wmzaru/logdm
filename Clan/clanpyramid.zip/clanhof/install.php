<?php
module_addhook("header-hof");
module_addhook("footer-hof");
module_addhook("footer-clan");
return true;
?>