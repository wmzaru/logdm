<?php
$fightnum=httpget('f');
$wall=httpget('w');
$p=httpget('p');
array("script","&p=$p&w=$wall&f=$fightnum");

?>