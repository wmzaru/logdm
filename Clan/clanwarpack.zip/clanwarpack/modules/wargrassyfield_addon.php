<?php
/*
Details:
 * This is a module that uses the clanwar.php module
 * Allows you to attack someone in the grassyfield module
History Log:
 v1.0:
 o Stable
 v1.2:
 o Now uses the proper badguy method
*/
require_once('modules/clanwar.php');
require_once("lib/fightnav.php");
require_once("lib/http.php");
require_once("lib/taunt.php");

function wargrassyfield_addon_getmoduleinfo(){
	$info = array(
		"name"=>"Grassy Field - Addon",
		"version"=>"1.2",
		"author"=>"`@CortalUX",
		"category"=>"Clanwar",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"download"=>"http://dragonprime.net/users/CortalUX/clanwarpack.zip",
		"settings"=>array(
			"Grassy Field Settings - Clanwar,title",
			"(choose how many points you want an action to increment your points by),note",
			"(set it to 0 for nothing to happen),note",
			"snkp"=>"Attacking the clan opponent and winning?,int|0", 
			"(and if you let users lose points in your war.. how much should they lose..),note",
			"atkdie"=>"Attacking the clan opponent and dying?,int|0", 
			"atkrunf"=>"Attacking the clan opponent and running- FAIL?,int|0", 
			"atkruns"=>"Attacking the clan opponent and running- SUCCEED?,int|0", 
		),
		"prefs"=>array(
			"Clan War - Grassy Field Addon,title",
			"hasfight"=>"Has fought clanmember today?,bool|0",
		),
		"prefs-clans"=>array(
			"Clan War - Sneak Points,title",
			"snkp"=>"Sneak points?,int|0",
		),
		"requires"=>array(
			"clanwar" => "1.9|`@CortalUX, http://dragonprime.net/users/CortalUX/clanwarpack.zip",
			"grassyfield" => "1.1|Sean McKillion<br>modified by Eric Stevens & JT Traub, core_module",
		),
	);
	return $info;
}

function wargrassyfield_addon_install(){
	if (!is_module_active('wargrassyfield_addon')){
		output("`n`c`b`QGrassy Field - Addon Module - Installed`0`b`c");
	}else{
		output("`n`c`b`QGrassy Field - Addon Module - Updated`0`b`c");
	}
	module_addhook("clanwar-points");
	module_addhook("footer-forest");
	return true;
}

function wargrassyfield_addon_uninstall(){
	output("`n`c`b`QGrassy Field - Addon Module - Uninstalled`0`b`c");
	return true;
}

function wargrassyfield_addon_dohook($hookname,$args){
	switch ($hookname){
		case "clanwar-points":
			$p = get_module_objpref("clans",$args['clan'],"snkp");
			if (isset($args['Sneak Points'])) {
				$args['Sneak Points']+=$p;
			} else {
				$args['Sneak Points']=$p;
			}
		break;
		case "newday":
			set_module_pref('hasfight',0);
		break;
		case "footer-forest":
			$op = httpget('op');
			if (get_module_setting("warstat","clanwar")==2&&$session['user']['specialinc']=="module:grassyfield") {
				output("`n`@You can see someone from another clanside thar helps with the war... ");
				if (get_module_pref('hasfight')==0) {
					output("get em!");
					addnav("War Options");
					addnav("Attack the infidel!", "runmodule.php?module=wargrassyfield_addon_addon&op=attack");
				} else {
					output("you don't feel like attacking someone else in this field today..");
				}
			}
		break;
	}
	return $args;
}

function wargrassyfield_addon_run() {
	require_once("lib/buffs.php");
	global $session;
	$session['user']['specialinc'] = "";
	$session['user']['specialmisc'] = "";
	$op = httpget('op');
	page_header("Grassy Field WAR!");
	set_module_pref('hasfight',1);
	if ($op=="run"){
		if (e_rand()%3 == 0){
			output ("`c`b`&You have successfully fled your opponent!`0`b`c`n");
			$op="";
			httpset('op', "");
			clanwar_module_pointinc("atkruns","","",false,"`@You ran off!","wargrassyfield_addon");
			$battle=false;
			addnav("Walk off...","forest.php");
		}else{
			output("`c`b`\$You failed to flee your opponent!`0`b`c");
			clanwar_module_pointinc("atkrunf","","",false,"`@You ran off!","wargrassyfield_addon");
			$battle=true;
		}
	} elseif ($op=="attack"){
		$battle=true;
		if (e_rand(0,2)==1){
			$plev = (e_rand(1,5)==1?1:0);
			$nlev = (e_rand(1,3)==1?1:0);
		}else{
			$plev=0;
			$nlev=0;
		}
		$badguy = array();
		$badguy['creaturename']="An evil clanmember";
		$badguy['creatureweapon']="Opposing Views";
		$badguy['creaturelevel']=$session['user']['level'] - 1;
		$badguy['creaturegold']=999;
		$badguy['creatureexp'] =
		round($session['user']['experience']/10, 0);
		$badguy['creaturehealth']=$session['user']['maxhitpoints'] - 2;
		$badguy['creatureattack']=$session['user']['attack'] + 1;
		$badguy['creaturedefense']=$session['user']['defense'] - 1;
		$badguy['expbonus']=
		round($session['user']['experience']/30, 0);
		$session['user']['badguy']=createstring($badguy);
	} elseif ($op=="fight"){
		$battle=true;
	}
	if ($battle){
		include("battle.php");
		if ($victory){
			$denyflawless = false;
			if (getsetting("dropmingold",0)){
					$badguy['creaturegold']=	e_rand(round($badguy['creaturegold']/4),round(3*$badguy['creaturegold']/4));
			}else{
				$badguy['creaturegold']=e_rand(0,$badguy['creaturegold']);
			}
			$expbonus = round(($badguy['creatureexp'] *	 (1 + .25 *		($badguy['creaturelevel']-$session['user']['level']))) -$badguy['creatureexp'],0);
			tlschema("battle");
			$msg = translate_inline($badguy['creaturelose']);
			tlschema();
			output_notl("`b`&%s`0`b`n",$msg);
			output("`b`\$You have slain %s!`0`b`n",$badguy['creaturename']);
			if (is_module_active('alignment')) {
				require_once('modules/alignment.php');
				align("-1");
				output("`n`b`%`cYour alignment has become more `\$EVIL`% for killing someone.`c`n");
			}
			output("`#You receive `^%s`# gold!`n",$badguy['creaturegold']);
			if ($badguy['creaturegold']) {
				debuglog("received gold for slaying a monster.");
			}
			if ($session['user']['level'] < 15 && e_rand(1,25) == 1) {
				output("`&You find A GEM!`n`#");
				$session['user']['gems']++;
				debuglog("found a gem when slaying a monster.");
			}
			if ($expbonus>0){
				output("`#***Because of the difficult nature of this fight, you are awarded an additional `^%s`# experience! `n(%s + %s = %s) ",$expbonus,$badguy['creatureexp'],abs($expbonus),$badguy['creatureexp']+$expbonus);
			}
			output("You receive `^%s`# total experience!`n`0",$badguy['creatureexp']+$expbonus);
			$session['user']['gold']+=$badguy['creaturegold'];
			$session['user']['experience']+=($badguy['creatureexp']+$expbonus);
			$creaturelevel = $badguy['creaturelevel'];
			if ($badguy['diddamage']!=1){
				output("`c`b`&~~ Flawless Fight! ~~`0`b`c");
				if ($session['user']['level']>=getsetting("lowslumlevel",4) || $session['user']['level']<=$creaturelevel){
					output("`c`b`\$You receive an extra turn!`0`b`c`n");
					$session['user']['turns']++;
				}else{
					output("`c`\$A more difficult fight would have yielded an extra turn.`0`c`n");
				}
			}
			if ($session['user']['hitpoints'] <= 0) {
				output("With your dying breath you spy a small stand of mushrooms off to the side.  You recognize them as some of the ones that the healer had drying in the hut and taking a chance, cram a handful into your mouth.  Even raw they have some restorative properties.`n");
				$session['user']['hitpoints'] = 1;
			}
			clanwar_module_pointinc("snkp","","",true,"`@You killed him!","wargrassyfield_addon");
			addnav("Run from this place...", "forest.php");
		}elseif($defeat){
			addnav("Daily News","news.php");
			$taunt = select_taunt_array();
			addnews("`%%s`5 was slain in the Grassy Field fighting someone from another clan.`n%s",$session['user']['name'],$taunt);
			$session['user']['alive']=false;
			debuglog("lost gold when they were slain in the Grassy Field");
			$session['user']['gold']=0;
			$session['user']['hitpoints']=0;
			$session['user']['experience']=round($session['user']['experience']*.9,0);
			$session['user']['badguy']="";
			output("`b`&You have been slain by `%%s`&!!!`n",$badguy['creaturename']);
			output("`4All gold on hand has been lost!`n");
			output("`410% of experience has been lost!`b`n");
			output("You may begin fighting again tomorrow.");
			clanwar_module_pointinc("atkdie","","",false,"`@You died!","wargrassyfield_addon");
		}else{
			fightnav();
		}
	}
	page_footer();
}
?>