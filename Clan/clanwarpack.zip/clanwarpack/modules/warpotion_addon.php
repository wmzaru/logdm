<?php
/*
Details:
 * This allows users to buy war potions to give you points
History Log:
 * Version 1.0
  o Seems Stable
 * Version 1.1
  o Potions can only be bought when a war is on
 * Version 1.2:
  o Textual fix
 * Version 1.3:
  o Now uses the 'potionshop' module
*/
require_once("lib/commentary.php");
require_once("lib/villagenav.php");

function warpotion_addon_getmoduleinfo(){
	$info = array(
		"name"=>"War Potions",
		"version"=>"1.3",
		"author"=>"`@CortalUX",
		"category"=>"Clanwar",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"download"=>"http://dragonprime.net/users/CortalUX/clanwarpack.zip",
		"allowanonymous"=>true,
		"override_forced_nav"=>false,
		"settings"=>array(
			"War Potions - Settings,title",
			"warbuy"=>"Allow users to buy war potions?,bool|1",
			"tLast"=>"Time for potions to last (realtime minutes)?,range,1,120,1|10",
			"pCost"=>"Cost of war potions?,int|1500",
			"adminPotion"=>"Admin have unlimited access to war potions?,bool|1",
			"(admin are those that can edit users),note",
			"ffReset"=>"Amount of forest fights to lose when your potion wears off?,int|0",
			"minP"=>"Minimum points for war potions to give you?,range,1,120,1|10",
			"maxP"=>"Maximum points for war potions to give you?,range,1,120,1|20",
			"inc"=>"Increase,hidden|0",
		),
		"prefs"=>array(
			"Potions - Preferences,title",
			"warPot"=>"War potions?,int|0",
			"secLast"=>"To last?,int|0",
			"start"=>"Started?,int|0",
			"warPot"=>"Is using a war potion?,bool|0",
		),
		"prefs-clans"=>array(
			"Clan War - Magic Points,title",
			"mgic"=>"Magic points?,int|0",
		),
		"requires"=>array(
			"potionshop"=>"1.0|`@CortalUX, http://dragonprime.net/users/CortalUX/potionshop.zip",
			"clanwar" => "1.9|`@CortalUX, http://dragonprime.net/users/CortalUX/clanwarpack.zip",
		),
	);
	return $info;
}

function warpotion_addon_install(){
	if (!is_module_active('warpotion_addon')) {
		output("`n`Q`b`cInstalling War Potions Module.`c`b`n");
	}else{
		output("`n`Q`b`cUpdating War Potions Module.`c`b`n");
	}
	module_addhook("clanwar-points");
	module_addhook("backpack");
	module_addhook("charstats");
	module_addhook("potionshop-list");
	module_addhook("battle-victory");
	module_addhook("village");
	module_addhook("forest");
	module_addhook("header-inn");
	module_addhook("header-gardens");
	module_addhook("header-gypsy");
	module_addhook("header-healer");
	module_addhook("header-armor");
	module_addhook("header-weapons");
	module_addhook("header-rock");
	module_addhook("header-stables");
	return true;
}

function warpotion_addon_uninstall(){
	output("`n`Q`b`cUninstalling War Potions Module.`c`b`n");
	return true;
}

function warpotion_addon_dohook($hookname,$args){
	global $session,$SCRIPT_NAME;
	switch($hookname){
		case "clanwar-points":
			$p = get_module_objpref("clans",$args['clan'],"mgic");
			if (isset($args['Magic Points'])) {
				$args['Magic Points']+=$p;
			} else {
				$args['Magic Points']=$p;
			}
		break;
		case "backpack":
			if (get_module_pref('check_show','movepotion')&&get_module_setting('warstat','clanwar')==2) {
				if (get_module_pref('warPot')>0) {
					output("`n`^You have `@%s`^ War Potions...`n",get_module_pref('warPot'));
				}
			}
		break;
		case "charstats":
			if (get_module_setting('warstat','clanwar')==2) {
				if (get_module_setting('adminPotion')==1&&$session['user']['superuser']&SU_EDIT_USERS) {
					set_module_pref('warPot',1);
				}
				if (get_module_pref('usPot')==1) {
					addcharstat("Vital Info");
					addcharstat("War Potion Info",warpotion_addon_left());
					$potion="";
				} else {
					if (get_module_pref('warPot')>0) {
						$potion="";
						$c = translate_inline("War potions cannot be used here");
						if (!strstr($SCRIPT_NAME, "village")&&!strstr($SCRIPT_NAME, "forest")&&!strstr($SCRIPT_NAME, "superuser")||$session['user']['specialinc']!=""&&$session['user']['specialmisc']!="") {
							$potion .="<div style='cursor: help;display:compact;' onMouseover=\"ddrivetip('$c', 'ffdf7b')\"; onMouseout=\"hideddrivetip()\">";
							$potion .="<img src=\"./images/warpotion_addon/potionclear.gif\" title=\"$c\" alt=\"$c\" style=\"width:22px; height:24px;\">";
							$potion .="</div>";
						} else {
							$x = get_module_pref('warPot');
							$y = 0;
							$c = translate_inline("Drink the war potion...");
							while ($x>0) {
								$y++;
								$x--;
								$potion.="<a border='0' onMouseover=\"ddrivetip('$c', '94f394')\"; onMouseout=\"hideddrivetip()\" style='border:0;' href=\"runmodule.php?module=warpotion_addon&op=start\"><img src=\"./images/warpotion_addon/potion.gif\" title=\"$c\" alt=\"$c\" style=\"width:22px; height:24px; border:0;\"></a>";
								addnav("","runmodule.php?module=warpotion_addon&op=start");
								if ($y>=3) {
									$y=0;
									$potion.="\n<br/>";
								}
							}
						}
					} else {
						$potion="";
					}
				}
				addcharstat("Click and use Items");
				if ($potion!="") addcharstat("War Potions", $potion);
			}
		break;
		case "potionshop-list":
			if (get_module_setting('warbuy')==1&&get_module_setting('warstat','clanwar')==2) {
				$price = get_module_setting('pCost');
				if ($price<=0) $price = 1;
				$mov=array();
				$mov['gold']=$price;
				$mov['name']=translate_inline("War Potions");
				$mov['avail']=translate_inline("In Stock");
				$mov['nav']=translate_inline("Buy a `QWar`0 Potion");
				$mov['effects']=translate_inline("Gives your war side more `b`\$war`@`b points at the end of a forest fight.");
				$mov['link']="runmodule.php?module=warpotion_addon&op=shop";
				$args[]=$mov;
			}
		break;
		case "battle-victory":
			if (get_module_pref('usPot')==1&&$args['type']=="forest"&&get_module_setting('warstat','clanwar')==2) {
				$am = e_rand(get_module_setting('minP'),get_module_setting('maxP'));
				set_module_setting('inc',$am);
				output("`n`%The anger from your potion gives your warside `^%s`% points..`n",$am);
				clanwar_module_pointinc("inc","","",true,"","warpotion_addon");
			}
		break;
		default:
			if (get_module_pref('usPot')==1&&$session['user']['alive']==1&&get_module_setting('warstat','clanwar')==2) {
				if (warpotion_addon_check()===true) {
					redirect("runmodule.php?module=warpotion_addon&op=end","War Potion Finished");
				}
			}
		break;
	}
	return $args;
}

function warpotion_addon_run(){
	global $session;
	$op = httpget('op');
	switch ($op) {
		case "start":
			page_header("You drink a potion..");
			set_module_pref('usPot',1);
			set_module_pref('warPot',get_module_pref('warPot')-1);
			villagenav();
			$secs = get_module_setting('tLast')*60;
			set_module_pref('secLast',$secs);
			set_module_pref('start',time());
			output("`@Throwing down a potion that enhances your anger... let the masses feel your pain...");
			page_footer();
		break;
		case "shop":
			page_header("Magical Potion Shoppe");
			$price = get_module_setting('pCost');
			if ($price<=0) $price = 1;
			if ($session['user']['gold']>=$price) {
				set_module_pref('warPot',get_module_pref('warPot')+1);
				$session['user']['gold']-=$price;
				output("`@Handing a %s gold to %s, he hands you a potion, `3\"`&This is a war potion. Swallow it within a village, and ye gain %s	to %s war points at the end of each successful battle... for %s outside minutes, ye should know what that is, player of my world... after the %s minutes, ye will be get a bit of damage, not enough teh kill.`3\"",$price,"`#CortalUX`@",get_module_setting('minP'),get_module_setting('maxP'),get_module_setting('tLast'),get_module_setting('tLast'));
			} else {
				output("%s stares at you.`n`3\"`&Ye do not have enough gold!`3\"","`#CortalUX`@");
			}
			modulehook("potionshop-navs");
			page_footer();
		break;
		case "end":
			page_header("Ouch!!!");
			$am=$session['user']['hitpoints']/2;
			if ($am<=0) $am=1;
			$session['user']['hitpoints']=round($am);
			output("`@Your anger dissipates.. your mind that holds the anger is wrenched away, and you lose half your hitpoints... you are home.");
			$x = get_module_setting('ffReset');
			if ($x>0) {
				$session['user']['turns']-=$x;
				if ($session['user']['turns']<=0) $session['user']['turns']=0;
				output("`nSlowed by this, you lose %s turns.",$x);
			}
			set_module_pref('usPot',0);
			villagenav();
			page_footer();
		break;
	}
}

function warpotion_addon_check() {
	$lasts = get_module_pref('secLast');
	$start = get_module_pref('start');
	$time = time();
	$end = $start+$lasts;
	if ($time>=$end) return true; // If it's later than when it should end, return true.
	$time = date("h:i",time());
	$end = date("h:i",get_module_pref('start')+get_module_pref('secLast')); // We don't tell the user the seconds, so we act on the minutes
	if ($time==$end) return true;
	return false;
}

function warpotion_addon_left() {
	$lastm = date("i",get_module_pref('secLast'));
	$lasth = date("g",get_module_pref('secLast'));
	$minutes = translate_inline(" minutes");
	$hours = translate_inline(" hours");
	$minute = translate_inline(" minute");
	$hour = translate_inline(" hour");
	$wordm=$minutes;
	if ($lastm==1) $wordm=$minute;
	$wordh=$hours;
	if ($lasth==1) $wordh=$hour;
	$string="";
	if ($lasth!=0) $string=$lasth.$wordh;
	if ($lasth!=0&&$lastm!=0) $string.=translate_inline(" and");
	if ($lastm!=0) $string.=" ".$lastm.$wordm;
	$start = date("h:i",get_module_pref('start'));
	$time = date("h:i",time());
	$end = date("h:i",get_module_pref('start')+get_module_pref('secLast'));
	$string = translate_inline("`&War Potions last `^").$string.translate_inline(" `&, you took yours at `^").$start.translate_inline("`&, the time is `^").$time.translate_inline("`&, so your anger will end at `^").$end."`&.";
	return $string;
}
?>