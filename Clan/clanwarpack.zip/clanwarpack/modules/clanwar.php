<?php
/*
Details:
 * This is a module for Clan Warfare
 * Set up your settings in the Grotto
 * Wars must be turned on within the Grotto
 * Clans can then align themselves to a cause
History Log:
 v1.0:
 o Stable
 v1.1:
 o Allowed Restrict Houses/Inns
 v1.2:
 o Allowed level-up points
 o Fixed ffights bug
 o Clan alignment uses enum in prefs, to work with module claneditor
 v1.3:
 o Fixed alignment link bug
 v1.4:
 o More functions added for dealing with packs
 v1.5:
 o Fixed visual bugs in the Grotto
 o Aligning works better
 o Listing works
 v1.6:
 o Slight bug fixed
 v1.7:
 o Visual bug fixed
 v1.8:
 o Newday block fixed
 v1.9:
 o Now uses correct pref
 v2.0:
 o MOTDs work better
 v2.1:
 o The 'changesetting' is called to as it should be
 o Users cannot hide in valhalla/darkportal
 o Addnews is now used
*/
require_once("lib/commentary.php");
require_once("lib/systemmail.php");
require_once("lib/villagenav.php");
require_once("lib/superusernav.php");

function clanwar_getmoduleinfo() {
	$info = array(
		"name"=>"Clan War System",
		"author"=>"`@CortalUX",
		"version"=>"2.0",
		"category"=>"Clan",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"download"=>"http://dragonprime.net/users/CortalUX/clanwarpack.zip",
		"override_forced_nav"=>true,
		"settings"=>array(
			"Clan War - Magicmirror Settings,title",
			"magicmirrorEach"=>"If Magic Mirror module is installed- Do the clan sides have their own system?,bool|1",
			"magicmirrorWithoro"=>"If Magic Mirror module is installed- Can anyone with or without the mirror view it?,bool|1",
			"sideoneMsg"=>"What are side one saying for their message?,text|",
			"sidetwoMsg"=>"What are side two saying for their message?,text|",
			"(this won't do anything if the magic mirror module isn't installed),note",
			"Clan War - House Settings,title",
			"housesleep"=>"Can users sleep in houses while a war is on?,bool|0",
			"houseRes"=>"Just restrict those whose clans are aligned?,bool|0",
			"(this won't do anything if the house module isn't installed),note",
			"Clan War - Inn Settings,title",
			"innsleep"=>"Can users sleep in the inn while a war is on?,bool|0",
			"innRes"=>"Just restrict those whose clans are aligned?,bool|0",
			"Clan War - DarkPortal Settings,title",
			"darkuse"=>"Can users use the dark portal while a war is on?,bool|0",
			"darkRes"=>"Just restrict those whose clans are aligned?,bool|0",
			"Clan War - General Settings,title",
			"sideone"=>"Name of clan war side one?,text|",
			"sidetwo"=>"Name of clan war side two?,text|",
			"sideonep"=>"Points in clan war side one?,int|0",
			"sidetwop"=>"Points in clan war side two?,int|0",
			"warstat"=>"What is the status of the war?,hidden|0",
			"archive"=>"Show archive of last war?,bool|0",
			"(you shouldn't show the archive if you haven't had a war),note",
			"(start your war in the superuser area),note",
			"turnCoat"=>"Can clans change sides if they've already chosen one before the war starts?,bool|0",
			"Clan War - Point Settings,title",
			"slose"=>"Does losing something take away points instead?,bool|1",
			"(choose how many points you want each action to increment your points by),note",
			"(set it to 0 for nothing to happen),note",
			"master"=>"Defeating your master?,int|10",
			"ffights"=>"Forest Fights?,int|1",
			"pvp"=>"PVP?,int|100",
			"dk"=>"Dragon Kills?,int|50",
		),
		"prefs-clans"=>array(
			"Clan War - Settings,title",
			"alignto"=>"Align to side?,enum,0,Unaligned,1,Side One,2,Side Two|0",
			"ffights"=>"Forest Fights?,int|0",
			"pvp"=>"PVP?,int|0",
			"dk"=>"Dragon Kills?,int|0",
			"master"=>"Defeating your master?,int|0",
			"slose"=>"Lose points?,int|0",
			"ald"=>"Alive during war?,bool|0",
		),
	);
	return $info;
}


function clanwar_install() {
	module_addhook("changesetting");
	module_addhook("superuser");
	module_addhook("footer-clan");
	module_addhook("newday");
	module_addhook("dragonkill");
	module_addhook("village");
	module_addhook("charstats");
	module_addhook("battle-victory");
	module_addhook("battle-defeat");
	module_addhook("innrooms");
	module_addhook("footer-inn");
	if (!is_module_active('clanwar')){
		output("`n`c`b`QClanwar Module - Installed`0`b`c");
	}else{
		output("`n`c`b`QClanwar Module - Updated`0`b`c");
		if (get_module_setting('warstat')==1) {
			set_module_setting("sideonep",0);
			set_module_setting("sidetwop",0);
		} // Should fix a few bugs with points...
	}
	return true;
}

function clanwar_uninstall() {
	output("`n`c`b`QClanwar Module - Uninstalled`0`b`c");
	return true;
}

function clanwar_dohook($hookname,$args) {
	global $session;
	switch ($hookname) {
		case "changesetting":
			if ($args['setting'] == "housesleep" && $args['module']=="clanwar") {
				$l = "";
				if (get_module_setting('houseRes')==1) $l = ",clanid<>0";
				$sql = "UPDATE " . db_prefix("accounts") . " SET loggedin=0, location='".getsetting("villagename", LOCATION_FIELDS)."',restorepage='village.php' WHERE restorepage LIKE '%runmodule.php?module=house&lo=house%'$l";
				db_query($sql);
				invalidatedatacache("charlisthomepage");
				invalidatedatacache("list.php-warsonline");
			}
			if ($args['setting'] == "innsleep" && $args['module']=="clanwar") {
				$l = "";
				if (get_module_setting('innRes')==1) $l = ",clanid<>0";
				$sql = "UPDATE " . db_prefix("accounts") . " SET loggedin=0, location='".getsetting("villagename", LOCATION_FIELDS)."',restorepage='village.php' WHERE restorepage LIKE '%inn.php?op=strolldown%'$l";
				db_query($sql);
				invalidatedatacache("charlisthomepage");
				invalidatedatacache("list.php-warsonline");
			}
		break;
		case "superuser":
			if ($session['user']['superuser'] & SU_EDIT_USERS) {
				addnav("Module Configurations");
				addnav("Clan War","runmodule.php?module=clanwar&op=list&whence=admin");
			}
		break;
		case "footer-clan":
			if (get_module_setting("warstat")==1) {
				if ($session['user']['clanrank'] == CLAN_LEADER){
					addnav("~");
					$a = get_module_objpref("clans",$session['user']['clanid'],"alignto");
					if ($a==0&&get_module_setting('turnCoat')==0||get_module_setting('turnCoat')==1) {
						addnav("`@Unalign","runmodule.php?module=clanwar&align=0&cl=".$session['user']['clanid']."",false,true);
						addnav(array("`@%s %s",translate_inline("Align to"),get_module_setting("sideone")),"runmodule.php?module=clanwar&align=1&cl=".$session['user']['clanid']."",false,true);
						addnav(array("`@%s %s",translate_inline("Align to"),get_module_setting("sidetwo")),"runmodule.php?module=clanwar&align=2&cl=".$session['user']['clanid']."",false,true);
						blocknav("runmodule.php?module=clanwar&align=".$a."&cl=".$session['user']['clanid']."",true);
					}
				}
				$n = true;
				if (get_module_objpref("clans",$session['user']['clanid'],"alignto")==1) {
					$b = get_module_setting("sideone");
				} elseif (get_module_objpref("clans",$session['user']['clanid'],"alignto")==2) {
					$b = get_module_setting("sidetwo");
				} else {
					$n=false;
					output("`n`@`b`cYour clan is not aligned.`c`b");
				}
				if ($n) {
					output("`n`@`b`cYour clan is aligned to %s! Wait for the war to start!`c`b",$b);
				}
			} elseif ($session['user']['clanrank'] > CLAN_APPLICANT&&$session['user']['clanid']&&get_module_setting("warstat")==2) {
				addnav("~");
				addnav(array("`@%s", translate_inline("View the War Status")),"runmodule.php?module=clanwar&op=list");
			} elseif ($session['user']['clanrank'] > CLAN_APPLICANT&&$session['user']['clanid']&&get_module_setting("warstat")==0&&get_module_setting("archive")==1) {
				addnav("~");
				addnav(array("`@%s", translate_inline("View the archive of the last War")),"runmodule.php?module=clanwar&op=list");
			}
		break;
		case "newday":
			if (get_module_setting("warstat")==2) {
				clanwar_lead();
				if (is_module_installed("house")) {			
					if (get_module_setting("housesleep")==1) {
						output("`n`@People are safe in their houses for the moment..");
					} else {
						if (get_module_setting('houseRes')==1&&get_module_objpref("clans",$session['user']['clanid'],"alignto")!=0||get_module_setting('houseRes')==0) {
							output("`n`%People are still being turned away from their houses by armed guards!");
							output("`nIt's not safe!!!");
						} else {
							output("`n`@Houses are as safe as they've ever been, for you...");
						}
					}
				}
			}
		break;
   		case "dragonkill":
			clanwar_pointinc("dk","","",true);
		break;
		case "village":
			if (get_module_setting("warstat")==2) {
				if (is_module_installed("house")) {			
					if (get_module_setting("housesleep")==1) {
						output("`n`@People are safe in their houses for the moment..");
					} else {
						if (get_module_setting('houseRes')==1&&get_module_objpref("clans",$session['user']['clanid'],"alignto")!=0||get_module_setting('houseRes')==0) {
							output("`n`%People are being turned away from their houses by armed guards!");
							blocknav("runmodule.php?module=house",true);
						} else {
							output("`n`@Armed guards allow you into your house, not having any offence with you.");
						}
					}
				}
				clanwar_lead();
			} elseif (get_module_setting("warstat")==1) {
				output("`n`^All around, the place is quiet.. warily awaiting what will come.");
				output("`nPeople await the next war... surreptiously arming themselves.");
			}
			if (get_module_setting('darkuse')==0) {
				if ($session['user']['clanid']!=0&&get_module_setting('darkRes')==1||get_module_setting('darkRes')==0) {
					blockmodule('darkportal');
					blocknav("runmodule.php?module=darkportal",true);
				}
			}
		break;
		case "charstats":
			if (is_module_installed("magicmirror")) {
				if (get_module_setting("magicmirrorEach")==1&&get_module_pref("hasMirror","magicmirror",$session['user']['acctid'])==1||get_module_setting("mirrorBuy","magicmirror")==0||get_module_setting("magicmirrorEach")==1&&get_module_setting("magicmirrorwithoro")==0) {
					if (get_module_objpref("clans",$session['user']['clanid'],"alignto")==1) {
						clanwar_mirrorlink("clanwar-sideone","Clanwar Mirror");
					} elseif (get_module_objpref("clans",$session['user']['clanid'],"alignto")==2) {
						clanwar_mirrorlink("clanwar-sidetwo","Clanwar Mirror");
					} else {
						clanwar_mirrorlink("clanwar-undecided","Clanwar Mirror");
					}
				}
			}
		break;
   		case "pvpwin":
	 		if (get_module_objpref("clans",$session['user']['clanid'],"alignto")!=0) {
		 		$id = (int)$args['badguy']['acctid'];
		   		$sql = "SELECT name,login,clanrank,clanid FROM " . db_prefix("accounts") . " WHERE acctid=$id";
		   		$result = db_query($sql);
		   		$t = true;
		   		for ($i=0;$i<db_num_rows($result);$i++){
					$row = db_fetch_assoc($result);
					if (get_module_objpref("clans",$row['clanid'],"alignto")==get_module_objpref("clans",$session['user']['clanid'],"alignto")) {
						clanwar_pointinc("pvp","","",true);
						$t = false;
					}
			    }
		   		if ($t) {
			 		$ge = ($session['user']['sex']?"her":"his");
			 		$msg = array("`&%s`0`^ has lost your clan side %s points, attacking someone from %s own side!",$session['user']['name'],get_module_setting("pvp"),$ge);
					clanwar_pointinc("pvp","UH OH!",$msg,false,"`%You shouldn't have attacked someone from your own side!");
				}
			}
		break;
		case "battle-victory":
			if($args['type']=="forest") {
				clanwar_pointinc("ffights","","",true);
			} elseif ($args['type']=="train"){
				clanwar_pointinc("master","","",true);
			}
		break;
		case "battle-defeat":
			if($args['type']=="pvp"){
				clanwar_pointinc("pvp","","",false,"`%You lost!!!");
			} elseif ($args['type']=="forest") {
				clanwar_pointinc("ffights","","",false,"`%You lost!!!");
			} elseif ($args['type']=="train") {
				clanwar_pointinc("master","","",false,"`%You lost!!!");
			}
		break;
		case "innrooms":
			if (get_module_setting('warstat')==2&&get_module_setting('innsleep')==0) {
				if (get_module_setting('innRes')==1&&get_module_objpref("clans",$session['user']['clanid'],"alignto")!=0||get_module_setting('innRes')==0) {
					redirect("inn.php");
				}
			}
		break;
		case "footer-inn":
			if (get_module_setting('warstat')==2&&get_module_setting('innsleep')==0) {
				output("`0\"`3We don't have any rooms for sale,`0\" Cedrik yells, `3\"It's a war!`0\"`n`n");
			}
		break;
	}
	
	return $args;
}

function clanwar_run() {
	global $session;
	$op = httpget("op");
	$a = httpget("align");
	if ($a!="") $op = 'align';
	switch ($op) {
		case "mirror":
			clanwar_mirror();
		break;
		case "align":
			popup_header("Clan Alignment");
			clanwar_align();
			popup_footer();
		break;
		case "list":
			page_header("Clan War - List");
			clanwar_list();
			if (httpget("whence")=="admin") {
				if (get_module_setting('sideone')!="") {
					addnav("Clan War - Setup","runmodule.php?module=clanwar&op=setup");
				} else {
					output("`n`\$`b`cWar's can only be started once you have named both sides in the settings!`c`b");
					output_notl("Set up Settings","configuration.php?op=modulesettings&module=clanwar");
				}
			}
			page_footer();
		break;
		case "setup":
			page_header("Clan War - Setup");
			clanwar_setup();
			addnav("Clan War - List","runmodule.php?module=clanwar&op=list&whence=admin");
			page_footer();
		break;
		case "motd":
			page_header("Clan War - MoTD");
			clanwar_motd();
			addnav("Clan War - Setup","runmodule.php?module=clanwar&op=setup");
			addnav("Clan War - List","runmodule.php?module=clanwar&op=list&whence=admin");
			page_footer();
		break;
	}
}

function clanwar_motd() {
	global $session;
	$subject = httppost("subject");
	$body = httppost("body");
	$sql = "INSERT INTO " . db_prefix("motd") . " (motdtitle,motdbody,motddate,motdauthor) VALUES (\"$subject\",\"$body\",'".date("Y-m-d H:i:s")."','{$session['user']['acctid']}')";
	db_query($sql);
	invalidatedatacache("motd");
	invalidatedatacache("motddate");
}

function clanwar_motdform() {
	global $session;
	output_notl("`bAdd an MoTD`b", $msg);
	rawoutput("<form action='runmodule.php?module=clanwar&op=motd' method='POST'>");
	addnav("","runmodule.php?module=clanwar&op=motd");
	output("Subject: ");
	rawoutput("<input type='text' size='50' name='subject' value=\"The end of the war!\"><br/>");
	output("Body:`n");
	$val = translate_inline("THIS WILL NEED EDITING!")."\n";
	$p = translate_inline("points");
	$val .= get_module_setting("sideone")." ".translate_inline("points: ").get_module_setting("sideonep")."\n";
	$val .= get_module_setting("sidetwo")." ".translate_inline("points: ").get_module_setting("sidetwop")."\n";
	$val .= translate_inline("This will be viewable until the next war starts.");
	$val = HTMLEntities(stripslashes($val));
	rawoutput("<textarea align='right' class='input' name='body' cols='37' rows='5'>".$val."</textarea><br/>");
	$sub = translate_inline("Submit");
	rawoutput("<input type='submit' class='button' value='$sub'></form>");
}

function clanwar_setup() {
	superusernav();
	$s = get_module_setting("warstat");
	if (httpget("seti")!="") {
		$s = httpget("seti");
	}
	if ($s==0) {
		addnav("Start a war","runmodule.php?module=clanwar&op=setup&seti=1&chn=y");
		if (httpget("chn")!="") {
			output("`%THE WAR HAS FINISHED!!!`n`@");
			clanwar_motdform();
			output("`n`^Adding an MoTD is optional.");
		} else {
			output("`@Let's start a war! A (non) nuclear war! At the legend, at the legend, of the greeen dragon!`n`c`%`bZOW!`b `^`iPOW!`i `Q`bSPLAT!`b`c");
		}
	} elseif ($s==1) {
		addnav("Move to actual warring","runmodule.php?module=clanwar&op=setup&seti=2&chn=y");
		if (httpget("chn")!="") {
			output("`b`%PREPERATIONS FOR WAR HAVE STARTED!!!`b");
		}
		output("`n`^This period is known as 'preperations'.`n");
		output("This is recommended for about a week or so, and there will be a preperatory message in each village.`n");
		output("This is when Clans can align themselves if you allow them to, and when you should post an announcement in the MOTD.`n");
		output("Nothing else will/can happen till the next stage.");
	} elseif ($s==2) {
		addnav("End the war","runmodule.php?module=clanwar&op=setup&seti=0&chn=y");
		output("`n`@A good war can go on quite a while:)`n");
		output("Don't forget to announce the winner in an MOTD!`n");
		if (httpget("chn")!="") {
			output("`%THE WAR HAS STARTED!!!`n");
		}
		output("`n`@`c`bEnding the war will open an editor to allow you to post an MoTD:)`b`c");
	}
	clanwar_init($s);
}

function clanwar_init($status="0") {
	if ($status!=get_module_setting("warstat")) {
		if ($status==0) {
			set_module_setting("warstat",0);
			set_module_setting('archive',1);
			require_once('lib/addnews.php');
			addnews("`@`bThe Clans seem to settle down...`b",true);
		} elseif ($status==1) {
			set_module_setting('archive',0);
			set_module_setting("sideonep",0);
			set_module_setting("sidetwop",0);
			$sql = "SELECT MAX(" . db_prefix("clans") . ".clanid) AS clanid, MAX(clanname) AS clanname,count(" . db_prefix("accounts") . ".acctid) AS c FROM " . db_prefix("clans") . " LEFT JOIN " . db_prefix("accounts") . " ON " . db_prefix("clans") . ".clanid=" . db_prefix("accounts") . ".clanid AND clanrank>".CLAN_APPLICANT." GROUP BY " . db_prefix("clans") . ".clanid ORDER BY c DESC";
			if (db_num_rows($result)>0){
				for ($i=0;$i<db_num_rows($result);$i++){
					$row = db_fetch_assoc($result);
					if ($row['c']==0){
						$sql = "DELETE FROM " . db_prefix("clans") . " WHERE clanid={$row['clanid']}";
						db_query($sql);
					} else {
						module_delete_objprefs("clans",$row['clanid']);
						set_module_objpref("clans",$row['clanid'],"ald",1);	
					}
				}
			}
			set_module_setting("warstat",1);
			require_once('lib/addnews.php');
			addnews("`@`bClans have become restless.. one collection challenges another... will it lead to war?`b",true);
			addnews("`@Two factions arise.. `^`b%s `&and `^%s`b`@.",get_module_setting('sideone'),get_module_setting('sidetwo'),true);
		} else {
			set_module_setting("warstat",2);
			require_once('lib/addnews.php');
			addnews("`@`bThe massed Clans have begun the war... let it begin!`b",true);
			addnews("`^`b%s `&vs `^%s`b",get_module_setting('sideone'),get_module_setting('sidetwo'),true);
		}
	}
}

function clanwar_list() {
	$sql = "SELECT MAX(" . db_prefix("clans") . ".clanid) AS clanid, MAX(clanname) AS clanname,count(" . db_prefix("accounts") . ".acctid) AS c FROM " . db_prefix("clans") . " LEFT JOIN " . db_prefix("accounts") . " ON " . db_prefix("clans") . ".clanid=" . db_prefix("accounts") . ".clanid AND clanrank>".CLAN_APPLICANT." GROUP BY " . db_prefix("clans") . ".clanid ORDER BY c DESC";
	$result = db_query($sql);
	$v = 0;
	addnav("Clan War");
	if (httpget("whence")!="admin") {
		villagenav();
		addnav("Return to your clan","clan.php");
		output("`@At the back of the Clan Hall is a hidden door...`nOpening it, you realize you stand in a secret room behind the Clan Halls.`n");
		output("You read about the war!");
		output("`nWhile reading, `%Karissa`@ steps out from the shadows, telling you more...`n");
		if (get_module_setting("warstat")==2) {
			output("You ask `%Karissa`@ for the status of WAR!`0`n`n");
		} else {
			output("You ask `%Karissa`@ about the last war...`0`n`n");
		}
	} else {
		superusernav();
		output("`@Exploring every inch of the Grotto, you come upon a hidden chamber...`n");
		output("You sight with your Godly powers, and see that you are at the back of all of the the Clan Halls!`n");
		output("You see then, that the mood of every clan of the realm can be manipulated here..`n");
		output("With these thoughts `%Karissa`@ steps out from the shadows, informing you of choices.`n");
		output("You ask `%Karissa`@ for the clan listings.`0`n`n");
	}
	rawoutput('<table cellspacing="0" cellpadding="2" align="left">');
	output_notl("<tr class='trhead'>",true);
	output_notl("<td>`@%s</td>",translate_inline("Guild"),true);
	output_notl("<td>`@%s</td>",translate_inline("Status"),true);
	$args = array("clan"=>"1");
	if (get_module_setting("archive")==1) output_notl("<td>`@%s</td>",translate_inline("Existance"),true);
	if (get_module_setting("slose")==1) output_notl("<td>`@%s</td>",translate_inline("Lost Points"),true);
	if (get_module_setting('pvp')>0) $args['Player VS Player Fights']=0;
	if (get_module_setting('dk')>0)	$args['Dragon Kill']=0;
	if (get_module_setting('master')>0) $args['Level Up']=0;
	if (get_module_setting('ffights')>0) $args['Forest Fights']=0;
	$tl = modulehook("clanwar-points", $args);
	foreach ($tl as $sn=>$po) {
		if ($sn!='clan') output_notl("<td>`@%s</td>",translate_inline($sn),true);
	}
	output_notl("</tr>",true);
	if (db_num_rows($result)>0){
		$ua = 0;
		$memb_n = translate_inline("(%s members)");
		$memb_1 = translate_inline("(%s member)");
		for ($i=0;$i<db_num_rows($result);$i++){
			$row = db_fetch_assoc($result);
			if ($row['c']==0){
				$sql = "DELETE FROM " . db_prefix("clans") . " WHERE clanid={$row['clanid']}";
				db_query($sql);
			}else{
				if (get_module_setting("warstat")==1||get_module_setting("warstat")==2) {
					set_module_objpref("clans",$row['clanid'],"ald",0);
				}
				rawoutput('<tr class="' . ($v%2?"trlight":"trdark").'"><td>', true);
				if ($row['c'] == 1) {
					$memb = sprintf($memb_1, $row['c']);
				} else {
					$memb = sprintf($memb_n, $row['c']);
				}
				output_notl("&#149; %s %s`n",htmlentities(full_sanitize($row['clanname'])), $memb, true);
				rawoutput('</td><td>');
				$alo = translate_inline("Align to %s");
				$alt = translate_inline("Align to %s");
				$alo = str_replace("%s",get_module_setting("sideone")."`0",$alo);
				$alt = str_replace("%s",get_module_setting("sidetwo")."`0",$alt);
				if (get_module_objpref("clans",$row['clanid'],"alignto")==0) {
					$ua++;
					output_notl("`&Unaligned");
				} elseif (get_module_objpref("clans",$row['clanid'],"alignto")==1) {
					$so = translate_inline("Aligned to %s");
					$so = str_replace("%s",get_module_setting("sideone")."`0",$so);
					output_notl("`^%s",$so,true);
				} else {
					$so = translate_inline("Aligned to %s");
					$so = str_replace("%s",get_module_setting("sidetwo")."`0",$so);
					output_notl("`^%s",$so,true);
				}
				if (httpget("whence")=="admin") {
					output_notl(" - `@[<a href='runmodule.php?module=clanwar&op=align&align=0&cl=".$row['clanid']."' onClick=\"".popup("runmodule.php?module=clanwar&op=align&align=0&cl=".$row['clanid']."").";return false;\" target='_blank' align='center'>%s</a>`@] - [<a href='runmodule.php?module=clanwar&op=align&align=1&cl=".$row['clanid']."' onClick=\"".popup("runmodule.php?module=clanwar&op=align&align=1&cl=".$row['clanid']."").";return false;\" target='_blank' align='center'>".$alo."</a>`@] - [<a href='runmodule.php?module=clanwar&op=align&align=2&cl=".$row['clanid']."' onClick=\"".popup("runmodule.php?module=clanwar&op=align&align=2&cl=".$row['clanid']."").";return false;\" target='_blank' align='center'>".$alt."</a>`@]`n",translate_inline("Unalign"),true);
					addnav("","runmodule.php?module=clanwar&op=align&align=1&cl=".$row['clanid']."");
					addnav("","runmodule.php?module=clanwar&op=align&align=2&cl=".$row['clanid']."");
					addnav("","runmodule.php?module=clanwar&op=align&align=0&cl=".$row['clanid']."");
				}
				if (get_module_setting("archive")==1) {
					if (get_module_setting("warstat")==0&&get_module_objpref("clans",$row['clanid'],"ald")==0) {
						rawoutput("</td><td>");
						output("`%This clan did not exist during the last war.");
					} elseif (get_module_setting("warstat")==0) {
						rawoutput("</td><td>");
						output("`%This clan existed during the last war.");
					}
				}
				if (get_module_setting("slose")==1) {
					rawoutput("</td><td>");
					if (get_module_objpref("clans",$row['clanid'],"slose")>0) {
						output("`@This clan has lost their side `^%s`@ points in total.",get_module_objpref("clans",$row['clanid'],"slose"));
					} else {
						output("`@This clan has not lost their side points.");
					}
				}
				$args = array("clan"=>$row['clanid']);
				$tl = modulehook("clanwar-points", $args);
				clanwar_pshow("Player VS Player Fight","pvp");
				clanwar_pshow("Dragon Kill","dk");
				clanwar_pshow("Level Up","master");
				clanwar_pshow("Forest Fight","ffights");
				foreach ($tl as $sn=>$po) {
					if ($sn!='clan') clanwar_pshow($sn,$po,false);
				}
				$v++;
				rawoutput('</td></tr>');
			}
		}
	} else {
		rawoutput("<tr><td>There are no clans.</td></tr>");
	}
	rawoutput("</table>", true);
	if (get_module_setting("warstat")==2) {
		if ($v>0) {
			output("`n`@There are `%%s`@ clans.`n",$v);
			if ($ua>0) output("`%%s`@ are unaligned. Chickens!",$ua);
			
		}
	}
	clanwar_lead();
}

function clanwar_align() {
	$t = httpget("align");
	$a = httpget("cl");
	set_module_objpref('clans',$a,'alignto',$t);
	if ($t==0) {
		output("Clan unaligned.");
	} elseif ($t==1) {
		output("Clan aligned to ".get_module_setting("sideone").".");
	} else {
		output("Clan aligned to ".get_module_setting("sidetwo").".");
	}
}

function clanwar_lead() {
	output("`n`@Who will win? %s`@ or %s`@?",get_module_setting("sideone"),get_module_setting("sidetwo"));
	$x = get_module_setting("sideonep");
	$y = get_module_setting("sidetwop");
	$b = false;
	if ($x>$y) {
		$h = "one";
		$t = "two";
		$b = true;
	} elseif ($y>$x) {
		$h = "two";
		$t = "one";
		$b = true;
	}
	if ($b) {
		output("`n`@%s`0`@ are currently in the lead with %s points, compared to %s`0`@'s %s points.",get_module_setting("side".$h),get_module_setting("side".$h."p"),get_module_setting("side".$t),get_module_setting("side".$t."p"));
	} else {
		output("`nIt's neck and neck with `^%s`@ points each!",$x);
	}
}

function clanwar_pointinc($mt="",$for="",$fsubj="",$t=true,$atr="") {
	global $session;
	if (get_module_setting($mt)>0) {
		$xy = get_module_setting($mt);
		if (get_module_objpref("clans",$session['user']['clanid'],"alignto")!=0) {
			$ab = get_module_objpref("clans",$session['user']['clanid'],$mt) + $xy;
			set_module_objpref("clans",$session['user']['clanid'],$mt,$ab);
			if ($t) {
				if (get_module_objpref("clans",$session['user']['clanid'],"alignto")==1) {
					output("`n`@Your clan side, %s`0`@ has gained `^%s`@ points!",get_module_setting("sideone"),$xy);
					set_module_setting("sideonep",get_module_setting("sideonep")+$xy);
				} elseif (get_module_objpref("clans",$session['user']['clanid'],"alignto")==2) {
					output("`n`@Your clan side, %s`0`@ has gained `^%s`@ points!",get_module_setting("sidetwo"),$xy);
					set_module_setting("sidetwop",get_module_setting("sidetwop")+$xy);
				}
			} else {
				if (get_module_setting("slose")!=0) {
					if (get_module_objpref("clans",$session['user']['clanid'],"alignto")==1) {
						output("`n`@Your clan side, %s`0`@ has `%LOST`@ `^%s`@ points!",get_module_setting("sideone"),$xy);
						set_module_setting("sideonep",get_module_setting("sideonep")-$xy);
						set_module_objpref("clans",$session['user']['clanid'],"slose",get_module_objpref("clans",$session['user']['clanid'],"slose")+$xy);
					} elseif (get_module_objpref("clans",$session['user']['clanid'],"alignto")==2) {
						output("`n`@Your clan side, %s`0`@ has `%LOST`@ `^%s`@ points!",get_module_setting("sidetwo"),$xy);
						set_module_setting("sidetwop",get_module_setting("sidetwop")-$xy);
						set_module_objpref("clans",$session['user']['clanid'],"slose",get_module_objpref("clans",$session['user']['clanid'],"slose")+$xy);
					}
				}
			}
			if ($for!=""&&$fsubj!="") {
				$sql = "SELECT name,login,acctid FROM " . db_prefix("accounts") . " WHERE clanid=".$session['user']['clanid']."";
		   	$result = db_query($sql);
		   	for ($i=0;$i<db_num_rows($result);$i++){
					$row = db_fetch_assoc($result);
					systemmail($row['acctid'],$fsubj,$for);
				}
			}
			if ($atr!="") {
				output("`n".$atr);
			}
		}
	}
}

function clanwar_pshow($n="",$abbv="",$p=true,$pn=0,$pt="") {
	if ($p) {
		if (get_module_setting($abbv)>0) {
			rawoutput("</td><td>");
			if (get_module_objpref("clans",$row['clanid'],$abbv)==0) {
				output("`@This clan has not earnt their side `^%s`@ points.",$abbv);
			} else {
				output("`@This clan has earnt their side `&%s `^%s`@ points.",get_module_objpref("clans",$row['clanid'],$abbv),$n);
			}
		}
	} else {
		rawoutput("</td><td>");
		if ($pn>0) {
			output("`@This clan has not earnt their side `^%s`@ points.",$pt);
		} else {
			output("`@This clan has earnt their side `&%s `^%s`@ points.",$pn,$pt);
		}
	}
}

function clanwar_mirrorlink($section="",$link="") {
	if (get_module_setting('warstat')==2) {
		addcharstat("Extra Info");
		$x = translate_inline($link);
		$y = translate_inline("Read your Mirror");
		$magicmirror="<a href='runmodule.php?module=clanwar&op=mirror&s=".$section."' onClick=\"".popup("runmodule.php?module=clanwar&op=mirror&s=".$section."").";return false;\" target='_blank' align='center' class=\"charinfo\" style=\"font-size:10px\">".$y."</a>";
		addcharstat($x, $magicmirror);
		addnav("","runmodule.php?module=clanwar&op=mirror&s=".$section."");
	}
}

function clanwar_mirror(){
	global $session;
	if (is_module_installed("magicmirror")) {
		$section = httpget("s");
		$com = httpget('comscroll');
		$refresh = httpget("refresh");
		if (get_module_objpref("clans",$session['user']['clanid'],"alignto")==1) {
			$b = get_module_setting("sideoneMsg");
			$clan = 1;
		} elseif (get_module_objpref("clans",$session['user']['clanid'],"alignto")==2) {
			$b = get_module_setting("sidetwoMsg");
			$clan = 2;
		} else {
			$clan = 0;
			$b = "`%Align your clan goddamit!";
		}
		$commenting = httpget("commenting");
		$comment = httppost('insertcommentary');
		addcommentary();
	
		popup_header("Clan WAR!");
		$xl = translate_inline("Make your plans!");
		output("`n`n`@%s`n",translate_inline("You search for people from your clan war side..."));
		clanwar_viewcommentary("clanwar-".$clan."","`^$xl",10,"makes war");
		if (get_module_pref("refreshBool","magicmirror")==1) {
				clanwar_script(get_module_pref("refreshTimeSecs","magicmirror"),get_module_pref("refreshTimeMins","magicmirror"));
		}
		output("`n`n`b`@%s`b `^%s",translate_inline("You see a message from your war side:"),$b);
	} else {
		popup_header("Error!");
		output("There en't nuthin here.");
	}
	popup_footer();
}

function clanwar_script($secs,$mins) {
	$rstatus = color_sanitize(translate_inline("Refreshing in progress..."));
	$ustatus = color_sanitize(translate_inline("Refreshing paused...."));
	$s = color_sanitize(translate_inline("seconds left until page refresh!"));
	$m = color_sanitize(translate_inline("minutes and"));
	rawoutput("<script language='javascript'>\n");
	rawoutput("<!--");
	rawoutput("var run=0");
	rawoutput("var limit=\"".$mins.":".$secs."\"");
	rawoutput("");
	rawoutput("function toggle(){");
	rawoutput("if (run==0){");
	rawoutput("run=1");
	rawoutput("}else{");
	rawoutput("run=0");
	rawoutput("}");
	rawoutput("}");
	rawoutput("if (document.images){");
	rawoutput("var parselimit=limit.split(\":\")");
	rawoutput("parselimit=parselimit[0]*60+parselimit[1]*1");
	rawoutput("}");
	rawoutput("function beginrefresh(){");
	rawoutput("if (!document.images)");
	rawoutput("return");
	rawoutput("if (run==1)");
	rawoutput("parselimit+=1");
	rawoutput("if (parselimit==1)");
	rawoutput("window.location.href = location.href;");
	rawoutput("else{"); 
	rawoutput("parselimit-=1");
	rawoutput("curmin=Math.floor(parselimit/60)");
	rawoutput("cursec=parselimit%60");
	rawoutput("if (curmin!=0)");
	rawoutput("curtime=curmin+\" ".$m." \"+cursec+\" ".$s."\"");
	rawoutput("else");
	rawoutput("curtime=cursec+\" ".$s."\"");
	rawoutput("if (run==1)");
	rawoutput("curtime=".$ustatus);
	rawoutput("window.status=curtime");
	rawoutput("setTimeout(\"beginrefresh()\",1000)");
	rawoutput("}");
	rawoutput("}");
	rawoutput("");
	rawoutput("window.onload=beginrefresh");
	rawoutput("//-->");
	rawoutput("</script>");
}

function clanwar_viewcommentary($section,$message="Interject your own commentary?",$limit=10,$talkline="says",$schema=false) {
	global $session,$REQUEST_URI,$doublepost, $translation_namespace;
	if (get_module_setting("pAllow","magicmirror")==1) {
		$pallowx = true;
	} else {
		if (get_module_setting("iAllow","magicmirror")!=1) {
			$limit = get_module_setting("pHere","magicmirror");
		}
		$pallowx = false;
	}
 	
	if ($schema === false)
		$schema=$translation_namespace;
	tlschema("commentary");

	$linkbios=false;

	if ($doublepost) output("`\$`bDouble post?`b`0`n");

	if ((int)getsetting("expirecontent",180)>0 && e_rand(1,1000)==1){
		$sql = "DELETE FROM " . db_prefix("commentary") . " WHERE postdate<'".date("Y-m-d H:i:s",strtotime("-".getsetting("expirecontent",180)." days"))."'";
		db_query($sql);
	}

	$clanrankcolors=array("`!","`#","`^","`&");

	$com=(int)httpget("comscroll");
	$cc = false;
	if (httpget("comscroll") !==false && (int)$session['lastcom']==$com+1)
		$cid = (int)$session['lastcommentid'];
	else
		$cid = 0;

	$session['lastcom'] = $com;

	if ($com > 0 || $cid > 0) {
		// Find newly added comments.
		$sql = "SELECT COUNT(commentid) AS newadded FROM " .
			db_prefix("commentary") . " LEFT JOIN " .
			db_prefix("accounts") . " ON " .
			db_prefix("accounts") . ".acctid = " .
			db_prefix("commentary"). ".author WHERE section='$section' AND " .
			db_prefix("accounts").".locked=0 AND commentid > '$cid'";
		$result = db_query($sql);
		$row = db_fetch_assoc($result);
		$newadded = $row['newadded'];
	} else {
		$newadded = 0;
	}

	$commentbuffer = array();
	if ($cid == 0) {
		$sql = "SELECT ". db_prefix("commentary") . ".*, " .
			db_prefix("accounts").".name, " .
			db_prefix("accounts").".login, " .
			db_prefix("accounts").".clanrank, " .
			db_prefix("clans") .  ".clanshort FROM " .
			db_prefix("commentary") . " INNER JOIN " .
			db_prefix("accounts") . " ON " .
			db_prefix("accounts") .  ".acctid = " .
			db_prefix("commentary"). ".author LEFT JOIN " .
			db_prefix("clans") . " ON " .
			db_prefix("clans") . ".clanid=" .
			db_prefix("accounts") .
			".clanid WHERE section = '$section' AND " .
			db_prefix("accounts") .
			".locked=0 ORDER BY commentid DESC LIMIT " .
			($com*$limit).",$limit";
		if ($com==0)
			$result = db_query_cached($sql,"comments-{$section}");
		else
			$result = db_query($sql);
		while($row = db_fetch_assoc($result)) $commentbuffer[] = $row;
	} else {
		$sql = "SELECT " . db_prefix("commentary") . ".*, " .
			db_prefix("accounts").".name, " .
			db_prefix("accounts").".login, " .
			db_prefix("accounts").".clanrank, " .
			db_prefix("clans").".clanshort FROM " .
			db_prefix("commentary") . " INNER JOIN " .
			db_prefix("accounts") . " ON " .
			db_prefix("accounts") . ".acctid = " .
			db_prefix("commentary"). ".author LEFT JOIN " .
			db_prefix("clans") . " ON " . db_prefix("clans") . ".clanid=" .
			db_prefix("accounts") .
			".clanid WHERE section = '$section' AND " .
			db_prefix("accounts") .
			".locked=0 AND commentid > '$cid' " . 
			"ORDER BY commentid ASC LIMIT $limit";
		$result = db_query($sql);
		while ($row = db_fetch_assoc($result)) $commentbuffer[] = $row;
		$commentbuffer = array_reverse($commentbuffer);
	}

	$rowcount = count($commentbuffer);
	if ($rowcount > 0)
		$session['lastcommentid'] = $commentbuffer[0]['commentid'];
	else
		$session['lastcommentid'];

	$counttoday=0;
	for ($i=0; $i < $rowcount; $i++){
		$row = $commentbuffer[$i];
		$row['comment'] = comment_sanitize($row['comment']);
		$commentids[$i] = $row['commentid'];
		if (date("Y-m-d",strtotime($row['postdate']))==date("Y-m-d")){
			if (!$pallowx) {
				if ($row['name']==$session['user']['name']) $counttoday++;
			}
		}
		$x=0;
		$ft="";
		for ($x=0;strlen($ft)<3 && $x<strlen($row['comment']);$x++){
			if (substr($row['comment'],$x,1)=="`" && strlen($ft)==0) {
				$x++;
			}else{
				$ft.=substr($row['comment'],$x,1);
			}
		}

		$link = "bio.php?char=" . rawurlencode($row['login']) .
			"&ret=".URLEncode($_SERVER['REQUEST_URI']);

		if (substr($ft,0,2)=="::")
			$ft = substr($ft,0,2);
		elseif (substr($ft,0,1)==":")
			$ft = substr($ft,0,1);

		$row['comment'] = holidayize($row['comment']);
		$row['name'] = holidayize($row['name']);
		if ($row['clanrank'])
			$row['name'] = ($row['clanshort']>""?"{$clanrankcolors[$row['clanrank']]}&lt;`2{$row['clanshort']}{$clanrankcolors[$row['clanrank']]}&gt; `&":"").$row['name'];
		if ($ft=="::" || $ft=="/me" || $ft==":"){
			$x = strpos($row['comment'],$ft);
			if ($x!==false){
				$op[$i] = str_replace("&amp;","&",HTMLEntities(substr($row['comment'],0,$x)))."`0`&{$row['name']}`0`& ".str_replace("&amp;","&",HTMLEntities(substr($row['comment'],$x+strlen($ft))))."`0`n";
				$rawc[$i] = str_replace("&amp;","&",HTMLEntities(substr($row['comment'],0,$x)))."`0`&{$row['name']}`0`& ".str_replace("&amp;","&",HTMLEntities(substr($row['comment'],$x+strlen($ft))))."`0`n";
			}
		}
		if ($op[$i]=="")  {
			$op[$i] = "`&{$row['name']}`3 says, \"`#".str_replace("&amp;","&",HTMLEntities($row['comment']))."`3\"`0`n";
			$rawc[$i] = "`&{$row['name']}`3 says, \"`#".str_replace("&amp;","&",HTMLEntities($row['comment']))."`3\"`0`n";
		}
		$session['user']['prefs']['timeoffset'] = round($session['user']['prefs']['timeoffset'],1);
		if ($session['user']['prefs']['timestamp']==1) {
			$time = strtotime("+{$session['user']['prefs']['timeoffset']} hours",strtotime($row['postdate']));
			$s=date("`7[m/d h:ia]`0 ",$time);
			$op[$i] = $s.$op[$i];
		}elseif ($session['user']['prefs']['timestamp']==2) {
			$s=reltime(strtotime($row['postdate']));
			$op[$i] = "`7($s)`0 ".$op[$i];
		}
		if ($message=="X")
			$op[$i]="`0({$row['section']}) ".$op[$i];
		if ($row['postdate']>=$session['user']['recentcomments'])
			$op[$i]="<img src='images/new.gif' alt='&gt;' width='3' height='5' align='absmiddle'> ".$op[$i];
		addnav("",$link);
		$auth[$i] = $row['author'];
		$rawc[$i] = full_sanitize($rawc[$i]);
		$rawc[$i] = htmlentities($rawc[$i], ENT_QUOTES);
	}
	$i--;
	$outputcomments=array();
	$sect="x";

	$moderating=false;
	if (($session['user']['superuser'] & SU_EDIT_COMMENTS) && $message=="X")
		$moderating=true;

	for (;$i>=0;$i--){
		$out="";
		if ($moderating){
			if ($session['user']['superuser'] & SU_EDIT_USERS){
				$out.="`0[ <input type='checkbox' name='comment[{$commentids[$i]}]'> | <a href='user.php?op=setupban&userid=".$auth[$i]."&reason=".rawurlencode($rawc[$i])."'>Ban</a> ]&nbsp;";
				addnav("","user.php?op=setupban&userid=$auth[$i]&reason=".rawurlencode($rawc[$i]));
			}else{
				$out.="`0[ <input type='checkbox' name='comment[{$commentids[$i]}]'> ]&nbsp;";
			}
			$matches=array();
			preg_match("/[(]([^)]*)[)]/",$op[$i],$matches);
			$sect=trim($matches[1]);
			if (substr($sect,0,5)!="clan-" || $sect==$section){
				if (substr($sect,0,4)!="pet-"){
					$out.=$op[$i];
					if (!is_array($outputcomments[$sect]))
						$outputcomments[$sect]=array();
					array_push($outputcomments[$sect],$out);
				}
			}
		}else{
			$out.=$op[$i];
			if (!is_array($outputcomments[$sect]))
				$outputcomments[$sect]=array();
			array_push($outputcomments[$sect],$out);
		}
	}
	
	if ($moderating){
		$scriptname=substr($_SERVER['SCRIPT_NAME'],strrpos($_SERVER['SCRIPT_NAME'],"/")+1);
		addnav("","$scriptname?op=commentdelete&return=".URLEncode($_SERVER['REQUEST_URI']));
		$mod_Del1 = htmlentities(translate_inline("Delete Checked Comments"));
		$mod_Del2 = htmlentities(translate_inline("Delete Checked & Ban (3 days)"));
		$mod_Del_confirm = addslashes(htmlentities(translate_inline("Are you sure you wish to ban this user and have you specified the exact reason for the ban, i.e. cut/pasted their offensive comments?")));
		$mod_reason = translate_inline("Reason:");
		$mod_reason_desc = htmlentities(translate_inline("Banned for comments you posted."));
		
		output_notl("<form action='$scriptname?op=commentdelete&return=".URLEncode($_SERVER['REQUEST_URI'])."' name='talkform' method='POST'>",true);
		output_notl("<input type='submit' class='button' value=\"$mod_Del1\">",true);
		output_notl("<input type='submit' class='button' name='delnban' value=\"$mod_Del2\" onClick=\"return confirm('$mod_Del_confirm');\">",true);
		output_notl("`n$mod_reason <input name='reason0' size='40' value=\"$mod_reason_desc\" onChange=\"document.getElementById('reason').value=this.value;\">",true);
	}
	//output the comments
	ksort($outputcomments);
	reset($outputcomments);
	$sections = commentarylocs();
	$needclose = 0;

	while (list($sec,$v)=each($outputcomments)){
		if ($sec!="x") {
			if($needclose) modulehook("}collapse");
			output_notl("`n<hr><a href='moderate.php?area=%s'>`b`^%s`0`b</a>`n", $sec, $sections[$sec], true);
			addnav("", "moderate.php?area=$sec");
			modulehook("collapse{",array("name"=>"com-".$sec));
			$needclose = 1;
		} else {
			modulehook("collapse{",array("name"=>"com-".$section));
			$needclose = 1;
		}
		reset($v);
		while (list($key,$val)=each($v)){
			$args = array('commentline'=>$val);
			$args = modulehook("viewcommentary", $args);
			$val = $args['commentline'];
			output_notl($val, true);
		}
	}

	if ($moderating && $needclose) {
		modulehook("}collapse");
		$needclose = 0;
	}

	if ($moderating){
		output_notl("`n");
		rawoutput("<input type='submit' class='button' value=\"$mod_Del1\">");
		rawoutput("<input type='submit' class='button' name='delnban' value=\"$mod_Del2\" onClick=\"return confirm('$mod_Del_confirm');\">");
		output_notl("`n%s ", $mod_reason);
		rawoutput("<input name='reason' size='40' id='reason' value=\"$mod_reason_desc\">");
		rawoutput("</form>");
		output_notl("`n");
	}

	if ($session['user']['loggedin']) {
		if ($counttoday<($limit/2) ||
				($session['user']['superuser']&~SU_DOESNT_GIVE_GROTTO)){
			if ($message!="X"){
				$message="`n`@$message`n";
				output($message);
				clanwar_talkform($section,$talkline,$limit,$schema);
			}
		}else{
			if (!$pallowx) {
				output("`n`@%s`nSorry, you've exhausted your posts in this section for now.`0`n",$message);
			} else {
				if ($message!="X"){
					$message="`n`@$message`n";
					output($message);
					clanwar_talkform($section,$talkline,$limit,$schema);
				}
			}
		}
	}

	$firstu = translate_inline("&lt;&lt; First Unseen");
	$prev = translate_inline("&lt; Previous");
	$ref = translate_inline("Refresh");
	$next = translate_inline("Next &gt;");
	$lastu = translate_inline("Last Page &gt;&gt;");
	if ($rowcount>=$limit || $cid>0){
		$sql = "SELECT count(*) AS c FROM " . db_prefix("commentary") . " WHERE section='$section' AND postdate > '{$session['user']['recentcomments']}'";
		$r = db_query($sql);
		$val = db_fetch_assoc($r);
		$val = round($val['c'] / $limit + 0.5,0) - 1;
		if ($val>0){
			$first = comscroll_sanitize($REQUEST_URI)."&comscroll=".($val);
			$first = str_replace("?&","?",$first);
			if (!strpos($first,"?")) $first = str_replace("&","?",$first);
			$first .= "&refresh=1";
			output_notl("<a href=\"$first\">$firstu</a>",true);
			addnav("",$first);
		}else{
			output_notl($firstu,true);
		}
		$req = comscroll_sanitize($REQUEST_URI)."&comscroll=".($com+1);
		$req = str_replace("?&","?",$req);
		if (!strpos($req,"?")) $req = str_replace("&","?",$req);
		$req .= "&refresh=1";
		output_notl("<a href=\"$req\">$prev</a>",true);
		addnav("",$req);
	}else{
		output_notl("$firstu $prev",true);
	}
	$last = comscroll_sanitize($REQUEST_URI)."&refresh=1";
	$last = str_replace("?&","?",$last);
	if (!strpos($last,"?")) $last = str_replace("&","?",$last);
	output_notl("&nbsp;<a href=\"$last\">$ref</a>&nbsp;",true);
	addnav("",$last);
	if ($com>0 || ($cid > 0 && $newadded > $limit)){
		$req = comscroll_sanitize($REQUEST_URI)."&comscroll=".($com-1);
		$req = str_replace("?&","?",$req);
		if (!strpos($req,"?")) $req = str_replace("&","?",$req);
		$req .= "&refresh=1";
		output_notl(" <a href=\"$req\">$next</a>",true);
		addnav("",$req);
		output_notl(" <a href=\"$last\">$lastu</a>",true);
	}else{
		output_notl("$next $lastu",true);
	}
	if (!$cc) db_free_result($result);
	tlschema();
	if ($needclose) modulehook("}collapse");
}

function clanwar_talkform($section,$talkline,$limit=10,$schema=false){
		if (get_module_setting("pAllow","magicmirror")==1) {
			$pallowx = true;
		} else {
			if (get_module_setting("iAllow","magicmirror")!=1) {
				$limit = get_module_setting("pHere","magicmirror");
			}
			$pallowx = false;
		}
		global $REQUEST_URI,$session,$translation_namespace;
		if ($schema===false) $schema=$translation_namespace;
		tlschema("commentary");

		if (substr($section,0,5)!="clan-"){
			$sql = "SELECT author FROM " . db_prefix("commentary") . " WHERE section='$section' AND postdate>'".date("Y-m-d 00:00:00")."' ORDER BY commentid DESC LIMIT $limit";
			$result = db_query($sql);
		$counttoday=0;
		while ($row=db_fetch_assoc($result)){
			if ($row['author']==$session['user']['acctid']) $counttoday++;
		}
		if (!$pallowx) {
			if (round($limit/2,0)-$counttoday <= 0){
				if ($session['user']['superuser']&~SU_DOESNT_GIVE_GROTTO){
					output("`n`)(You'd be out of posts if you weren't a superuser or moderator.)`n");
				}else{
					output("`n`)(You are out of posts for the time being.  Once some of your existing posts have moved out of the comment area, you'll be allowed to post again.)`n");
					return false;
				}
			}
		}
	}
	rawoutput("<script language='JavaScript'>
	function previewtext(t){
		var out = \"<span class=\'colLtWhite\'>".addslashes(appoencode($session['user']['name']))." \";
		var end = '</span>';
		var x=0;
		var y='';
		var z='';
		if (t.substr(0,2)=='::'){
			x=2;
			out += '</span><span class=\'colLtWhite\'>';
		}else if (t.substr(0,1)==':'){
			x=1;
			out += '</span><span class=\'colLtWhite\'>';
		}else if (t.substr(0,3)=='/me'){
			x=3;
			out += '</span><span class=\'colLtWhite\'>';
		}else{
			out += '</span><span class=\'colDkCyan\'>".addslashes(appoencode($talkline)).", \"</span><span class=\'colLtCyan\'>';
			end += '</span><span class=\'colDkCyan\'>\"';
		}
		for (; x < t.length; x++){
			y = t.substr(x,1);
			if (y=='<'){
				out += '&lt;';
				continue;
			}else if(y=='>'){
				out += '&gt;';
				continue;
			}else if (y=='`'){
				if (x < t.length-1){
					z = t.substr(x+1,1);
					if (z=='0'){
						out += '</span>';
					}else if (z=='1'){
						out += '</span><span class=\'colDkBlue\'>';
					}else if (z=='2'){
						out += '</span><span class=\'colDkGreen\'>';
					}else if (z=='3'){
						out += '</span><span class=\'colDkCyan\'>';
					}else if (z=='4'){
						out += '</span><span class=\'colDkRed\'>';
					}else if (z=='5'){
						out += '</span><span class=\'colDkMagenta\'>';
					}else if (z=='6'){
						out += '</span><span class=\'colDkYellow\'>';
					}else if (z=='7'){
						out += '</span><span class=\'colDkWhite\'>';
					}else if (z=='q'){
						out += '</span><span class=\'colDkOrange\'>';
					}else if (z=='!'){
						out += '</span><span class=\'colLtBlue\'>';
					}else if (z=='@'){
						out += '</span><span class=\'colLtGreen\'>';
					}else if (z=='#'){
						out += '</span><span class=\'colLtCyan\'>';
					}else if (z=='$'){
						out += '</span><span class=\'colLtRed\'>';
					}else if (z=='%'){
						out += '</span><span class=\'colLtMagenta\'>';
					}else if (z=='^'){
						out += '</span><span class=\'colLtYellow\'>';
					}else if (z=='&'){
						out += '</span><span class=\'colLtWhite\'>';
					}else if (z=='Q'){
						out += '</span><span class=\'colLtOrange\'>';
					}else if (z==')'){
						out += '</span><span class=\'colLtBlack\'>';
					}
					x++;
				}
			}else{
				out += y;
			}
		}
		document.getElementById(\"previewtext\").innerHTML=out+end+'<br/>';
	}
	</script>
	");
	if ($talkline!="says") $tll = strlen($talkline)+11; else $tll=0;
	$req = comscroll_sanitize($REQUEST_URI)."&comment=1";
	$req = str_replace("?&","?",$req);
	if (!strpos($req,"?")) $req = str_replace("&","?",$req);
	addnav("",$req."&s=".httpget("s")."&msg=".httpget("msg"));
	rawoutput("<form action=\"$req\" method='POST' name='talkform' autocomplete='false'>",true);
	if (get_module_pref("refreshBool","magicmirror")==1) {
		$x = "onfocus='toggle();' onblur='toggle();' ";
	} else {
		$x = "";
	}
	rawoutput("<input name='insertcommentary' id='commentary' ".$x."onKeyUp='previewtext(document.getElementById(\"commentary\").value);'; size='40' maxlength='".(200-$tll)."'>",true);
	rawoutput("<input type='hidden' name='talkline' value='$talkline'>");
	rawoutput("<input type='hidden' name='schema' value='$schema'>");
	rawoutput("<input type='hidden' name='counter' value='{$session['counter']}'>");
	$session['commentcounter'] = $session['counter'];
	if ($section=="X"){
		$vname = getsetting("villagename", LOCATION_FIELDS);
		$iname = getsetting("innname", LOCATION_INN);
		$sections = commentarylocs();
		reset ($sections);
		output_notl("<select name='section'>",true);
		while (list($key,$val)=each($sections)){
			output_notl("<option value='$key'>$val</option>",true);
		}
		output_notl("</select>",true);
	}else{
		output_notl("<input type='hidden' name='section' value='$section'>",true);
	}
	$add = translate_inline("Add");
	output_notl("<input type='submit' class='button' value='$add'>`n",true);
	if (!$pallowx) {
		if (round($limit/2,0)-$counttoday < 3){
			output("`)(You have %s posts left today)`n`0",(round($limit/2,0)-$counttoday));
		}
	}
	output_notl("<div id='previewtext'></div><br/>",true);
	rawoutput("</form>");
	tlschema();
}

function clanwar_module_pointinc($mt="",$for="",$fsubj="",$t=true,$atr="",$module="") {
	global $session;
	if (get_module_setting("warstat","clanwar")==2) {
		if (get_module_setting($mt,$module)>0) {
			$xy = get_module_setting($mt,$module);
			if (get_module_objpref("clans",$session['user']['clanid'],"alignto","clanwar")!=0) {
				$ab = get_module_objpref("clans",$session['user']['clanid'],$mt,$module) + $xy;
				set_module_objpref("clans",$session['user']['clanid'],$mt,$ab,$module);
				if ($t) {
					if (get_module_objpref("clans",$session['user']['clanid'],"alignto","clanwar")==1) {
						output("`n`@Your clan side, %s`0`@ has gained `^%s`@ points!",get_module_setting("sideone","clanwar"),$xy);
						set_module_setting("sideonep",get_module_setting("sideonep","clanwar")+$xy,"clanwar");
					} elseif (get_module_objpref("clans",$session['user']['clanid'],"alignto","clanwar")==2) {
						output("`n`@Your clan side, %s`0`@ has gained `^%s`@ points!",get_module_setting("sidetwo","clanwar"),$xy);
						set_module_setting("sidetwop",get_module_setting("sidetwop","clanwar")+$xy,"clanwar");
					}
				} else {
					if (get_module_setting("slose","clanwar")!=0) {
						if (get_module_objpref("clans",$session['user']['clanid'],"alignto","clanwar")==1) {
							output("`n`@Your clan side, %s`0`@ has `%LOST`@ `^%s`@ points!",get_module_setting("sideone","clanwar"),$xy);
							set_module_setting("sideonep",get_module_setting("sideonep","clanwar")-$xy,"clanwar");
							set_module_objpref("clans",$session['user']['clanid'],"slose",get_module_objpref("clans",$session['user']['clanid'],"slose","clanwar")+$xy,"clanwar");
						} elseif (get_module_objpref("clans",$session['user']['clanid'],"alignto","clanwar")==2) {
							output("`n`@Your clan side, %s`0`@ has `%LOST`@ `^%s`@ points!",get_module_setting("sidetwo","clanwar"),$xy);
							set_module_setting("sidetwop",get_module_setting("sidetwop","clanwar")-$xy,"clanwar");
							set_module_objpref("clans",$session['user']['clanid'],"slose",get_module_objpref("clans",$session['user']['clanid'],"slose","clanwar")+$xy,"clanwar");
						}
					}
				}
				if ($for!=""&&$fsubj!="") {
					require_once('lib/systemmail.php');
					$sql = "SELECT name,login,acctid FROM " . db_prefix("accounts") . " WHERE clanid=".$session['user']['clanid']."";
			   		$result = db_query($sql);
			   		for ($i=0;$i<db_num_rows($result);$i++){
						$row = db_fetch_assoc($result);
						systemmail($row['acctid'],$fsubj,$for);
					}
				}
				if ($atr!="") {
					output("`n".$atr);
				}
			}
		}
	}
}
?>