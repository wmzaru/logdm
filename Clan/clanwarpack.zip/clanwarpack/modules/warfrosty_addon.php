<?php
/*
Details:
 * This is a module that uses the clanwar.php module
 * Basically just adds events and the oppurtunity to earn points in frosty the snowman
History Log:
 v1.0:
 o Stable
 v1.1:
 o Still stable...
*/
require_once('modules/clanwar.php');
function warfrosty_addon_getmoduleinfo(){
	$info = array(
		"name"=>"Frosty the Snowman - Addon", 
		"version"=>"1.1",
		"author"=>"`@CortalUX", 
		"download"=>"http://dragonprime.net/users/CortalUX/clanwarpack.zip", 
		"category"=>"Clanwar",
		"settings"=>array(
			"Frosty the Snowman - Clanwar,title",
			"(choose how many points you want an action to increment your points by),note",
			"(set it to 0 for nothing to happen),note",
			"rebuild"=>"Rebuilding the snowman?,int|0", 
			"(and if you let users lose points in your war.. how much should they lose..),note",
			"ignore"=>"Ignoring the girl?,int|0",
		),
		"prefs-clans"=>array(
			"Clan War - Frosty Points,title",
			"rebuild"=>"Rebuilding the snowman??,int|0",
		),
		"requires"=>array(
			"clanwar" => "1.9|`@CortalUX, http://dragonprime.net/users/CortalUX/clanwarpack.zip",
			"frosty" => "1.0|Talisman, core_module",
		),
	);
	return $info;
}

function warfrosty_addon_install() {
	if (!is_module_active('warbloodbank_addon')){
		output("`n`c`b`QFrosty the Snowman - Addon Module - Installed`0`b`c");
	}else{
		output("`n`c`b`QFrosty the Snowman - Addon Module - Updated`0`b`c");
	}
	module_addhook("clanwar-points");
	module_addhook("footer-village");
	debuglog("Clanwar Frosty the Snowman addon - Installed.");
	return true;
}

function warfrosty_addon_uninstall(){
	output("`n`c`b`QFrosty the Snowman - Addon Module - Uninstalled`0`b`c");
	return true;
}

function warfrosty_addon_dohook($hookname, $args){
	global $session;
	switch ($hookname){
		case "clanwar-points":
			$p = get_module_objpref("clans",$args['clan'],"rebuild");
			if (isset($args['Christmas Spirit Points'])) {
				$args['Christmas Spirit Points']+=$p;
			} else {
				$args['Christmas Spirit Points']=$p;
			}
		break;
		case "footer-village":
			$op = httpget('op');
			if (get_module_setting("warstat","clanwar")==2&&$session['user']['specialinc']=="module:frosty") {
				if ($op=='') {
					if (get_module_pref('seentoday','frosty')==0) {
						output("`n`@Someone from another war side walked past you...");
					}
				} elseif ($op=='help') {
					if (is_module_active('alignment')) {
						require_once('modules/alignment.php');
						align("1");
					}
					clanwar_module_pointinc("rebuild","","",true,"`@Someone from another side walked past without seeing you, while you built the snowman. When you finished, you ran off and hit him for more points!","warfrosty_addon"); 
				} elseif ($op=='leave') {
					if (is_module_active('alignment')) {
						require_once('modules/alignment.php');
						align("-1");
					}
					clanwar_module_pointinc("ignore","","",false,"`%Someone from another side saw you and hit you before you could react! If you'd helped the girl make her snowman, they wouldn't have seen you... and you could've jumped them.","warfrosty_addon"); 
				} elseif ($op=='ignore') {
					if (is_module_active('alignment')) {
						require_once('modules/alignment.php');
						align("-1");
					}
					clanwar_module_pointinc("ignore","","",false,"`%Someone from another side saw you and hit you before you could react! If you'd talked to the girl, they wouldn't have noticed you.. and you could've jumped them.","warfrosty_addon"); 
				}
			}
		break;
	}
	return $args;
}

function warfrosty_addon_run(){
}
?>
