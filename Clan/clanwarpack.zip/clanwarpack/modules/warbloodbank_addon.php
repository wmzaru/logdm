<?php
/*
Details:
 * This is a module that uses the clanwar.php module
 * Allows you to donate more blood at the bloodbank- upto 5 times
 * After five times, there is a random chance of dying
History Log:
 v1.0:
 o Stable
*/
require_once('modules/clanwar.php');
function warbloodbank_addon_getmoduleinfo(){
	$info = array(
		"name"=>"Bloodbank - Addon",
		"version"=>"1.1",
		"author"=>"`@CortalUX",
		"download"=>"http://dragonprime.net/users/CortalUX/clanwarpack.zip",
		"category"=>"Clanwar",
		"settings"=>array(
			"Bloodbank Addon Settings - Clanwar,title",
			"(choose how many points you want an action to increment your points by),note",
			"(set it to 0 for nothing to happen),note",
			"snkp"=>"Taking blood?,int|0",
			"(and if you let users lose points in your war.. how much should they lose..),note",
			"die"=>"Dying?,int|0",
		),
		"prefs"=>array(
			"Bloodbank Addon - User Prefs, title",
			"blood"=>"Blood taken today?,int|0"
		),
		"prefs-clans"=>array(
			"Clan War - Bloodbank Addon Points,title",
			"snkp"=>"Sneak points?,int|0",
		),
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"requires"=>array(
			"clanwar" => "1.9|`@CortalUX, http://dragonprime.net/users/CortalUX/clanwarpack.zip",
			"bloodbank" => "2.0|E Stevens, JT Traub, S Brown, core_module",
		),
	);
	return $info;
}

function warbloodbank_addon_install(){
	if (!is_module_active('warbloodbank_addon')){
		output("`n`c`b`QBloodbank - Addon Module - Installed`0`b`c");
	}else{
		output("`n`c`b`QBloodbank - Addon Module - Updated`0`b`c");
	}
	module_addhook("clanwar-points");
	module_addhook("footer-runmodule");
	return true;
}

function warbloodbank_addon_uninstall(){
	output("`n`c`b`QBloodbank - Addon Module - Uninstalled`0`b`c");
	return true;
}

function warbloodbank_addon_dohook($hookname, $args){
	global $session;
	switch ($hookname){
		case "clanwar-points":
			$p = get_module_objpref("clans",$args['clan'],"snkp");
			if (isset($args['Sneak Points'])) {
				$args['Sneak Points']+=$p;
			} else {
				$args['Sneak Points']=$p;
			}
		break;
		case "footer-runmodule":
			$module = httpget('module');
			$op = httpget('op');
			if ($module=='bloodbank'&&get_module_setting("warstat","clanwar")==2&&op=="") {
				addnav("War Options");
				addnav(array("`b`@Give Bvlood for the War `^(%s pints given)`b",get_module_pref("blood")),"runmodule.php?module=warbloodbank_addon&op=gifblood");
				output("`n`7Vladimir paces around before saying, \"`&Many wars haf come and gone, many ignored by Vampires. I vould like to help you. If you gif me what I like to call 'War' bvlood, I can use it to help your side.7\"");
				output("`n`7Vladimir continues, \"`&The operahtion is very.. dahngeros. You muhst be sure.?7\"");
			}
		break;
	}
	return $args;
}

function warbloodbank_addon_run(){
	global $session;
	page_header("Vladimir's Blood Bank");
	output("`^`c`bGihfing blood.`b`c");
	$blood = get_module_pref("blood");
	output("`n`7Vladimir smiles and asks you to grit your teeth, \"`&I vill extract a pint now.`7\"");
	if ($blood>=5) {
		$chn=(e_rand(1,5));
		if ($chn==5) {
			$die = true;
		} else {
			output("`n`7Vladimir advises you, \"`&I think you've given enough Bvlood... but I vill take more if you vant.`7\"");
			$die = false;
		}
	} else {
		$die = false;
	}
	$blood++;
	set_module_pref("blood",$blood);
	if ($die) {
		output("`nVladimir extracts a pint of bvlood... and light flashes in front of your eyes...");
		output("`nYour vision fades..."); 
		output("`nVladimir winces, \"`&May Ramius be vith you.`7\"");
		clanwar_module_pointinc("die","","",false,"`%You die, and your clan is weakened!","warbloodbank_addon");
		output("`^You `\$lose`^ 5% of your experience.`n");
		output("You may continue playing again tomorrow.");
		$session['user']['alive']=false;
		$session['user']['hitpoints']=0;
		$session['user']['experience']*=0.95;
		addnav("Daily News","news.php");
		$ge = ($session['user']['sex']?"her":"his");
		addnews("`&%s `7was giving WAR blood to Vladimir to gain points for %s clan side... %s died.", $session['user']['name'],$ge,$ge);
	} else {
		output("`nVladimir extracts a pint of bvlood... \"`&Yesh! De opervation vas successful! I didn't think it vould be!`7\"");
		output("`n`3You exclaim, \"`&WHAT! AND YOU STILL HAD ME DO IT!`3\"");
		output("`nVladimir extracts a pint of bvlood... \"`&I shed..`7\"");
		clanwar_module_pointinc("snkp","","",true,"`%Vladimir helps your clan side with blood magic! Your clan gains sneak points!","warbloodbank_addon");
		$allowdep=get_module_setting("allowdep","bloodbank");
		$allowtx=get_module_setting("allowtx","bloodbank");
		$giventoday=get_module_pref("giventoday","bloodbank");
		villagenav();
		addnav("Money");
		if ($session['user']['goldinbank']>=0){
			addnav("W?Withdraw","runmodule.php?module=bloodbank&op=withdraw");
			if ($allowdep)
				addnav("D?Deposit","runmodule.php?module=bloodbank&op=deposit");
			if (getsetting("borrowperlevel",20))
				addnav("L?Take out a Loan","runmodule.php?module=bloodbank&op=borrow");
		}else{
			if ($allowdep)
				addnav("D?Pay off Debt","runmodule.php?module=bloodbank&op=deposit");
			if (getsetting("borrowperlevel",20))
				addnav("L?Borrow More","runmodule.php?module=bloodbank&op=borrow");
		}
		if ($allowtx){
			if ($session['user']['level']>=getsetting("mintransferlev",3) ||
					$session['user']['dragonkills']>0){
				addnav("M?Transfer Money","runmodule.php?module=bloodbank&op=transfer");
			}
		}
		addnav("Give Blood","runmodule.php?module=bloodbank&op=give");
		addnav("War Options");
		addnav(array("`b`@Give Bvlood for the War `^(%s pints given)`b",get_module_pref("blood")),"runmodule.php?module=warbloodbank_addon&op=gifblood");
		output("`n`7Vladimir paces around before saying, \"`&Many wars haf come and gone, many ignored by Vampires. I vould like to help you. If you gif me MORE of what I like to call 'War' bvlood, I can use it to help your side better.7\"");
		output("`n`7Vladimir continues, \"`&The operahtion is very.. dahngeros, as I said before. You muhst be sure.7\"");
		output("`n`7Vladimir smiles bloodily, \"`&Or you can deposit money.`7\"");
		$session['user']['hitpoints']-=10;
		if ($session['user']['hitpoints']<=0) {
			$session['user']['hitpoints']=1;
		}
	}
	page_footer();
}
?>
