<?php
// Clan Training Room
// Author: Robert of Maddrio dot com
// 24July06
// Version 1.1 adds in fees and dk requirements

require_once("lib/fightnav.php");
require_once("lib/http.php");

function trainingroom_getmoduleinfo(){
	$info = array(
		"name"=>"Clan Training Room",
		"version"=>"1.1",
		"author"=>"`2Robert",
		"category"=>"Clan",
		"download"=>"http://dragonprime.net/index.php?topic=2215.0",
		"settings"=>array(
			"Clan Training Room - Settings,title",
			"turncost"=>"How many turns must player have before training?,range,1,50,1|5",
			"feegold"=>"Cost in Gold to train? (minimum 10 gold!),range,10,500,10|50",
			"dkgems"=>"How many DK - after this player pays in gems!,range,1,100,1|10",
			"feegems"=>"Cost in Gems to train? (see above setting) (minimum 1 gem!),range,1,100,1|1",
			"maxlevel"=>"Max level for player to be.,range,1,20,1|14",
			"days"=>"How many days in between training? (minimum 2 days!),range,2,20,2|4",
			"amt"=>"How much EXP? (multiplied by players level),range,5,200,5|25",
		),
		"prefs"=>array(
			"Clan Training Room - User Prefs,title",
			"fighttoday"=>"Did player train today?,bool|0",
			"daysleft"=>"How many days till they can train again?,int|1",
			"fighttotal"=>"Total training sessions.,int|0",
		)
		
	);
	return $info;
}
function trainingroom_install(){
	if (!is_module_active('trainingroom')){
		output("`^ Installing Clan Training Room `n`0");
	}else{
		output("`^ Up Dating Clan Training Room `n`0");
	}
	module_addhook("footer-clan");
	module_addhook("newday");
	return true;
}

function trainingroom_uninstall(){
	output("`^ Un-Installing Clan Training Room `n`0");
	return true;
}

function trainingroom_dohook($hookname,$args){
	$maxlevel=get_module_setting("maxlevel");
	$level=$session['user']['level'];
	$clanrank=$session['user']['clanrank'];
	switch($hookname){
	case "footer-clan":
	if (!$clanrank == "Applicant" && $level <= $maxlevel){
	addnav("Clan Options");
	addnav("Enter Training Room","runmodule.php?module=trainingroom");
	}
	break;
	case "newday":
	if (get_module_pref("daysleft") >=1){
		output("`n`2Your body still hurts from your last training session!`n`0");
		increment_module_pref("daysleft",-1);
	}
	if (get_module_pref("fighttoday") >= 1){
		set_module_pref("fighttoday",0);
	}
	break;
	}
return $args;
}

function trainingroom_run(){
	global $session;
	$op=httpget('op');
	$name=$session['user']['name'];
	$gems=$session['user']['gems'];
	$gold=$session['user']['gold'];
	$turns=$session['user']['turns'];
	$level=$session['user']['level'];
	$playerdk=$session['user']['dragonkills'];

	$amt=get_module_setting("amt");
	$feegold=get_module_setting("feegold");
	$dkgems=get_module_setting("dkgems");
	$feegems=get_module_setting("feegems");
	$exp= round($level*$amt);
	$daysleft=get_module_pref("daysleft");
	$fighttoday = get_module_pref("fighttoday");
	
	page_header("Clan Hall");
	output("`c`b`2 Clan Training Room `b`c`n`n");
	if ($session['user']['sex']==0){ $sex="m'lord"; }else{ $sex="m'lady";}

	if ($op==""){
		addnav("(B) Back to Clan Hall","clan.php");
		if ($turns < $turncost){
			output("`n You think about training today but are too tired. ");
		}
		if ($fighttoday > 0){
			output("`n`n You re-enter to see if anyone else is training today. ");
		}
		if ($daysleft > 0){
			output("`n`n You still suffer aches and pain from your last training session. ");
			output("`n`n You should wait %s more days before training again. ",$daysleft);
		}
		if ($daysleft==0 && $fighttoday==0){
		output(" You enter the Clan Training Room, where great warriors are bred. ");
		output("`n`n A Knight dressed in a Suit of Black Armor waits for you. ");
			if ($playerdk < $dkgems){
				output("`n`n The Clan requires you pay %s gold to train. ",$feegold);
				if ($gold >= $feegold ){
					addnav(" Train ");
					addnav("(T) Begin Training","runmodule.php?module=trainingroom&op=battle");
				}else{
					output("`n`n`^ You bloody pauper, you dont have enough gold to train, come back when you do. ");
				}
			}else{
				output("`n`n At your rank, the Clan requires you pay %s gem to train. ",$feegems);
				if ($gems >= $feegems ){
					addnav(" Train ");
					addnav("(T) Begin Training","runmodule.php?module=trainingroom&op=battle");
				}else{
					output("`n`n`^ You bloody pauper, you dont have enough gems to train, come back when you do. ");
				}
			}
		}
	}elseif ($op=="battle"){
		$attack = round($session['user']['attack']*.75);
		$defense = round($session['user']['defense']*.75);
		$maxhitpoints = $session['user']['maxhitpoints']+4;
		$badguy = array(
			"creaturename"=>"`%Black Knight`0",
			"creaturelevel"=>$session['user']['level'],
			"creatureweapon"=>"`6Broadsword",
			"creatureattack"=>$attack,
			"creaturedefense"=>$defense,
			"creaturehealth"=>$maxhitpoints,
			"diddamage"=>0,
			"type"=>"bandit");
			$session['user']['badguy']=createstring($badguy);
			$op="fight";
			httpset('op',"fight");
		$battle=true;
	}
	if ($op=="run"){
		if (e_rand(1,3)==1){
			output("`n`3 You wimp out of the fight and are seen running away!`n`n");
			set_module_pref("fighttoday",1);
		}else{
			output("`n`3 The trainer continues to pound on you like there is no tomorrow!`n`n");
			$op="fight";
			httpset('op',"fight");
		}
	}
	if ($op=="fight" || $op=="run"){
	$battle=true;
	}
	if ($battle){
	require_once("lib/battle-skills.php");
	suspend_buffs('allowintrain',"`&Your Clan prevents you from using any buffs during training!`0`n");
	require_once("battle.php");
		if ($victory){
			switch (e_rand(1,6)) {
				case 1: output("`& With a final swift kick to the ribs, the `%Black Knight `&coughs up blood and concedes defeat!"); break;
				case 2: output("`& A sharp blow to the neck, the `%Black Knight `&falls to the ground!"); break;
				case 3: output("`& You step to the side and attack the `%Black Knight `& from the rear, he falls to the ground!"); break;
				case 4: output("`& A quick thrust into his chest, the `%Black Knight `&cannot breathe anymore and concedes defeat!"); break;
				case 5: output("`& A hard blow to his head, the `%Black Knight `&falls to the ground!"); break;
				case 6: output("`& As a final insult, you trip the `%Black Knight `& and he tumbles to the ground!"); break;
			}
			output("`n`n This training session has earned you `^ %s `& experience.",$exp);
			$session['user']['turns']-=1;
			$session['user']['experience'] += $exp;
			if ($playerdk < $dkgems){
				$session['user']['gold'] -= $feegold;
				debuglog(" paid $feegold gold to use Clan training room`0");
			}else{
				$session['user']['gems'] -= $feegems;
				debuglog(" paid $feegems gems to use Clan training room`0");
			}
			increment_module_pref("fighttoday",1);
			increment_module_pref("fighttotal",1);
			increment_module_pref("daysleft",get_module_setting("days"));
			villagenav();
		}else{
			if($defeat){
			tlschema("nav");
			addnav(" bad news! ");
			addnav("(D) Daily news","news.php");
			tlschema();
			addnews("`0".$session['user']['name']."`# was found lying in the alley behind Clan Halls.`0");
			$session['user']['alive']=true;
			$session['user']['hitpoints']=1;
			output("`n`n`& You are beaten up really bad by the trainer.");
			output("`n`n`3 A swift kick in your ribs is the last you remember. ");
			output("`n`n`^ Better luck next time! `n");
			page_footer();
			}else{
		 		fightnav(false,false,"runmodule.php?module=trainingroom");
			}
		}
		if ($victory || $defeat) {
			unsuspend_buffs('allowintrain',"`&You may now make use of your buffs again!`0`n");
		}
	}
page_footer();
}
?>