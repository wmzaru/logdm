<?php

function clanadminapproval_getmoduleinfo() {
    $info = array(
        "name"=>"Clan Approval",
        "author"=>"<a href=http://www.sixf00t4.com>`^Sixf00t4</a>",
        "version"=>"20070829b",
        "vertxtloc"=>"http://www.legendofsix.com/",
        "category"=>"Clan",
        "download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=1202",
        "prefs-clans"=>array(
            "appstatus"=>"Is this clan approved?,bool|0",
            ),
    );
    return $info;
}


function clanadminapproval_install() {
    if (!is_module_installed('clanadminapproval')){
        output("`n`c`b`Qclanadminapproval Module - Installed`0`b`c");
    }else{
        output("`n`c`b`Qclanadminapproval Module - Updated`0`b`c");
    }
    module_addhook("footer-clan");
    module_addhook("superuser");
    return true;
}

function clanadminapproval_uninstall() {
    output("`n`c`b`Qclanadminapproval Module - Uninstalled`0`b`c");
    return true;
}

function clanadminapproval_dohook($hookname,$args) {
    global $session;
    switch ($hookname) {
        case "footer-clan":
            if($session['user']['clanid']>0 && get_module_objpref("clans",$session['user']['clanid'], "appstatus","clanadminapproval")<1) set_module_objpref("clans",$session['user']['clanid'], "appstatus",0,"clanadminapproval");
            if ($session['user']['clanid']!=0 && get_module_objpref("clans",$session['user']['clanid'], "appstatus","clanadminapproval")==0) {
                redirect("runmodule.php?module=clanadminapproval&op=wait");
            }elseif($op=="new" && $session['user']['clanid']>0){
                output("`n`n%s has handed your form to the admins to mandate.  You will get a YOM on their consent.",getsetting('clanregistrar','`%Karissa'));
            }
        break;

        case "superuser":
            $sql = "SELECT * FROM ".db_prefix('module_objprefs')." WHERE modulename='clanadminapproval' and objtype='Clans' and setting='appstatus' and value<1";
            $result = db_query($sql);
            $apps=db_num_rows($result);
            addnav(array("Process clan applications (%s)",$apps),"runmodule.php?module=clanadminapproval&op=su");
        break;
        }
    return $args;
}

function clanadminapproval_run() {
    global $session;
    
    $op = httpget('op');
    $cid = httpget('cid');
    page_header("Clan Approval");
    switch ($op) {
        case "su":
            
            addnav("Back to the grotto","superuser.php");
            
            $sql = "SELECT objid FROM ".db_prefix('module_objprefs')." WHERE modulename='clanadminapproval' and objtype='Clans' and setting='appstatus' and value=0";
            $result = db_query($sql);
            $name=translate_inline("Name");
            $approve=translate_inline("Approve");
            $deny=translate_inline("Deny");
            $leader=translate_inline("Leader");
            $apps=translate_inline("Applicants");
            $action=translate_inline("Action");
            output("results: %s`n`n",db_num_rows($result));
            rawoutput("<table align=center border='0' cellpadding='2' cellspacing='0'><tr class='trhead'><td align=center>$action</td><td align=center>$name</td><td align=center>$leader</td><td align=center>$apps</td></tr>");            
            while ($row = db_fetch_assoc($result)) {
                $clanid=$row['objid'];
                $sql = "SELECT * FROM ".db_prefix('clans')." WHERE clanid=$clanid";
                $result1 = db_query($sql);
                $row1=db_fetch_assoc($result1);

                $cname=$row1['clanname'];

                $sql2 = "SELECT name FROM ".db_prefix('accounts')." WHERE clanid=$clanid and clanrank='".CLAN_FOUNDER."' Limit 1";
                $result2 = db_query($sql2);
                $row2=db_fetch_assoc($result2);              
                $cleader=$row2['name'];
                
                $sql3 = "SELECT count(`acctid`) as `c` FROM ".db_prefix('accounts')." WHERE clanid=$clanid and clanrank='".CLAN_APPLICANT."'";
                $result3 = db_query($sql3);                
                $row3=db_fetch_assoc($result3); 
                $napps=$row3['c'];
                
                rawoutput("<tr class='".($i%2?"trlight":"trdark")."'><td align=center><font color=red>[</font><a href=\"runmodule.php?module=clanadminapproval&op=approve&clanid=$clanid\">$approve</a><font color=red>]</font> - <font color=red>[</font><a href=\"runmodule.php?module=clanadminapproval&op=deny&clanid=$clanid\">$deny</a><font color=red>]</font></td><td align=center>");
                output("%s",$cname);
                rawoutput("</td><td align=center>");
                output("%s",$cleader);
                rawoutput("</td><td align=center>$napps</td></tr>");
                addnav("","runmodule.php?module=clanadminapproval&op=deny&clanid=$clanid");
                addnav("","runmodule.php?module=clanadminapproval&op=approve&clanid=$clanid");
            }
            output("</table>",true);
        break;

        case "approve":

            $clanid = httpget('clanid');
            
            $sql = "select acctid from ".db_prefix("accounts")." where clanid=$clanid and clanrank>1 limit 1";
            $result = db_query($sql);
            $row=db_fetch_assoc($result);
            $leader = $row['acctid'];
            
            require_once("lib/systemmail.php");
            systemmail($leader,"`^Clan Application Approved`0","Your clan application has been reviewed and approved.  ".getsetting('clanregistrar','`%Karissa')." is glad to welcome you and your members to the clan halls.","0"); 
            output("A YOM has been sent to the leader to let them know of your decision.");
            addnav("Back to the Grotto","superuser.php");
            set_module_objpref("clans",$clanid,"appstatus",1,"clanadminapproval");
        
        break;

        case "deny":
           
            $clanid = httpget('clanid');
            
            $sql = "select acctid from ".db_prefix("accounts")." where clanid=$clanid and clanrank>1 limit 1";
            $result = db_query($sql);
            $row=db_fetch_assoc($result);
            $leader = $row['acctid'];
            
            if(is_module_active("payintoguilds") && get_module_setting("sameprice","payintoguilds")==0 && get_module_objpref("Clans",$clanid,"bwp","payintoguilds")==1){
                $gold = get_module_setting("goldcost","payintoguilds");
                $gems = get_module_setting("gemcost","payintoguilds");
            }else{
                $gold = getsetting("goldtostartclan",10000);
                $gems = getsetting("gemstostartclan",15);
            }
            $sql = "UPDATE ".db_prefix("accounts")." SET gold=gold+$gold,gems=gems+$gems WHERE acctid=$leader";
            db_query($sql);            
            debuglog("account $leader was given back $gold gold and $gems gems for having their guild denied",$leader);
            require_once("lib/systemmail.php");
            systemmail($leader,"`^Clan Application Denied`0","Your clan application has been reviewed and shredded.  If you wish to try again, please ensure that you meet all requirements.","0"); 
            output("A YOM has been sent to the leader to let them know of your decision.");
            addnav("Back to the Grotto","superuser.php");
            $sql = "UPDATE ".db_prefix("accounts")." SET clanid=0,clanrank=".CLAN_APPLICANT.",clanjoindate='0000-00-00 00:00:00' WHERE clanid=$clanid";
            db_query($sql);
            $sql = "DELETE FROM " . db_prefix("clans") . " WHERE clanid=$clanid";
            db_query($sql);
            $sql = "DELETE FROM " . db_prefix("module_objprefs") . " WHERE objid=$clanid and objtype='Clans'";
            db_query($sql);       
       break;
        
        case "wait":
            addnav(array("Back to %s",$session['user']['location']),"village.php");
            output("Your guild is still pending approval.  You will get a YOM once approved.  You should try to get applicants to apply now, so that admins see that there is a strong interest in having this guild approved.");
        break;        
    }
    page_footer();
}

?>