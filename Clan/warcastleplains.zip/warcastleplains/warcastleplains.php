<?php
function warplains_getmoduleinfo(){
	$info = array(
		"name"=>"War Castle Plains",
		"version"=>"1.0",
		"author"=>"`^CortalUX",
		"category"=>"Clan add-on",
		"override_forced_nav"=>true,
		"download"=>"http://dragonprime.net/users/CortalUX/clanwarpack.zip",
		"settings"=>array(
			"War Castle Plains - General,title",
			"allowedIn"=>"Are the plains enterable?,bool|1",
			"(if the clanwar module is active you won't be allowed in if a war isn't on),note",
			"War Castle Plains - Visual,title",
			"mCol"=>"Id for mountain colour?",
			"War Castle Plains - Mechanics,title",
		),
		"prefs"=>array(
			"War Castle Plains - General,title",
			"warban"=>"Is this user banned from making war?,bool|0",
			"curloc"=>"Current location,viewonly|1,1,1",
		),
		"prefs-clan"=>array(
			"War Castle Plains - General,title",
			"ident"=>"Ident?,viewonly|",
			"size"=>"What size castle?,enum,None,0,Small,1,Medium,2,Large,3|0",
			"catapult"=>"What size catapult?,enum,None,0,Small,1,Medium,2,Large,3|0",
			"cannonballs"=>"How many Cannon Balls?,int|0",
			"health"=>"Health?,int|0",
			"invade"=>"Castle been invaded?,bool|0",
			"cturns"=>"If invaded- how many turns till the castle gets demolished?",
			"mining"=>"Mining stat?,int|1",
			"tin"=>"Tin?,int|0",
			"copper"=>"Copper?,int|0",
			"bronze"=>"Bronze?,int|0",
			"silver"=>"Silver?,int|0",
			"gold"=>"Gold?,int|0",
		),
		"requires"=>array(
			"cities" => "1.0|Eric Stevens, core_module",
		),
	);
	return $info;
}

function warplains_install(){
	global $session;
	if (!is_module_active('warplains')){
		debug("Installing War Plains Module.");
	}else{
		debug("Updating War Plains Module.");
	}
	if (!db_table_exists(db_prefix("warplains"))){
		$sql = "CREATE TABLE ".db_prefix("warplains")." (";
  	$sql .= "`clanid` int(11) NOT NULL default '1',";
  	$sql .= "`ident` int(11) NOT NULL default '1',";
  	$sql .= "`where` varchar(100) NOT NULL default '',";
  	$sql .= "PRIMARY KEY  (`clanid`)";
		$sql .= ") TYPE=MyISAM;";
		db_query($sql); 
	}
	module_addhook("footer-clan");
	module_addhook("charstats");
	module_addhook("biostat");
	module_addhook("footer-hof");
	module_addhook("travel");
	module_addhook("village");
	module_addhook("validlocation");
	return true;
}

function warplains_uninstall(){
	debug("Uninstalling War Plains Module.");
	$sql = "DROP TABLE ".db_prefix("warplains");
	db_query($sql);
	return true;
}

function warplains_dohook($hookname,$args){
	global $session;
	$place = "The War Plains";
	switch($hookname){
		case "footer-hof":
			if (is_module_active("clanwar")&&get_module_setting("warstat","clanwar")==2&&is_module_installed("cities")||get_module_setting('allowedIn')==1&&is_module_installed("cities")) {
				addnav("Clan Rankings");
				addnav("Strongest Castle","runmodule.php?module=warplains&op=hof&stat=strong",false,true);
				addnav("Best Castle Invaders","runmodule.php?module=warplains&op=hof&stat=invaders",false,true);
				addnav("Best Miners","runmodule.php?module=warplains&op=hof&stat=mine",false,true);
				addnav("Best Castle Demolishers","runmodule.php?module=warplains&op=hof&stat=demo",false,true);
				addnav("Biggest Castle","runmodule.php?module=warplains&op=hof&stat=big",false,true);
			}
		break;
		case "travel":
			if (warplains_test()) {
					addnav("Safer Travel");
					if ($session['user']['location']!=$place){
						addnav("Enter the War Plains","runmodule.php?module=cities&op=travel&city=$place");
					}
					addnav("More Dangerous Travel");
					if ($session['user']['superuser'] & SU_EDIT_USERS){
						addnav("Superuser");
						addnav("Enter the War Plains","runmodule.php?module=cities&op=travel&city=$place&su=1");
					}	
			}
		break;
		case "village":
			if ($session['user']['location']==$place) {
				redirect("runmodule.php?module=warplains&op=enter");
			}
		break;
		case "validlocation":
			if (is_module_active("cities")&&warplains_test()) {
				$args[$place]="plains-war";
			}
		 break;
	}
	page_footer();
}

function warplains_run(){
	global $session;
	$op = httpget("op");
	if ($op!='hof') page_header("The Plains of War");
	switch($op){
		case "enter":
		break;	
		case "hof":
			popup_header('Hall of Fame');
			warplains_hof();
			popup_footer();
		break;
	}
	if ($op!='hof') page_footer();
}

function warplains_test() {
	$t = false;
	if (is_module_active("clanwar")) {
		if (get_module_setting("warstat","clanwar")==2) {
			$t = true;
		}
	} else {
		if (is_module_installed("cities")||is_module_installed("worldmap")) {
			$t = true;
		}
	}
	if (get_module_pref("warban")==1) {
		$t = false;
	}
	return $t;
}

function warplains_build($clan=0,$x=0,$y=0,$z=0){
	global $session;
	$ident = e_rand(1000,9999);
	db_query("INSERT INTO ".db_prefix("warplains")." SET clanid='".$session['user']['clanid']."',ident='$ident',where='$x|$y|$z'");
	set_module_objpref('clans',$session['user']['clanid'],'ident',$ident);
}

function warplains_here($x=0,$y=0,$z=0){
	global $session;
  $sql = "SELECT clanid,ident FROM ".db_prefix("warplains")." WHERE where='$x|$y|$z'";
	$result = db_query($sql);
	if (db_num_rows($result)==0||db_num_rows($result)>1) {
		$t = 0;
	} else {
		$result = db_fetch_assoc($result);
		if ($result['ident']==get_module_objpref('clans',$result['clanid'],'ident')) {
			$t = $result['clanid'];
		} else {
			$t = 0;
		}
	}
	return $t;
}

function warplains_demolish($x=0,$y=0,$z=0,$clan=0){
	global $session;
	set_module_objpref('clans',$clan,'ident','');
	$sql = db_query("DELETE FROM ".db_prefix("warplains")." WHERE where='$x|$y|$z',clanid='$clan'")
	$result = db_query($sql);
	return $t;
}

function warplains_data($x=0,$y=0,$z=0,$type=false) {
	global $session;
	$loc = str_replace(',','|',get_module_pref('curloc'));
	$mcol = "#999999";
	$gras = "#669900";
	$cast = "#DDDD33";
	$curloc = "#FF9900";
	$text = "";
	if ($type===false) {
		$col = $mcol;
	} else {
		$col = $gras;
	}
	if (warplains_here($x,$y,$z)!=0) {
		$col = $cast;
		$sql = "SELECT * FROM " . db_prefix("clans") . " WHERE clanid='".warplains_here($x,$y,$z)."'";
		$result = db_query_cached($sql, "clandata-$detail", 3600);
		$row = db_fetch_assoc($result1);
		$clan = translate_inline('Clan');
		$text = "`^".$clan.":`n`@".$row['clanshort']."";
	}
	if ($loc == "$x|$y|$z") {
		$col = $curloc;
	}
	output_notl("<td color='%s'>%s</td>",$col,$text,true);
}
?>