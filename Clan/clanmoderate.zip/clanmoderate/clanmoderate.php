<?php
/*
Details:
 * This is a module for Clans to allow their Clans to moderate themselves
*/
require_once("lib/datetime.php");
require_once("lib/sanitize.php");
require_once("lib/http.php");
require_once("lib/systemmail.php");
require_once("lib/villagenav.php");

function clanmoderate_getmoduleinfo(){
	$info = array(
		"name"=>"Clan Moderation",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"download"=>"http://dragonprime.net/users/CortalUX/clanmoderate.zip",
		"author"=>"`@CortalUX",
		"version"=>"1.0",
		"category"=>"Clan",
		"settings"=>array(
			"Clan Moderation - General Settings,title",
			"aWarning"=>"Show the warning string telling users that deletions are logged?,bool|1",
		),
		"requires"=>array(
			"clanoptions"=>"1.5|`@CortalUX, http://dragonprime.net/users/CortalUX/clanoptions.zip",
		),
	);
	return $info;
}

function clanmoderate_install(){
	if (!is_module_active('clanmoderate')){
		output("`n`c`b`QClan Moderation Module - Installed`0`b`c");
	}else{
		output("`n`c`b`QClan Moderation Module - Updated`0`b`c");
	}
	module_addhook("clanoptions-admin-text");
	return true;
}
function clanmoderate_uninstall(){
	output("`n`c`b`QClan Moderation Module - Uninstalled`0`b`c");
	return true;
}
function clanmoderate_dohook($hookname, $args){
	global $session;
	$clan = $session['user']['clanid'];
	switch($hookname){
		case "clanoptions-admin-text":
			addnav("Clan Moderation");
			addnav("Moderate","runmodule.php?module=clanmoderate&area=clan-$clan");
		break;
	}
 	return $args;
}

function clanmoderate_run() {
	global $session;
	tlschema("moderate");
	clanmoderate_addcommentary();
	addnav("Navigation");
	villagenav();
	addnav("Clan Options","runmodule.php?module=clanoptions&op=admin");
	addnav("Sections");
	
	$op = httpget("op");
	if ($op=="commentdelete"){
		$comment = httppost('comment');
		if (!isset($comment) || !is_array($comment)) $comment = array();
		$sql = "SELECT " .
			db_prefix("commentary").".*,".db_prefix("accounts").".name,".
			db_prefix("accounts").".login, ".db_prefix("accounts").".clanrank,".
			db_prefix("clans").".clanshort FROM ".db_prefix("commentary").
			" INNER JOIN ".db_prefix("accounts")." ON ".
			db_prefix("accounts").".acctid = " . db_prefix("commentary").
			".author LEFT JOIN ".db_prefix("clans")." ON ".
			db_prefix("clans").".clanid=".db_prefix("accounts").
			".clanid WHERE commentid IN ('".join("','",array_keys($comment))."')";
		$result = db_query($sql);
		$invalsections = array();
		while ($row = db_fetch_assoc($result)){
			$sql = "INSERT LOW_PRIORITY INTO ".db_prefix("moderatedcomments").
				" (moderator,moddate,comment) VALUES ('{$session['user']['acctid']}','".date("Y-m-d H:i:s")."','".addslashes(serialize($row))."')";
			db_query($sql);
			$invalsections[$row['section']] = 1;
		}
		$sql = "DELETE FROM " . db_prefix("commentary") . " WHERE commentid IN ('" . join("','",array_keys($comment)) . "')";
		db_query($sql);
		foreach($invalsections as $key=>$dummy) {
			invalidatedatacache("comments-$key");
		}
		//update moderation cache
		invalidatedatacache("comments-or11");
		output("`n`@`b`cThose comments were deleted.`c`b`n");
		if (get_module_setting('aWarning')==1) output("`c`b`\$REMEMBER: `QAll comment deletions `iare`i logged by admin.`b`c");
	}
	if (httpget('area')==''&&httpget('iarea')==''||httpget('area')=="' or '1'='1"||$section=="' or '1'='1"||httpget('iarea')=="' or '1'='1") {
		httpset("area", "clan-{$session['user']['clanid']}",true);
		$section="clan-{$session['user']['clanid']}";
	}
	
	$seen = httpget("seen");
	if ($seen>""){
		$session['user']['recentcomments']=$seen;
	}
	$area = httpget('area');
	if ($area==''&&httpget('iarea')!='') $area=httpget('iarea');
	page_header("Clan Comment Moderation");
	$link = "runmodule.php?module=clanmoderate" . ($area ? "&area=$area" : "");
	$refresh = translate_inline("Refresh");
	rawoutput("<form action='$link' method='POST'>");
	rawoutput("<input type='submit' class='button' value='$refresh'>");
	rawoutput("</form>");
	addnav("", "$link");
	if ($area==""){
		clanmoderate_talkform("X","says");
		clanmoderate_viewcommentary("' or '1'='1","X",100);
	}else{
		clanmoderate_viewcommentary($area,"X",100);
		clanmoderate_talkform($area,"says");
	}
	
	tlschema("commentary");
	$sql = "SELECT clanname,clanshort FROM " . db_prefix("clans") . " WHERE clanid={$session['user']['clanid']}";
	$result = db_query($sql);
	tlschema("notranslate");
	$row=db_fetch_assoc($result);
	addnav(array("<%s> %s %s", $row['clanshort'], $row['clanname'], translate_inline("Main Hall")),"runmodule.php?module=clanmoderate&area=clan-{$session['user']['clanid']}");
	tlschema();
	$mods = array("clan"=>$session['user']['clanid'],"clanname"=>$row['clanname'],"clanshort"=>$row['clanshort']);
	$mods = modulehook("clanmoderate", $mods);
	unset($mods['clan'],$mods['clanname'],$mods['clanshort']);
	reset($mods);
	tlschema("notranslate");
	foreach ($mods as $area=>$name) {
		addnav($name, "runmodule.php?module=clanmoderate&area=$area");
	}
	tlschema();
	page_footer();
}

$comsecs = array();
function clanmoderate_commentarylocs() {
	global $comsecs, $session;
	if (is_array($comsecs) && count($comsecs)) return $comsecs;
	$sql = "SELECT clanname,clanshort FROM " . db_prefix("clans") . " WHERE clanid={$session['user']['clanid']}";
	$result = db_query($sql);
	// these are proper names and shouldn't be translated.
	tlschema("notranslate");
	$row=db_fetch_assoc($result);
	$area="clan-".$session['user']['clanid'];
	$comsecs[$area]="<{$row['clanshort']}> {$row['clanname']} ".translate_inline("Main Hall");
	tlschema();
	$comsecs['clan']=$session['user']['clanid'];
	$comsecs['clanname']=$row['clanname'];
	$comsecs['clanshort']=$row['clanshort'];
	$comsecs = modulehook("clanmoderate", $comsecs);
	unset($comsecs['clan'],$comsecs['clanname'],$comsecs['clanshort']);
	rawoutput(tlbutton_clear());
	return $comsecs;
}

function clanmoderate_addcommentary() {
	global $session;
	$section = httppost('section');
	$talkline = httppost('talkline');
	$schema = httppost('schema');
	$comment = trim(httppost('insertcommentary'));
	$counter = httppost('counter');
	if (array_key_exists('commentcounter',$session) && $session['commentcounter']==$counter)
		if ($section || $talkline || $comment)
			clanmoderate_injectcommentary($section, $talkline, $comment, $schema);
}

function clanmoderate_injectrawcomment($section, $author, $comment) {
	$sql = "INSERT INTO " . db_prefix("commentary") . " (postdate,section,author,comment) VALUES ('".date("Y-m-d H:i:s")."','$section',$author,\"$comment\")";
	db_query($sql);
	if (db_insert_id()%50==0 && (int)getsetting("expirecontent",180)>0){
		$sql = "DELETE FROM " . db_prefix("commentary") . " WHERE postdate<'".date("Y-m-d H:i:s",strtotime("-".getsetting("expirecontent",180)." days"))."'";
		db_query($sql);
		require_once("lib/gamelog.php");
		gamelog("Deleted ".db_affected_rows()." old comments.","comment expiration");
	}
	invalidatedatacache("comments-{$section}");
	// invalidate moderation screen also.
	invalidatedatacache("comments-or11");
}

function clanmoderate_injectcommentary($section, $talkline, $comment, $schema=false) {
	global $session,$doublepost, $translation_namespace;
	if ($schema===false) $schema=$translation_namespace;
	tlschema("commentary");
	$doublepost=0;
	if ($comment !="") {
		$commentary = str_replace("`n","",soap($comment));
		$y = strlen($commentary);
		for ($x=0;$x<$y;$x++){
			if (substr($commentary,$x,1)=="`"){
				$colorcount++;
				if ($colorcount>=getsetting("maxcolors",10)){
					$commentary = substr($commentary,0,$x).color_sanitize(substr($commentary,$x));
					$x=$y;
				}
				$x++;
			}
		}

		$args = array('commentline'=>$commentary, 'commenttalk'=>$talkline);
		$args = modulehook("commentary", $args);
		$commentary = $args['commentline'];
		$talkline = $args['commenttalk'];
		tlschema($schema);
		$talkline = translate_inline($talkline);
		tlschema();

		$commentary = preg_replace("'([^[:space:]]{45,45})([^[:space:]])'","\\1 \\2",$commentary);

		if ($talkline!="says" // do an emote if the area has a custom talkline and the user isn't trying to emote already.
		&& substr($commentary,0,1)!=":" 
		&& substr($commentary,0,2)!="::" 
		&& substr($commentary,0,3)!="/me") 
			$commentary = ":`3$talkline, \\\"`#$commentary`3\\\"";
		$sql = "SELECT comment,author FROM " . db_prefix("commentary") . " WHERE section='$section' ORDER BY commentid DESC LIMIT 1";
		$result = db_query($sql);
		$row = db_fetch_assoc($result);
		db_free_result($result);
		if ($row['comment']!=stripslashes($commentary) ||
				$row['author']!=$session['user']['acctid']){
			clanmoderate_injectrawcomment($section, $session['user']['acctid'], $commentary);
			$session['user']['laston']=date("Y-m-d H:i:s");
		} else {
			$doublepost = 1;
		}
	}
	tlschema();
}

function clanmoderate_viewcommentary($section="",$message="Interject your own commentary?",$limit=10,$talkline="says",$schema=false) {
 	global $session,$REQUEST_URI,$doublepost, $translation_namespace;
	if (httpget('area')==''&&httpget('iarea')==''||httpget('area')=="' or '1'='1"||$section=="' or '1'='1"||httpget('iarea')=="' or '1'='1") {
		httpset("area", "clan-{$session['user']['clanid']}",true);
		$section="clan-{$session['user']['clanid']}";
	}
	if (httpget('iarea')!='') $section=httpget('iarea');
	if ($schema === false)
		$schema=$translation_namespace;
	tlschema("commentary");

	$linkbios=true;

	if ($doublepost) output("`\$`bDouble post?`b`0`n");

	if ((int)getsetting("expirecontent",180)>0 && e_rand(1,1000)==1){
		$sql = "DELETE FROM " . db_prefix("commentary") . " WHERE postdate<'".date("Y-m-d H:i:s",strtotime("-".getsetting("expirecontent",180)." days"))."'";
		db_query($sql);
	}

	$clanrankcolors=array("`!","`#","`^","`&");

	$com=(int)httpget("comscroll");
	$cc = false;
	if (httpget("comscroll") !==false && (int)$session['lastcom']==$com+1)
		$cid = (int)$session['lastcommentid'];
	else
		$cid = 0;

	$session['lastcom'] = $com;

	if ($com > 0 || $cid > 0) {
		// Find newly added comments.
		$sql = "SELECT COUNT(commentid) AS newadded FROM " .
			db_prefix("commentary") . " LEFT JOIN " .
			db_prefix("accounts") . " ON " .
			db_prefix("accounts") . ".acctid = " .
			db_prefix("commentary"). ".author WHERE section='$section' AND " .
			db_prefix("accounts").".locked=0 AND commentid > '$cid'";
		$result = db_query($sql);
		$row = db_fetch_assoc($result);
		$newadded = $row['newadded'];
	} else {
		$newadded = 0;
	}

	$commentbuffer = array();
	if ($cid == 0) {
		$sql = "SELECT ". db_prefix("commentary") . ".*, " .
			db_prefix("accounts").".name, " .
			db_prefix("accounts").".login, " .
			db_prefix("accounts").".clanrank, " .
			db_prefix("clans") .  ".clanshort FROM " .
			db_prefix("commentary") . " INNER JOIN " .
			db_prefix("accounts") . " ON " .
			db_prefix("accounts") .  ".acctid = " .
			db_prefix("commentary"). ".author LEFT JOIN " .
			db_prefix("clans") . " ON " .
			db_prefix("clans") . ".clanid=" .
			db_prefix("accounts") .
			".clanid WHERE section = '$section' AND " .
			db_prefix("accounts") .
			".locked=0 ORDER BY commentid DESC LIMIT " .
			($com*$limit).",$limit";
		if ($com==0)
			$result = db_query_cached($sql,"comments-{$section}");
		else
			$result = db_query($sql);
		while($row = db_fetch_assoc($result)) $commentbuffer[] = $row;
	} else {
		$sql = "SELECT " . db_prefix("commentary") . ".*, " .
			db_prefix("accounts").".name, " .
			db_prefix("accounts").".login, " .
			db_prefix("accounts").".clanrank, " .
			db_prefix("clans").".clanshort FROM " .
			db_prefix("commentary") . " INNER JOIN " .
			db_prefix("accounts") . " ON " .
			db_prefix("accounts") . ".acctid = " .
			db_prefix("commentary"). ".author LEFT JOIN " .
			db_prefix("clans") . " ON " . db_prefix("clans") . ".clanid=" .
			db_prefix("accounts") .
			".clanid WHERE section = '$section' AND " .
			db_prefix("accounts") .
			".locked=0 AND commentid > '$cid' " . 
			"ORDER BY commentid ASC LIMIT $limit";
		$result = db_query($sql);
		while ($row = db_fetch_assoc($result)) $commentbuffer[] = $row;
		$commentbuffer = array_reverse($commentbuffer);
	}

	$rowcount = count($commentbuffer);
	if ($rowcount > 0)
		$session['lastcommentid'] = $commentbuffer[0]['commentid'];
	else
		$session['lastcommentid'];

	$counttoday=0;
	for ($i=0; $i < $rowcount; $i++){
		$row = $commentbuffer[$i];
		$row['comment'] = comment_sanitize($row['comment']);
		$commentids[$i] = $row['commentid'];
		if (date("Y-m-d",strtotime($row['postdate']))==date("Y-m-d")){
			if ($row['name']==$session['user']['name']) $counttoday++;
		}
		$x=0;
		$ft="";
		for ($x=0;strlen($ft)<3 && $x<strlen($row['comment']);$x++){
			if (substr($row['comment'],$x,1)=="`" && strlen($ft)==0) {
				$x++;
			}else{
				$ft.=substr($row['comment'],$x,1);
			}
		}

		$link = "bio.php?char=" . rawurlencode($row['login']) .
			"&ret=".URLEncode($_SERVER['REQUEST_URI']);

		if (substr($ft,0,2)=="::")
			$ft = substr($ft,0,2);
		elseif (substr($ft,0,1)==":")
			$ft = substr($ft,0,1);

		$row['comment'] = holidayize($row['comment'],'comment');
		$row['name'] = holidayize($row['name'],'comment');
		if ($row['clanrank'])
			$row['name'] = ($row['clanshort']>""?"{$clanrankcolors[$row['clanrank']]}&lt;`2{$row['clanshort']}{$clanrankcolors[$row['clanrank']]}&gt; `&":"").$row['name'];
		if ($ft=="::" || $ft=="/me" || $ft==":"){
			$x = strpos($row['comment'],$ft);
			if ($x!==false){
				if ($linkbios)
					$op[$i] = str_replace("&amp;","&",HTMLEntities(substr($row['comment'],0,$x)))."`0<a href='$link' style='text-decoration: none'>\n`&{$row['name']}`0</a>\n`& ".str_replace("&amp;","&",HTMLEntities(substr($row['comment'],$x+strlen($ft))))."`0`n";
				else
					$op[$i] = str_replace("&amp;","&",HTMLEntities(substr($row['comment'],0,$x)))."`0`&{$row['name']}`0`& ".str_replace("&amp;","&",HTMLEntities(substr($row['comment'],$x+strlen($ft))))."`0`n";
				$rawc[$i] = str_replace("&amp;","&",HTMLEntities(substr($row['comment'],0,$x)))."`0`&{$row['name']}`0`& ".str_replace("&amp;","&",HTMLEntities(substr($row['comment'],$x+strlen($ft))))."`0`n";
			}
		}
		if (!isset($op) || !is_array($op)) $op = array();
		if (!array_key_exists($i,$op) || $op[$i] == "")  {
			if ($linkbios)
				$op[$i] = "`0<a href='$link' style='text-decoration: none'>`&{$row['name']}`0</a>`3 says, \"`#".str_replace("&amp;","&",HTMLEntities($row['comment']))."`3\"`0`n";
			else
				$op[$i] = "`&{$row['name']}`3 says, \"`#".str_replace("&amp;","&",HTMLEntities($row['comment']))."`3\"`0`n";
			$rawc[$i] = "`&{$row['name']}`3 says, \"`#".str_replace("&amp;","&",HTMLEntities($row['comment']))."`3\"`0`n";
		}
		$session['user']['prefs']['timeoffset'] = round($session['user']['prefs']['timeoffset'],1);

		if (!array_key_exists('timestamp', $session['user']['prefs']))
			$session['user']['prefs']['timestamp'] = 0;

		if ($session['user']['prefs']['timestamp']==1) {
			$time = strtotime("+{$session['user']['prefs']['timeoffset']} hours",strtotime($row['postdate']));
			$s=date("`7[m/d h:ia]`0 ",$time);
			$op[$i] = $s.$op[$i];
		}elseif ($session['user']['prefs']['timestamp']==2) {
			$s=reltime(strtotime($row['postdate']));
			$op[$i] = "`7($s)`0 ".$op[$i];
		}
		if ($message=="X")
			$op[$i]="`0({$row['section']}) ".$op[$i];
		if ($row['postdate']>=$session['user']['recentcomments'])
			$op[$i]="<img src='images/new.gif' alt='&gt;' width='3' height='5' align='absmiddle'> ".$op[$i];
		addnav("",$link);
		$auth[$i] = $row['author'];
		$rawc[$i] = full_sanitize($rawc[$i]);
		$rawc[$i] = htmlentities($rawc[$i], ENT_QUOTES);
	}
	$i--;
	$outputcomments=array();
	$sect="x";

	$moderating=true;

	for (;$i>=0;$i--){
		$out="`0[ <input type='checkbox' name='comment[{$commentids[$i]}]'> ]&nbsp;";
		$matches=array();
		preg_match("/[(]([^)]*)[)]/",$op[$i],$matches);
		$sect=trim($matches[1]);
		if (substr($sect,0,5)!="clan-" || $sect==$section){
			if (substr($sect,0,4)!="pet-"){
				$out.=$op[$i];
				if (!isset($outputcomments[$sect]) ||
						!is_array($outputcomments[$sect]))
					$outputcomments[$sect]=array();
				array_push($outputcomments[$sect],$out);
			}
		}
	}
	addnav("","runmodule.php?module=clanmoderate&op=commentdelete&iarea=$section");
	$mod_Del1 = htmlentities(translate_inline("Delete Checked Comments"));
	
	output_notl("<form action='runmodule.php?module=clanmoderate&op=commentdelete&iarea=$section' method='POST'>",true);
	output_notl("<input type='submit' class='button' value=\"$mod_Del1\">",true);

	//output the comments
	ksort($outputcomments);
	reset($outputcomments);
	$sections = clanmoderate_commentarylocs();
	$needclose = 0;
	$y=0;
	while (list($sec,$v)=each($outputcomments)){
		if ($sec!="x") {
			if($needclose) modulehook("}collapse");
			$y++;
			output_notl("`n<hr><a href='runmodule.php?module=clanmoderate&area=%s'>`b`^%s`0`b</a>`n", $sec, $sections[$sec], true);
			addnav("", "runmodule.php?module=clanmoderate&area=$sec");
			modulehook("collapse{",array("name"=>"com-".$sec));
			$needclose = 1;
		} else {
			modulehook("collapse{",array("name"=>"com-".$section));
			$needclose = 1;
		}
		reset($v);
		while (list($key,$val)=each($v)){
			$args = array('commentline'=>$val);
			$args = modulehook("viewcommentary", $args);
			$val = $args['commentline'];
			output_notl($val, true);
		}
	}
	if ($y==0) {
		rawoutput("<hr>");
		output("`c`b`^There are no comments in this section... get to it, clan!!!`b`c`0");
	}
	if ($needclose) {
		modulehook("}collapse");
		$needclose = 0;
	}

	output_notl("`n");
	rawoutput("<input type='submit' class='button' value=\"$mod_Del1\">");
	rawoutput("</form>");
	output_notl("`n");

	$args = modulehook("insertcomment", array("section"=>$section));
	if (array_key_exists("mute",$args) && $args['mute'] &&
			!($session['user']['superuser'] & SU_EDIT_COMMENTS)) {
		output_notl("%s", $args['mutemsg']);
	} elseif ($counttoday<($limit/2) ||
			($session['user']['superuser']&~SU_DOESNT_GIVE_GROTTO)){
		if ($message!="X"){
			$message="`n`@$message`n";
			output($message);
			clanmoderate_talkform($section,$talkline,$limit,$schema);
		}
	}else{
		$message="`n`@$message`n";
		output($message);
		output("Sorry, you've exhausted your posts in this section for now.`0`n");
	}

	$firstu = translate_inline("&lt;&lt; First Unseen");
	$prev = translate_inline("&lt; Previous");
	$ref = translate_inline("Refresh");
	$next = translate_inline("Next &gt;");
	$lastu = translate_inline("Last Page &gt;&gt;");
	if ($rowcount>=$limit || $cid>0){
		$sql = "SELECT count(*) AS c FROM " . db_prefix("commentary") . " WHERE section='$section' AND postdate > '{$session['user']['recentcomments']}'";
		$r = db_query($sql);
		$val = db_fetch_assoc($r);
		$val = round($val['c'] / $limit + 0.5,0) - 1;
		if ($val>0){
			$first = comscroll_sanitize($REQUEST_URI)."&comscroll=".($val);
			$first = str_replace("?&","?",$first);
			if (!strpos($first,"?")) $first = str_replace("&","?",$first);
			$first .= "&refresh=1";
			output_notl("<a href=\"$first\">$firstu</a>",true);
			addnav("",$first);
		}else{
			output_notl($firstu,true);
		}
		$req = comscroll_sanitize($REQUEST_URI)."&comscroll=".($com+1);
		$req = str_replace("?&","?",$req);
		if (!strpos($req,"?")) $req = str_replace("&","?",$req);
		$req .= "&refresh=1";
		output_notl("<a href=\"$req\">$prev</a>",true);
		addnav("",$req);
	}else{
		output_notl("$firstu $prev",true);
	}
	$last = comscroll_sanitize($REQUEST_URI)."&refresh=1";

	// Okay.. we have some smart-ass (or stupidass, you guess) players
	// who think that the auto-reload firefox plugin is a good way to
	// avoid our timeouts.  Won't they be surprised when I take that little
	// hack away.
	$last .= "&c={$session['counter']}";
	$last .= "-".date("His");

	$last = str_replace("?&","?",$last);
	if (!strpos($last,"?")) $last = str_replace("&","?",$last);
	output_notl("&nbsp;<a href=\"$last\">$ref</a>&nbsp;",true);
	addnav("",$last);
	if ($com>0 || ($cid > 0 && $newadded > $limit)){
		$req = comscroll_sanitize($REQUEST_URI)."&comscroll=".($com-1);
		$req = str_replace("?&","?",$req);
		if (!strpos($req,"?")) $req = str_replace("&","?",$req);
		$req .= "&refresh=1";
		output_notl(" <a href=\"$req\">$next</a>",true);
		addnav("",$req);
		output_notl(" <a href=\"$last\">$lastu</a>",true);
	}else{
		output_notl("$next $lastu",true);
	}
	if (!$cc) db_free_result($result);
	tlschema();
	if ($needclose) modulehook("}collapse");
}

function clanmoderate_talkform($section,$talkline,$limit=10,$schema=false){
	global $REQUEST_URI,$session,$translation_namespace;
	if ($schema===false) $schema=$translation_namespace;
	tlschema("commentary");

	$counttoday=0;
	if (substr($section,0,5)!="clan-"){
		$sql = "SELECT author FROM " . db_prefix("commentary") . " WHERE section='$section' AND postdate>'".date("Y-m-d 00:00:00")."' ORDER BY commentid DESC LIMIT $limit";
		$result = db_query($sql);
		while ($row=db_fetch_assoc($result)){
			if ($row['author']==$session['user']['acctid']) $counttoday++;
		}
		if (round($limit/2,0)-$counttoday <= 0){
			if ($session['user']['superuser']&~SU_DOESNT_GIVE_GROTTO){
				output("`n`)(You'd be out of posts if you weren't a superuser or moderator.)`n");
			}else{
				output("`n`)(You are out of posts for the time being.  Once some of your existing posts have moved out of the comment area, you'll be allowed to post again.)`n");
				return false;
			}
		}
	}
	rawoutput("<script language='JavaScript'>
	function previewtext(t){
		var out = \"<span class=\'colLtWhite\'>".addslashes(appoencode($session['user']['name']))." \";
		var end = '</span>';
		var x=0;
		var y='';
		var z='';
		if (t.substr(0,2)=='::'){
			x=2;
			out += '</span><span class=\'colLtWhite\'>';
		}else if (t.substr(0,1)==':'){
			x=1;
			out += '</span><span class=\'colLtWhite\'>';
		}else if (t.substr(0,3)=='/me'){
			x=3;
			out += '</span><span class=\'colLtWhite\'>';
		}else{
			out += '</span><span class=\'colDkCyan\'>".addslashes(appoencode($talkline)).", \"</span><span class=\'colLtCyan\'>';
			end += '</span><span class=\'colDkCyan\'>\"';
		}
		for (; x < t.length; x++){
			y = t.substr(x,1);
			if (y=='<'){
				out += '&lt;';
				continue;
			}else if(y=='>'){
				out += '&gt;';
				continue;
			}else if (y=='`'){
				if (x < t.length-1){
					z = t.substr(x+1,1);
					if (z=='0'){
						out += '</span>';
					}else if (z=='1'){
						out += '</span><span class=\'colDkBlue\'>';
					}else if (z=='2'){
						out += '</span><span class=\'colDkGreen\'>';
					}else if (z=='3'){
						out += '</span><span class=\'colDkCyan\'>';
					}else if (z=='4'){
						out += '</span><span class=\'colDkRed\'>';
					}else if (z=='5'){
						out += '</span><span class=\'colDkMagenta\'>';
					}else if (z=='6'){
						out += '</span><span class=\'colDkYellow\'>';
					}else if (z=='7'){
						out += '</span><span class=\'colDkWhite\'>';
					}else if (z=='q'){
						out += '</span><span class=\'colDkOrange\'>';
					}else if (z=='!'){
						out += '</span><span class=\'colLtBlue\'>';
					}else if (z=='@'){
						out += '</span><span class=\'colLtGreen\'>';
					}else if (z=='#'){
						out += '</span><span class=\'colLtCyan\'>';
					}else if (z=='$'){
						out += '</span><span class=\'colLtRed\'>';
					}else if (z=='%'){
						out += '</span><span class=\'colLtMagenta\'>';
					}else if (z=='^'){
						out += '</span><span class=\'colLtYellow\'>';
					}else if (z=='&'){
						out += '</span><span class=\'colLtWhite\'>';
					}else if (z=='Q'){
						out += '</span><span class=\'colLtOrange\'>';
					}else if (z==')'){
						out += '</span><span class=\'colLtBlack\'>';
					}
					x++;
				}
			}else{
				out += y;
			}
		}
		document.getElementById(\"previewtext\").innerHTML=out+end+'<br/>';
	}
	</script>
	");
	if ($talkline!="says") $tll = strlen($talkline)+11; else $tll=0;
	$req = comscroll_sanitize($REQUEST_URI)."&comment=1";
	$req = str_replace("?&","?",$req);
	if (!strpos($req,"?")) $req = str_replace("&","?",$req);
	addnav("",$req);
	output_notl("<form action=\"$req\" method='POST' autocomplete='false'>",true);
	output_notl("<input name='insertcommentary' id='commentary' onKeyUp='previewtext(document.getElementById(\"commentary\").value);'; size='40' maxlength='".(200-$tll)."'>",true);
	rawoutput("<input type='hidden' name='talkline' value='$talkline'>");
	rawoutput("<input type='hidden' name='schema' value='$schema'>");
	rawoutput("<input type='hidden' name='counter' value='{$session['counter']}'>");
	$session['commentcounter'] = $session['counter'];
	$sections = clanmoderate_commentarylocs();
	output_notl("<select name='section'>",true);
	foreach ($sections as $key=>$val) {
		$str="<option ";
		if ($key==$section||$key==httpget('iarea')) $str.="selected ";
		$str.="value='$key'>".htmlentities($val)."</option>";
		output_notl($str,true);
	}
	reset($sections);
	$add = translate_inline("Add");
	output_notl("</select><input type='submit' class='button' value='$add'>",true);
	if (round($limit/2,0)-$counttoday < 3){
		output("`)(You have %s posts left today)`n`0",(round($limit/2,0)-$counttoday));
	}
	output_notl("<div id='previewtext'></div></form>",true);
	tlschema();
}
?>