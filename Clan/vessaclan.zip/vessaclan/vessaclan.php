<?php
/*
Details:
 * Based upon Reznarth's Gemshop
 * Cleaned up code, used switches
 * Added a commentary
 * Users now use a <select> range field, so they cannot enter a non-numeric amount, or an illegal amount
 * Money can go into a Clan's vault
 * The Inventory is now clan-local
Version 9.0:
 * Seems stable
Version 9.1:
 * Fixed a bug on line 366, forgot to start the array function
Version 9.2:
 * Moderation Fixed
Version 9.3:
 * Textual Fixes
*/
require_once('lib/villagenav.php');
require_once("lib/commentary.php");
require_once("lib/showform.php");

function vessaclan_getmoduleinfo(){
	$info = array(
		"name"=>"Vessa's Clan Gem Shop",
		"version"=>"9.3",
		"author"=>"`@CortalUX`&, based upon '`#vessa`&' by `#Reznarth`&.",
		"category"=>"Clan",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"download"=>"http://dragonprime.net/users/CortalUX/vessaclan.zip",
		"settings"=>array(
			"Vessa Clan - General Settings,title",
			"clango"=>"Can money go into a Clan's vault?,bool|1",
			"clanfrom"=>"Does Vessa pay out of a Clan's vault?,bool|1",
			"gemcost"=>"Gold needed to buy a Gem?,int|2000",
			"gemsell"=>"Gold paid for selling a Gem?,int|500",
			"gemsdailyb"=>"Maximum Gems allowed to be bought per new day?,int|50",
			"gemsdailys"=>"Maximum Gems allowed to be sold per new day?,int|50",
			"enterlevel"=>"Minimum level needed to enter the Gemshop?,int|8",
			"maxlevel"=>"Maximum level allowed to enter the Gemshop?,int|14",
			"maxmessage"=>"Not allowed/maximum level message?,text|Don't you think it's time to kill the dragon?",
			"The 'geminventory' must now be set individually for each clan.,note",
		),
		"prefs"=>array(
			"Vessa Clan - Preferences,title",
			"gemsbuytoday"=>"How many Gems has this user bought today?,int|0",
			"gemsselltoday"=>"How many Gems has this user sold today?,int|0",
		),
		"prefs-clans"=>array(
			"Vessa Clan - Clan Settings,title",
			"geminventory"=>"Amount of Gems this clan stocks?,int|100",
		),
	);
	return $info;
}

function vessaclan_install(){
	if (!is_module_active('vessclan')){
		output("`n`c`b`QVessa's Clan Gem Shop Module - Installed`0`b`c");
	}else{
		output("`n`c`b`QVessa's Clan Gem Shop Module - Updated`0`b`c");
	}
	module_addhook("newday");
	module_addhook("footer-clan");
	module_addhook("moderate");
	return true;
}

function vessaclan_uninstall(){
	output("`n`c`b`QVessa's Clan Gem Shop Module - Uninstalled`0`b`c");
	return true;
}

function vessaclan_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "newday":
			if ($args['resurrection'] != 'true') {
				set_module_pref("gemsbuytoday",0);
				set_module_pref("gemsselltoday",0);
			}
		break;
		case "footer-clan":
			if ($session['user']['clanrank'] >= CLAN_MEMBER&&httpget('op')=='') {
				addnav("~");
				addnav("Vessa's Clan Gem Exchange","runmodule.php?module=vessaclan");
			}
		break;
		case "moderate":
			$args['vessaclan'] = "Vessa's Clan Gem Exchange";
		break;
	}
	return $args;
}

function vessaclan_run(){
	global $session;
	$op = httpget('op');
	page_header("Vessa's Clan Gem Exchange");
	addnav("Actions");
	$geminventory = get_module_objpref("clans",$session['user']['clanid'],"geminventory");
	$gemcost = get_module_setting("gemcost");
	$gemsell = get_module_setting("gemsell");
	$gemsdailyb = get_module_setting("gemsdailyb");
	$gemsdailys = get_module_setting("gemsdailys");
	$enterlevel = get_module_setting("enterlevel");
	$maxlevel = get_module_setting("maxlevel");
	$maxmessage = get_module_setting("maxmessage");
	addnav("Navigation");
	addnav("Return to your Clan hall","clan.php");
	villagenav();
	addnav("Actions");
	if ($session['user']['level']<$enterlevel) {
		output("`^Vessa `3says, \"`&Come back once you've leveled up, wimpo!`3\"`n`n");
	} elseif ($session['user']['level']>$maxlevel) {
		output_notl($maxmessage);
	} else {
		switch ($op) {
			default:
				if ($op=='') output("`@Looking in one of the rooms of your clan, you find `^Vessa`@!`n");
				else output("`@You walk to the desk, inquiring a bit closer about her services.`n");
				if (is_module_active('clanvault')&&get_module_setting('clango')==1) output("`^Vessa `3tells you, \"`&All money will go to your Clan.`3\"`n");
				if (is_module_active('clanvault')&&get_module_setting('clanfrom')==1) output("`^Vessa `3tells you, \"`&All Gems are paid for out of your Clan's vault.`3\"`n");
				output("`^Vessa `3says, \"`&Gems cost %s Gold, and I'll buy them from you for %s Gold.`3\"`n",$gemcost,$gemsell);
				output("`^Vessa `3specifies, \"`&I'll sell %s more Gems to you today, and I'll buy up to %s more Gems from you.`3\"`n",$gemsdailyb,$gemsdailys);
				output("`^Vessa `3notes, \"`&I've got %s Gems stocked for your Clan.`3\"`n",$geminventory);
				$buy = get_module_pref("gemsbuytoday");
				$sell = get_module_pref("gemsselltoday");
				output("`^Vessa `3informs you, \"`&I've bought %s Gems from you today, and I've sold you %s Gems.`3\"`n",$buy,$sell);
				if (is_module_active('clanvault')) {
					$m = get_module_objpref("clans",$session['user']['clanid'],"vaultgold",'clanvault');
					output("`^Vessa `3informs you, \"`&Your clan has %s Gold in it's vault...`3\"`n",$m);
				}
			break;
			case "talk":
				addcommentary();
				output("`n`n`b`^Walking around the exchange, you hear people discoursing... listening close, you realize that other clans are talking here as well!`b`n");
				viewcommentary("vessaclan","`#Discourse?`@",25,"discourses");
			break;
			case "gembuy":
				$max=(get_module_setting("gemsdailyb") - get_module_pref("gemsbuytoday"));
				if ($session['user']['gold'] < ($max * $gemcost)) {
					while ($session['user']['gold'] < ($max * $gemcost)) {
						$max--;
						if ($max<=0) {
							$max=0;
							continue;
						}
					}
				}
				if ($max>$geminventory&&$max!=0) {
					while ($max>$geminventory&&$max!=0) {
						$max--;
						if ($max<=0) {
							$max=0;
							continue;
						}
					}
				}
				if ($max<=0) {
					output("`^Vessa `3states, \"`&I can't sell any Gems to you.`3\"`n");
					output("`^Vessa `3states, \"`&You might not have enough money, or maybe I've sold you too many...`3\"`n");
					output("`^Vessa `3states, \"`&I might not have enough for your Clan`3\"`n");
				} elseif (get_module_pref("gemsbuytoday")>=get_module_setting("gemsdailyb")) {
					output("`^Vessa `3states, \"`&I can't sell any Gems to you.`3\"`n");
					output("`^Vessa `3states, \"`&I've sold you too many...`3\"`n");
				} else {
					output("`^Vessa `3asks, \"`&How many Gems would you like to buy? I've got `%%s`&!`3\"`n",$geminventory);
					output("`^Vessa `3reminds you, \"`&You've got enough money to buy `%%s`& more Gems.`3\"",$max);
					rawoutput("<br><form action='runmodule.php?module=vessaclan&op=gembuy2' method='post'>");
					$stuff = array(
						"buy"=>"How many?,range,1,".$max.",1|1",
					);
					$b = array(
						"buy"=>1,
					);
					showform($stuff,$b,true);
					$b = translate_inline("Buy!");
					rawoutput(" <input type='submit' class='button' value='$b'></form>");
					addnav("","runmodule.php?module=vessaclan&op=gembuy2");
				}
			break;
			case "gembuy2":
				$max=(get_module_setting("gemsdailyb") - get_module_pref("gemsbuytoday"));
				if ($session['user']['gold'] < ($max * $gemcost)) {
					while ($session['user']['gold'] < ($max * $gemcost)) {
						$max--;
						if ($max<=0) {
							$max=0;
							continue;
						}
					}
				}
				if ($max>$geminventory&&$max!=0) {
					while ($max>$geminventory&&$max!=0) {
						$max--;
						if ($max<=0) {
							$max=0;
							continue;
						}
					}
				}
				$buy = httppost('buy');
				if ($buy < 0) $buy = 0;
				if ($buy >= $max) $buy = ($max);
				if ($session['user']['gold'] < ($buy * $gemcost)) {
					output("`^Vessa`& gives you the finger after you attempt to pay her less than her Gems are worth.`n`n");
				} else {
					$cost=($buy * $gemcost);
					$session['user']['gold']-=$cost;
					$session['user']['gems']+=$buy;
					set_module_pref("gemsbuytoday",get_module_pref("gemsbuytoday")+$buy);
					$m = get_module_objpref("clans",$session['user']['clanid'],"geminventory")-$buy;
					set_module_objpref("clans",$session['user']['clanid'],"geminventory",$m);
					output("`^Vessa`& takes your %s Gold and hands you %s Gems.",$cost, $buy);
					debuglog("spent $cost Gold buying $buy Gems from Vessa");
					if (is_module_active('clanvault')&&get_module_setting('clango')==1) {
						$m = get_module_objpref("clans",$session['user']['clanid'],"vaultgold",'clanvault')+$cost;
						set_module_objpref("clans",$session['user']['clanid'],"vaultgold",$m,'clanvault');
						output("`n`^Vessa`& puts %s Gold in your Clan's Vault.",$cost);
					}
				}
			break;
			case "gemsell":
				$max = $session['user']['gems'];
				$s = get_module_setting("gemsdailys") - get_module_pref("gemsselltoday");
				if ($s<=0||$max==0) {
					$max=0;
				} else {
					if ($max>$s) {
						while ($max>$s) {
							$max--;
							if ($max<=0) {
								$max=0;
								continue;
							}
						}
					}
				}
				if (is_module_active('clanvault')&&get_module_setting('clanfrom')==1&&get_module_objpref("clans",$session['user']['clanid'],"vaultgold",'clanvault')<$gemsell) {
					output("`^Vessa `3states, \"`&I can't buy any Gems from you.`3\"`n");
					output("`^Vessa `3states, \"`&I don't have enough money to pay for them...`3\"`n");
				} elseif ($max<=0) {
					output("`^Vessa `3states, \"`&I can't buy any Gems from you.`3\"`n");
					output("`^Vessa `3states, \"`&You might not have enough Gems, or maybe I've bought too many...`3\"`n");
				} elseif (get_module_pref("gemsselltoday")>=get_module_setting("gemsdailys")) {
					output("`^Vessa `3states, \"`&I can't buy any Gems from you.`3\"`n");
					output("`^Vessa `3states, \"`&I've bought too many...`3\"`n");
				} else {
					if (is_module_active('clanvault')&&get_module_setting('clanfrom')==1&&get_module_objpref("clans",$session['user']['clanid'],"vaultgold",'clanvault')) {
						$m = get_module_objpref("clans",$session['user']['clanid'],"vaultgold",'clanvault');
						$cost = $max * $gemsell;
						if ($cost>$m) {
							while ($cost>$m) {
								$max--;
								$cost-=$gemsell;
								if ($max<=0) {
									$max=0;
									continue;
								}
							}
						}
					}
					if ($max==0) {
						output("`^Vessa `3states, \"`&I can't buy any Gems from you.`3\"`n");
						output("`^Vessa `3states, \"`&I don't have enough money to pay for them...`3\"`n");
					} else {
						output("`^Vessa `3asks, \"`&How many Gems would you like to sell me? I've got `%%s`&!`3\"`n",$geminventory);
						output("`^Vessa `3reminds you, \"`&You can sell up to `%%s`& more Gems.`3\"",$max);
						rawoutput("<br><form action='runmodule.php?module=vessaclan&op=gemsell2' method='post'>");
						$stuff = array(
							"sell"=>"How many?,range,1,".$max.",1|1",
						);
						$s = array(
							"sell"=>1,
						);
						showform($stuff,$s,true);
						$b = translate_inline("Sell!");
						rawoutput(" <input type='submit' class='button' value='$b'></form>");
						addnav("","runmodule.php?module=vessaclan&op=gemsell2");
					}
				}
			break;
			case "gemsell2":
				$max = $session['user']['gems'];
				$s = get_module_setting("gemsdailys") - get_module_pref("gemsselltoday");
				if ($s<=0||$max==0) {
					$max=0;
				} else {
					if ($max>$s) {
						while ($max>$s) {
							$max--;
							if ($max<=0) {
								$max=0;
								continue;
							}
						}
					}
				}
				if (is_module_active('clanvault')&&get_module_setting('clanfrom')==1&&get_module_objpref("clans",$session['user']['clanid'],"vaultgold",'clanvault')) {
					$m = get_module_objpref("clans",$session['user']['clanid'],"vaultgold",'clanvault');
					$cost = $max * $gemsell;
					if ($cost>$m) {
						while ($cost>$m) {
							$max--;
							$cost-=$gemsell;
							if ($max<=0) {
								$max=0;
								continue;
							}
						}
					}
				}
				$sell = httppost('sell');
				if ($sell>$max) $sell=$max;
				if ($session['user']['gems'] < $sell||$sell>$max) {
					output("`^Vessa`& raises her fist at you.`n`n");
				} else {
					$cost=($sell * $gemsell);
					$session['user']['gems']-=$sell;
					$session['user']['gold']+=$cost;
					set_module_pref("gemsselltoday",get_module_pref("gemsselltoday")+$sell);
					$m = get_module_objpref("clans",$session['user']['clanid'],"geminventory")+$sell;
					if (is_module_active('clanvault')&&get_module_setting('clanfrom')==1) {
						$m = get_module_objpref("clans",$session['user']['clanid'],"vaultgold",'clanvault')-$cost;
						set_module_objpref("clans",$session['user']['clanid'],"vaultgold",$m,'clanvault');
						output("`^Vessa`& takes %s Gold from your Clan's Vault.`n",$cost);
					}
					set_module_objpref("clans",$session['user']['clanid'],"geminventory",$m);
					output("`^Vessa`& gives you %s Gold in return for %s Gems.",$cost,$sell);
					debuglog("got $cost Gold selling $sell Gems to Vessa");
				}
			break;
		}
		addnav("Talk to others","runmodule.php?module=vessaclan&op=talk");
		addnav("Inquire Closer","runmodule.php?module=vessaclan&op=desk");
		addnav(array("Buy Gems - %s gp",$gemcost),"runmodule.php?module=vessaclan&op=gembuy");
		addnav(array("Sell Gems - %s gp",$gemsell),"runmodule.php?module=vessaclan&op=gemsell");
	}
	addnav("Navigation");
	addnav("Actions");
	page_footer(); 
}
?>