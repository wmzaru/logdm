<?php
function colliseum_getmoduleinfo(){
	$info = array(
		"name" => "Clan Colliseum",
		"author" => "`b`&Ka`6laza`&ar`b",
		"version" => "1.1",
		"Download" => "http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=1045",
		"category" => "Clan",
		"description" => "Clan Colliseum for battles",
		"settings"=>array(
			"Colliseum, title",
			"name"=>"Arena name,int|The Colliseum",
			"colloc"=>"Where does the Arena appear,location|".getsetting("villagename", LOCATION_FIELDS),
			"list"=>"how many on hof,int|25",

		),
		"prefs"=>array(
			"Colliseum,title",
				"collreg"=>"registered in colliseum,enum,0,no,1,yes,2,attack",
				"cbattleid"=>"current battleid,int,",
				"These are for coding purposes only,note",
				"clasthit"=>"amount of last hit,int|0",
				"cbonushit"=>"amount of bonus hit,int|0",
				"idno"=>"fighters id number,int",
				"colldate"=>"date round starts,int",
		),
		"prefs-clans"=>array(
		"clanwins"=>"clan points in Colliseum,viewonly|0",
		),
		);
		return $info;
}
function colliseum_install(){
	require_once("lib/tabledescriptor.php");
	$colliseum = array(
		'battleid'=>array('name'=>'battleid', 'type'=>'int unsigned',	'extra'=>'not null auto_increment'),
		'type'=>array('name'=>'type', 'type'=>'int unsigned',	'extra'=>'not null'),
		'id1'=>array('name'=>'id1', 'type'=>'int unsigned',	'extra'=>'not null'),
		'id2'=>array('name'=>'id2', 'type'=>'int unsigned',	'extra'=>'not null'),
		'id3'=>array('name'=>'id3', 'type'=>'int unsigned', 'extra'=>'not null'),
		'id4'=>array('name'=>'id4', 'type'=>'int unsigned', 'extra'=>'not null'),
		'id5'=>array('name'=>'id5', 'type'=>'int unsigned', 'extra'=>'not null'),
		'id6'=>array('name'=>'id6', 'type'=>'int unsigned', 'extra'=>'not null'),
		'id7'=>array('name'=>'id7', 'type'=>'int unsigned',	'extra'=>'not null'),
		'id8'=>array('name'=>'id8', 'type'=>'int unsigned',	'extra'=>'not null'),
		'id9'=>array('name'=>'id9', 'type'=>'int unsigned',	'extra'=>'not null'),
		'id10'=>array('name'=>'id10', 'type'=>'int unsigned',	'extra'=>'not null'),
		'clan'=>array('name'=>'clan', 'type'=>'int unsigned',	'extra'=>'not null'),
		'creature'=>array('name'=>'creature', 'type'=>'text',	'extra'=>'not null'),
		'chp'=>array('name'=>'chp', 'type'=>'int unsigned',	'extra'=>'not null'),
		'catk'=>array('name'=>'catk', 'type'=>'int unsigned',	'extra'=>'not null'),
		'cdef'=>array('name'=>'cdef', 'type'=>'int unsigned',	'extra'=>'not null'),
		'day'=>array('name'=>'day', 'type'=>'int unsigned',	'extra'=>'not null'),
		'inprogress'=>array('name'=>'inprogress', 'type'=>'int unsigned',	'extra'=>'not null'),
		'key-PRIMARY'=>array('name'=>'PRIMARY', 'type'=>'primary key',	'unique'=>'1', 'columns'=>'battleid'));
		synctable(db_prefix('colliseum'), $colliseum, true);
	module_addhook("changesetting");
	module_addhook("village");
	module_addhook("header-hof");
	return true;
}
function colliseum_uninstall(){
   debug("Dropping colliseum table");
   $sql = "DROP TABLE IF EXISTS " . db_prefix("colliseum");
   db_query($sql);
   return true;
}
function colliseum_dohook($hookname,$args){
	global $session;
	$reg=get_module_pref("collreg");
	$id = $session['user']['acctid'];
	switch ($hookname){
		case "changesetting":
			if ($args['setting'] == "villagename") {
			if ($args['old'] == get_module_setting("colloc")) {
			set_module_setting("colloc", $args['new']);
			}
		}
		break;
		case "village":
			if ($session['user']['location'] == get_module_setting("colloc")){
				tlschema($args['schemas']['gatenav']);
			  addnav($args['gatenav']);
				tlschema();
				addnav("`b`#Colliseum`b","runmodule.php?module=colliseum&op=enter");
			}
			if ($reg==5){
		  	tlschema($args['schemas']['gatenav']);
		    addnav($args['gatenav']);
				tlschema();
		    addnav("`b`#Colliseum Battle`b", "runmodule.php?module=colliseum.php&op=battle");
			}
	  break;
		case "header-hof":
			addnav("Clan Rankings");
			addnav("Clan Points", "runmodule.php?module=colliseum&op=clanhof");
			break;
		}
	return $args;
}
function colliseum_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "colliseum") {
			include("modules/colliseum/colliseum.php");
		}
	}
}
?>