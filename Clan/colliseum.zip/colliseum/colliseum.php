<?php
//$timeout = date("Y-m-d H:i:s",strtotime("-43200 seconds"));
require_once("common.php");
require_once("lib/http.php");
require_once("lib/villagenav.php");
global $session;
tlschema('colliseum');

page_header("Colliseum");

$name = get_module_setting("name","colliseum");
$id = $session['user']['acctid'];
$op=httpget('op');
if ($op=="enter"){
	output("You walk into the %s`0, looking around, you see several passages.  Which will you take?",$name);
	addnav("The Colliseum","runmodule.php?module=colliseum&op=colliseum");
	villagenav();
}
if ($op=="colliseum"){
		output("You approach the %s`0 ",$name);
		output_notl("`n`n");
		$clanid = $session['user']['clanid'];
		if ($session['user']['clanrank'] <= CLAN_APPLICANT){
			output("You are not a member of a clan, if you wish to participate in the Colliseum you should join one");
		}elseif ($session['user']['clanrank'] >= CLAN_MEMBER){
			if ($session['user']['clanrank'] >= CLAN_OFFICER){
				addnav("Register a Battle","runmodule.php?module=colliseum&op=regbattle");
				addnav("Check battles due to Start","runmodule.php?module=colliseum&op=start");
				addnav("Skip Player","runmodule.php?module=colliseum&op=skip");
			}
			addnav("Sign up for a Battle","runmodule.php?module=colliseum&op=signup");
			addnav("Rules and Guidelines","runmodule.php?module=colliseum&op=rules");
		}
		villagenav();
	}
if ($op=="skip"){
	//select players that are in this clan who haven't had their turn in 1 real time day.
	$clanid=$session['user']['clanid'];
	$acc = db_prefix("accounts");
	$mp = db_prefix("module_userprefs");
	$sql = "SELECT $acc.name AS name,
	$acc.acctid AS acctid,
	$mp.value AS turn,
	$mp.userid FROM $mp INNER JOIN $acc
	ON $acc.acctid = $mp.userid 
	WHERE $mp.modulename = 'colliseum' 
	AND $mp.setting = 'collreg'
	and $acc.clanid = '$clanid' 
	AND $mp.value = 1";
	$result = db_query($sql);
	$rank = translate_inline("Skip");
	$nname = translate_inline("Name");
	rawoutput("<table border='0' cellpadding='2' cellspacing='1' align='center'>");
	rawoutput("<tr class='trhead'><td align=center>$nname</td><td align=center>$rank</td></tr>");
	for ($i=0;$i < db_num_rows($result);$i++){ 
		$row = db_fetch_assoc($result);
		$name1 = $row['name'];
		if ($row['clanid']<>$session['user']['clanid']){
			rawoutput("<tr class='trhilight'><td>");
		}else{
			rawoutput("<tr class='".($i%2?"trdark":"trlight")."'><td align=left>");
		}
		output_notl($name1);
        rawoutput("</td><td>");
        $battleid = $rowc['battleid'];
        $id=$row['acctid'];
		$thisday=date("Y-m-d H:i:s",strtotime("-10800 seconds"));
		$day = get_module_pref("colldate","colliseum",$id);
		if ($day == ""){
			output_notl("`#[`&Waiting`#]`0");
		}elseif ($day<$thisday){
			rawoutput("<a href='runmodule.php?module=colliseum&op=skipplayer&id=$id'>");
        	addnav("","runmodule.php?module=colliseum&op=skipplayer&id=$id");
       		output_notl("`#[`&Skip`#]`0");
		}elseif ($day>=$thisday){
       		output_notl("`#[`&Waiting`#]`0");
		}
	}
	rawoutput("</table>");
	output("`^Choose a Player to Skip");
	addnav("Return to Colliseum", "runmodule.php?module=colliseum&op=colliseum");
	villagenav();
}
if ($op=="skipplayer"){
	$id = httpget('id');
	$sql = "SELECT * FROM " .db_prefix("module_userprefs"). " WHERE modulename = 'colliseum' AND setting = 'idno' AND userid = '$id'";
	$res = db_query($sql);
	$row = db_fetch_assoc($res);
	$idno = $row['value'];
	$idnoa="id".$idno;
	set_module_pref("collreg",2,"colliseum",$id);
	$sqla = "SELECT * FROM " .db_prefix("module_userprefs"). " WHERE modulename = 'colliseum' AND setting = 'cbattleid' AND userid = '$id'";
	$resa = db_query($sqla);
	$rowa = db_fetch_assoc($resa);
	$battleid = $rowa['value'];
	$sql1 = "SELECT * FROM " .db_prefix("colliseum"). " WHERE battleid = '$battleid' ORDER BY battleid DESC LIMIT 1";
	$res1=db_query($sql1);
	$row1 = db_fetch_assoc($res1);
	$idno1=$idno+1;
	$idno1a="id".$idno1;
	$id2 = $row1[$idno1a];
	if ($id2==0){
		$id2 = $row1['id1'];
	}
	if ($idno=10){
		$id2=$row1['id1'];
	}
	$date=date("Y-m-d H:i:s");
	set_module_pref("colldate",$date,"colliseum",$id2);
	clear_module_pref("colldate","colliseum",$id);
	require_once("lib/systemmail.php");
	systemmail($id,"`^Colliseum Battle!`0",array("`^Turn over, You failed to accept the challenge within the alloted time."));
	systemmail($id2,"`^Colliseum Battle!`0",array("`^The battle has commenced, it is now your turn, please click the link in the village"));
	set_module_pref("collreg",1,"colliseum",$id2);
	output("That Player has been skipped.  A system mail has been sent to the next player in line. They have 1 day to take their turn");
	addnav("Skip Another","runmodule.php?module=colliseum&op=skip");
	addnav("Return to Colliseum", "runmodule.php?module=colliseum&op=colliseum");
	villagenav();
}
if ($op=="regbattle"){
	$thisday = date("Y-m-d H:i:s");
	$sql = "SELECT * FROM " .db_prefix ("accounts") . " WHERE acctid = '$id'";
	$res = db_query($sql);
	$row = db_fetch_assoc($res);
	$clanid = $row['clanid'];
	addnav("Return to Colliseum","runmodule.php?module=colliseum&op=colliseum");
	$sqla = "SELECT * FROM " .db_prefix("clans") . " WHERE clanid = '$clanid'";
	$resa = db_query($sqla);
	$rowa = db_fetch_assoc($resa);
	$clanshort = $rowa['clanshort'];
	$sqlb = "SELECT * FROM " .db_prefix("colliseum"). " WHERE clan = '$clanid' AND chp > 0";
	$resb = db_query($sqlb);
	$rowb = db_fetch_assoc($resb);
	if (db_num_rows($resb)>=3){
		output("Your clan already has the maximum number of battles registered here, one must end before you may start another");
	}
	if (db_num_rows($resb)<3){
		db_query("INSERT INTO " .db_prefix("colliseum"). " (battleid,type,clan,day,inprogress) VALUES ('0','3','$clanid','$thisday','0')");
		$sqlc = "SELECT * FROM " .db_prefix("colliseum"). " WHERE clan = '$clanid' ORDER BY 'battleid' DESC LIMIT 1";
		$resc = db_query($sqlc);
		$rowc = db_fetch_assoc($resc);
		$battleid = $rowc['battleid'];
		output("You have now registered a battle in the %s, and may now Call for signups from your Clan members.  This Battle Number is %s",$name,$battleid);
	}
	villagenav();
}
if ($op=="start"){
	$clanid = $session['user']['clanid'];
	$clan = db_prefix("clans");
	$co = db_prefix("colliseum");
	$sqlc = "SELECT $clan.clanshort AS clanshort,
	$clan.clanid AS clanid,
	$co.battleid AS battles,
	$co.day AS day,
	$co.id3 AS id3,
	$co.clan FROM $co INNER JOIN $clan
	ON $clan.clanid = $co.clan 
	WHERE $co.clan = '$clanid'
	AND $co.inprogress = 0
	ORDER BY ($co.battleid+0)
	DESC Limit 3;
	";
	$resc = db_query($sqlc);
	$battle = translate_inline("Battles");
    $su = translate_inline("Signup");
    rawoutput("<table border='0' cellpadding='3' cellspacing='0' align='center'><tr class='trhead'><td style='width:250px' align=center>$battle</td><td align=center>$su</td></tr>"); 
    if(!db_num_rows($resc)){
    	$none = translate_inline("None");
    	rawoutput("<tr class='".($i%2?"trlight":"trdark")."'><td align=center  colspan=4><i>$none</i></td></tr>");
    }else{
        for ($i = 0; $i < db_num_rows($resc); $i++){ 
        	$rowc = db_fetch_assoc($resc);
        	$battleid = $rowc['battles'];
        	$num = $i+1;
                rawoutput("<tr class='".($i%2?"trlight":"trdark")."'><td>");
                output_notl($battleid);
                rawoutput("</td><td>");
            $thisday = date("Y-m-d h:m:s",strtotime("-1 day"));
			$day = $row['day'];
			if ($thisday>=$day && $rowc['id3']<>0){
        		rawoutput("<a href=runmodule.php?module=colliseum&op=startbattle&battleid=$battleid>");
        		addnav("","runmodule.php?module=colliseum&op=startbattle&battleid=$battleid");
       			output_notl("`#[`&Start`#]`0");
   			}
       		if ($thisday-$day<3 || $rowc['id3']==0){
	       		output_notl("`#[`&Can't be started`#]`0");
		}
    }    
}
rawoutput("</table>");
addnav("Return to Colliseum", "runmodule.php?module=colliseum&op=colliseum");
villagenav();
}
if ($op=="startbattle"){
	$battleid = httpget('battleid');
	$creature = e_rand(1,5);
			switch($creature){
				case 1:
				$cn = "`)Basilisk";
				break;
				case 2:
				$cn = "`\$Cerberus";
				break;
				case 3:
				$cn = "`4Cyclops";
				break;
				case 4:
				$cn = "`#Chimera";
				break;
				case 5:
				$cn = "`QManticore";
				break;
			}
	$catk=round(e_rand(150,250));
	$cdef=round(e_rand(150,250));
	output("This battle has been started, and a challenge sent to the first player");
	$sql = "SELECT * FROM " .db_prefix("colliseum"). " WHERE battleid = '$battleid'";
	$res = db_query($sql);
	$row = db_fetch_assoc($res);
	$id = $row['id1'];
	$chp = round(e_rand(50000,60000));
	db_query("UPDATE " .db_prefix("colliseum"). " SET inprogress = '1',creature = '$cn', chp = '$chp', catk = '$catk',cdef = $cdef WHERE battleid = '$battleid'");
	require_once("lib/systemmail.php");
	systemmail($id,"`^Colliseum Battle!`0",array("`^The battle has commenced, it is now your turn, please click the link in the village"));
	set_module_pref("collreg",1,"colliseum",$id);
	villagenav();
}
if ($op=="signup"){
	$ids=$session['user']['acctid'];
	$signup=get_module_pref("collreg","colliseum",$ids);
	if ($signup==2){
		output("You are already signed up for a battle and may not sign up for another");
	}
	if ($signup==0){
		$clanid = $session['user']['clanid'];
		$clan = db_prefix("clans");
		$co = db_prefix("colliseum");
		$sqlc = "SELECT $clan.clanshort AS shortname,
		$clan.clanid AS clanid,
		$co.battleid AS battles,
		$co.clan FROM $co INNER JOIN $clan
		ON $clan.clanid = $co.clan 
		WHERE $co.clan = '$clanid'
		AND $co.id10 = 0
		AND $co.inprogress = 0
		ORDER BY ($co.battleid+0)
		DESC Limit 3;
		";
		$resc = db_query($sqlc);
		$battle = translate_inline("Battles");
    	$su = translate_inline("Signup");
        rawoutput("<table border='0' cellpadding='3' cellspacing='0' align='center'><tr class='trhead'><td style='width:250px' align=center>$battle</td><td align=center>$su</td></tr>"); 
        if(!db_num_rows($resc)){
            $none = translate_inline("None");
        	rawoutput("<tr class='".($i%2?"trlight":"trdark")."'><td align=center  colspan=4><i>$none</i></td></tr>");
        	output("There are no battles registered for your clan at this time");
    	}else{
        	for ($i = 0; $i < db_num_rows($resc); $i++){ 
        		$rowc = db_fetch_assoc($resc);
        		$battleid = $rowc['battles'];
        		$num = $i+1;
                rawoutput("<tr class='".($i%2?"trlight":"trdark")."'><td>");
                output_notl($battleid);
                rawoutput("</td><td>");
             
        		rawoutput("<a href='runmodule.php?module=colliseum&op=signup2&battleid=$battleid'>");
        		addnav("","runmodule.php?module=colliseum&op=signup2&battleid=$battleid");
       			output_notl("`#[`&Sign Up`#]`0");
			}
    	}    
    	rawoutput("</table>");
	}
    addnav("Return to Colliseum", "runmodule.php?module=colliseum&op=colliseum");
    villagenav();
}
if ($op=="signup2"){
	$battleid = httpget("battleid");
	$id = $session['user']['acctid'];
	$signup = get_module_pref("collreg","colliseum",$id);
	$sql = "SELECT * FROM " .db_prefix("colliseum"). " WHERE battleid = '$battleid'";
	$res = db_query($sql);
	$row = db_fetch_assoc($res);
	if ($signup==1 || $signup==2){
		output("Sorry you are already signed up for a battle and cannot sign up for another til that one is finished, if this is incorrect please notify a admin");
	}
	if ($signup==0){
	if ($row['id10']<>0){
		output("Sorry, but this battle is filled, please choose another");
	}
	if ($row['id10']==0){
		if ($row['id1']==0){
			db_query("UPDATE " .db_prefix("colliseum"). " SET id1 = '$id' WHERE battleid = '$battleid'");
			set_module_pref("idno",1,"colliseum",$id);
			set_module_pref("cbattleid",$battleid,"colliseum",$id);
		}
		if ($row['id1']<>0 && $row['id2']==0){
			db_query("UPDATE " .db_prefix("colliseum"). " SET id2 = '$id' WHERE battleid = '$battleid'");
			set_module_pref("idno",2,"colliseum",$id);
			set_module_pref("cbattleid",$battleid,"colliseum",$id);
		}
		if ($row['id1']<>0 && $row['id2']<>0 && $row['id3']==0){
			db_query("UPDATE " .db_prefix("colliseum"). " SET id3 = '$id' WHERE battleid = '$battleid'");
			set_module_pref("idno",3,"colliseum",$id);
			set_module_pref("cbattleid",$battleid,"colliseum",$id);
		}
		if ($row['id1']<>0 && $row['id2']<>0 && $row['id3']<>0 && $row['id4']==0){
			db_query("UPDATE " .db_prefix("colliseum"). " SET id4 ='$id' WHERE battleid = '$battleid'");
			set_module_pref("idno",4,"colliseum",$id);
			set_module_pref("cbattleid",$battleid,"colliseum",$id);
		}
		if ($row['id1']<>0 && $row['id2']<>0 && $row['id3']<>0 && $row['id4']<>0 && $row['id5']==0){
			db_query("UPDATE " .db_prefix("colliseum"). " SET id5 ='$id' WHERE battleid = '$battleid'");
			set_module_pref("idno",5,"colliseum",$id);
			set_module_pref("cbattleid",$battleid,"colliseum",$id);
		}
		if ($row['id1']<>0 && $row['id2']<>0 && $row['id3']<>0 && $row['id4']<>0 && $row['id5']<>0 && $row['id6']==0){
			db_query("UPDATE " .db_prefix("colliseum"). " SET id6 ='$id' WHERE battleid = '$battleid'");
			set_module_pref("idno",6,"colliseum",$id);
			set_module_pref("cbattleid",$battleid,"colliseum",$id);
		}
		if ($row['id1']<>0 && $row['id2']<>0 && $row['id3']<>0 && $row['id4']<>0 && $row['id5']<>0 && $row['id6']<>0 && $row['id7']==0){
			db_query("UPDATE " .db_prefix("colliseum"). " SET id7 ='$id' WHERE battleid = '$battleid'");
			set_module_pref("idno",7,"colliseum",$id);
			set_module_pref("cbattleid",$battleid,"colliseum",$id);
		}
		if ($row['id1']<>0 && $row['id2']<>0 && $row['id3']<>0 && $row['id4']<>0 && $row['id5']<>0 && $row['id6']<>0 && $row['id7']<>0 && $row['id8']==0){
			db_query("UPDATE " .db_prefix("colliseum"). " SET id8 ='$id' WHERE battleid = '$battleid'");
			set_module_pref("idno",8,"colliseum",$id);
			set_module_pref("cbattleid",$battleid,"colliseum",$id1);
		}
		if ($row['id1']<>0 && $row['id2']<>0 && $row['id3']<>0 && $row['id4']<>0 && $row['id5']<>0 && $row['id6']<>0 && $row['id7']<>0 && $row['id8']<>0 && $row['id9']==0){
			db_query("UPDATE " .db_prefix("colliseum"). " SET id9 = '$id' WHERE battleid = '$battleid'");
			set_module_pref("idno",9,"colliseum",$id);
			set_module_pref("cbattleid",$battleid,"colliseum",$id);
		}
		if ($row['id1']<>0 && $row['id2']<>0 && $row['id3']<>0 && $row['id4']<>0 && $row['id5']<>0 && $row['id6']<>0 && $row['id7']<>0 && $row['id8']<>0 && $row['id9']<>0  && $row['id10']==0){
			$creature = e_rand(1,5);
			switch($creature){
				case 1:
				$cn = "`)Basilisk";
				break;
				case 2:
				$cn = "`\$Cerberus";
				break;
				case 3:
				$cn = "`4Cyclops";
				break;
				case 4:
				$cn = "`#Chimera";
				break;
				case 5:
				$cn = "`QManticore";
				break;
			}
			$catk=round(e_rand(150,250));
			$cdef=round(e_rand(150,250));
			db_query("UPDATE " .db_prefix("colliseum"). " SET (id10,inprogress,creature,chp,catk,cdef) VALUES ('$id','1','$cn','500000','$catk','$cdef') WHERE battleid = '$battleid'");
			$sql = "SELECT * FROM " .db_prefix("colliseum"). " WHERE battleid = '$battleid'";
			$res = db_query($sql);
			$row = db_fetch_assoc($res);
			$id1 = $row['id1'];
			require_once("lib/systemmail.php");
			systemmail($id1,"`^Colliseum Battle!`0",array("`^The battle has commenced, it is now your turn, please click the link in the village"));
			$day = date("j");
			set_module_pref("colldate",$day,"colliseum",$id1);
			set_module_pref("collreg",1,"colliseum",$id1);
			set_module_pref("cbattleid",$battleid,"colliseum",$id);
			set_module_pref("idno",10,"colliseum",$id);
			set_module_pref("collreg",2,"colliseum",$id);
		}
		set_module_pref("collreg",2,"colliseum",$id);
		output("You have now signed up for this battle, and may not signup for another until it is completed");
	}
}
villagenav();
}
if ($op=="battle"){
	$id = $session['user']['acctid'];
	$battleid = get_module_pref("cbattleid","colliseum",$id);
	$sql = "SELECT * FROM " .db_prefix("colliseum"). " WHERE battleid = '$battleid' ORDER BY 'battleid' DESC Limit 1";
	$res = db_query($sql);
	$row = db_fetch_assoc($res);
	$cn = $row['creature'];
	
	output("It is now your turn to battle the %s`0",$cn);
	addnav(array("Enter Battleground"),"runmodule.php?module=colliseum&op=battleground&battleid=$battleid");
}
if ($op=="battleground"){
	$id = $session['user']['acctid'];
	$battleid = httpget('battleid');
	$sql = "SELECT * FROM " .db_prefix("colliseum"). " WHERE battleid = '$battleid' ORDER BY 'battleid' DESC Limit 1";
	$res = db_query($sql);
	$row = db_fetch_assoc($res);
	$cn = $row['creature'];
	$chp = $row['chp'];
	$catk = $row['catk'];
	$cdef = $row['cdef'];
	$clanid = $session['user']['clanid'];
	$clanatk = 300;
	$clandef = 300;
	$idno = get_module_pref("idno","colliseum",$id);
	$dk = $session['user']['dragonkills'];
	if ($dk<50){
		$atk = $clanatk;
		$def = $clandef;
	}
	if ($dk>=50 && $dk<=100){
		$atk = $clanatk+5;
		$def = $clandef+5;
	}
	if ($dk>=101 && $dk<=200){
		$atk = $clanatk+20;
		$def = $clandef+20;
	}
	if ($dk>=201 && $dk<=400){
		$atk = $clanatk+30;
		$def = $clandef+30;
	}
	if ($dk>=401 && $dk<=700){
		$atk = $clanatk+40;
		$def = $clandef+40;
	}
	if ($dk>=701){
		$atk = $clanatk+50;
		$def = $clandef+50;
	}
	output_notl("`n`n");
	output("`b`c`^Your Stats`b");
	output_notl("`n`n");
	output("Your Stats");
	output_notl("`n`n");
	output("`@Hitpoints: `#%s",$session['user']['hitpoints']);
	output_notl("`n`n");
	output("`@Attack: `#%s",$atk);
	output_notl("`n`n");
	output("`@Defense: `#%s",$def);
	output_notl("`n`n");
	output("`b`c`^Arena Stats`b");
	output_notl("`n`n");
	output("%s Stats",$cn);
	output_notl("`n`n");
	output("`@Hitpoints: `#%s",$chp);
	output_notl("`n`n");
	output("`@Attack: `#%s",$catk);
	output_notl("`n`n");
	output("`@Defense: `#%s",$cdef);
	addnav("Attack","runmodule.php?module=colliseum&op=attack&battleid=$battleid");
}
if ($op=="attack"){
	$id = $session['user']['acctid'];
	$battleid = httpget('battleid');
	$sql = "SELECT * FROM " .db_prefix("colliseum"). " WHERE battleid = '$battleid' ORDER BY 'battelid' DESC Limit 1";
	$res = db_query($sql);
	$row = db_fetch_assoc($res);
	$cn = $row['creature'];
	$chp = $row['chp'];
	$catk = $row['catk'];
	$cdef = $row['cdef'];
	$clanid = $row['clan'];
	$clanatk = 300;
	$clandef = 300;
	$dk = $session['user']['dragonkills'];
	
	$sqlc = "SELECT * FROM " .db_prefix("clans") . " WHERE clanid = '$clanid'";
	$resc = db_query($sqlc);
	$rowc = db_fetch_assoc($resc);
	$clanname = $rowc['clanname'];
	if ($dk<50){
		$atk = $clanatk;
		$def = $clandef;
	}
	if ($dk>=50 && $dk<=100){
		$atk = $clanatk+5;
		$def = $clandef+5;
	}
	if ($dk>=101 && $dk<=200){
		$atk = $clanatk+20;
		$def = $clandef+20;
	}
	if ($dk>=201 && $dk<=400){
		$atk = $clanatk+30;
		$def = $clandef+30;
	}
	if ($dk>=401 && $dk<=700){
		$atk = $clanatk+40;
		$def = $clandef+40;
	}
	if ($dk>=701){
		$atk = $clanatk+50;
		$def = $clandef+50;
	}
	$hp = $session['user']['hitpoints'];
	$atkmin = round($atk*0.1);
	$atkmax = round($atk*0.2);
	$atknew = e_rand($atkmin,$atkmax);
	$defmin = round($def*0.12);
	$defmax = round($def*0.26);
	$defnew = e_rand($defmin,$defmax);
	$camin = round($catk*0.1);
	$camax = round($catk*0.27);
	$canew = e_rand($camin,$camax);
	$cdmin = round($cdef*0.11);
	$cdmax = round($cdef*0.28);
	$cdnew = e_rand($cdmin,$cdmax);
	$dam = round((($canew-$atknew)*0.89)*(($cdnew-$defnew)*0.12));
	if ($dam>0){
		output("You hit your opponent for %s damage",$dam);
		$hit=e_rand(1,15);
		switch($hit){
			case 1:
			case 5:
			$bonus = ($chp*0.02);
			output("Dodging under %s's`0 guard you execute a second quick attack for %s damage",$cn, $bonus);
			break;
			case 2:
			case 3:
			case 4:
			case 6:
			case 7:
			case 8:
			case 9:
			case 10:
			case 11:
			case 12:
			case 13:
			case 14:
			case 15:
			break;
		}
		set_module_pref("collreg",2,"colliseum",$id);
		$damnew = $dam+$bonus;
		$hpopp = $chp-$damnew;
		$sql="UPDATE " . db_prefix("colliseum") . " SET chp = '$hpopp' WHERE battleid = '$battleid'";
		db_query($sql);
	}
	if ($dam==0){
		output("You miss");
		set_module_pref("collreg",2,"colliseum",$id);
		$hpopp= $chp;
	}
	if ($dam<0){
		output("You are riposted for %s damage",$dam);
		set_module_pref("collreg",2,"colliseum",$id);
		$hit=e_rand(1,15);
		switch($hit){
			case 1:
			case 5:
			$bonus = ($chp*0.02);
			output("Recoiling from %s`o, you swiftly lift your weapon and catch them offguard for %s damage",$cn,$bonus);
			break;
			case 2:
			case 3:
			case 4:
			case 6:
			case 7:
			case 8:
			case 9:
			case 10:
			case 11:
			case 12:
			case 13:
			case 14:
			case 15:
			break;
		}
		$hpnew = $hp+$dam;
		$hpopp = $chp-$bonus;
		$sql="UPDATE " . db_prefix("colliseum") . " SET chp = '$hpopp' WHERE battleid = '$battleid'";
		db_query($sql);
		if ($hpnew<=0){
			output_notl("`n`n");
			output("If this were a real battle, you'd be dead!!");
		}
	}
	villagenav();
	if ($hpopp<=0){
		output("The %s`0 falls to the ground at your feet, gasping for breath it reaches towards you.  You drive your weapon through its skull!  The battle is over, your Clan is victorious",$cn);
		addnews("`@%s Clan has defeated the %s`@ in the Colliseum",$clanname,$cn);
		$id1 = $row['id1'];
		$id2 = $row['id2'];
		$id3 = $row['id3'];
		$id4 = $row['id4'];
		$id5 = $row['id5'];
		$id6 = $row['id6'];
		$id7 = $row['id7'];
		$id8 = $row['id8'];
		$id9 = $row['id9'];
		$id10 = $row['id10'];
		$sql="UPDATE " . db_prefix("colliseum") . " SET inprogress = '3' WHERE battleid = '$battleid'";
		db_query($sql);
		require_once("lib/systemmail.php");
		systemmail($id1,"`^Colliseum Battle!`0",array("`^Your Clan was Victorious!!"));
		systemmail($id2,"`^Colliseum Battle!`0",array("`^Your Clan was Victorious!!"));
		systemmail($id3,"`^Colliseum Battle!`0",array("`^Your Clan was Victorious!!"));
		set_module_pref("collreg",0,"colliseum",$id1);
		set_module_pref("collreg",0,"colliseum",$id2);
		set_module_pref("collreg",0,"colliseum",$id3);
		if ($id4<>0){
			systemmail($id4,"`^Colliseum Battle!`0",array("`^Your Clan was Victorious!!"));
			set_module_pref("collreg",0,"colliseum",$id4);
			if ($id5==0){
				$pt=5;
			}
		}
		if ($id5<>0){
			systemmail($id5,"`^Colliseum Battle!`0",array("`^Your Clan was Victorious!!"));
			set_module_pref("collreg",0,"colliseum",$id5);
			if ($id6==0){
				$pt=6;
			}
		}
		if ($id6<>0){
			systemmail($id6,"`^Colliseum Battle!`0",array("`^Your Clan was Victorious!!"));
			set_module_pref("collreg",0,"colliseum",$id6);
			if ($id7==0){
				$pt=7;
			}
		}
		if ($id7<>0){
			systemmail($id7,"`^Colliseum Battle!`0",array("`^Your Clan was Victorious!!"));
			set_module_pref("collreg",0,"colliseum",$id7);
			if ($id8==0){
				$pt=8;
			}
		}
		if ($id8<>0){
			systemmail($id8,"`^Colliseum Battle!`0",array("`^Your Clan was Victorious!!"));
			set_module_pref("collreg",0,"colliseum",$id8);
			if ($id9==0){
				$pt=9;
			}
		}
		if ($id9<>0){
			systemmail($id9,"`^Colliseum Battle!`0",array("`^Your Clan was Victorious!!"));
			set_module_pref("collreg",0,"colliseum",$id9);
			if ($id10==0){
				$pt=10;
			}
		}
		if ($id10<>0){
			systemmail($id10,"`^Colliseum Battle!`0",array("`^Your Clan was Victorious!!"));
			set_module_pref("collreg",0,"colliseum",$id10);
			$pt=11;
		}
		// copied and edited code from clans.php
		$sql = "SELECT MAX(" . db_prefix("clans") . ".clanid) AS clanid, MAX(clanshort) AS clanshort, MAX(clanname) AS clanname,count(" . db_prefix("accounts") . ".acctid) AS c FROM " . db_prefix("clans") . " LEFT JOIN " . db_prefix("accounts") . " ON " . db_prefix("clans") . ".clanid=" . db_prefix("accounts") . ".clanid AND clanrank>".CLAN_APPLICANT." GROUP BY " . db_prefix("clans") . ".clanid ORDER BY c DESC";
		$result = db_query($sql);
		if (db_num_rows($result)>0){
		$v = 0;
		$row = db_fetch_assoc($result);
		// end of copied code
		if ($row['c']>0 && $row['c']<=10){
			$points = $pt+5;
		}
		if ($row['c']>10 && $row['c']<=30){
			$points = $pt+4;
		}
		if ($row['c']>=31){
			$points = $pt+3;
		}
		$clanwins = get_module_objpref("clans",$clanid,"clanwins","colliseum")+$points;
		set_module_objpref("clans",$clanid,"clanwins",$clanwins,"colliseum");
	}
}
	if ($hpopp>0){
		output_notl("`n`n");
		output("Your turn is now over, you will receive another mail when it is your turn again, or the %s`0 is defeated",$cn);
		$idno1 = get_module_pref("idno","colliseum",$id);
		//output("idno1 %s",$idno1);
		$idno = $idno1+1;
		if ($idno>10){
			$idno = 1;
		}
		//output("id %s",$idno);
		$sql = "SELECT * FROM " .db_prefix("colliseum"). " WHERE battleid = '$battleid'";
		$res = db_query($sql);
		$row = db_fetch_assoc($res);
		//$idset = ("id$idno");
		//output("idset %s",$idset);
		$id2 = $row['id'.$idno];
		if ($id2==0) {
			$id2=$row['id1'];
			//output("id2 %s",$id2);
		}
		$date = date("Y-m-d H:i:s");
		//output("id2 %s",$id2);
		set_module_pref("collreg",2,"colliseum",$id);
		set_module_pref("collreg",1,"colliseum",$id2);
		set_module_pref("colldate",$date,"colliseum",$id2);
		set_module_pref("colldate","","colliseum",$id);
		require_once("lib/systemmail.php");
		systemmail($id2,"`^Colliseum Battle!`0",array("`^The battle has commenced, it is now your turn, please click the link in the village"));
	}

}
if ($op=="rules"){
	output("`b`c`^RULES AND GUIDELINES FOR `b%s`0`c",$name);
	output_notl("`n`n");
	output("`b`&1.  This arena is for Clans to fight together.  Only a leader may register to start a battle here.");
	output_notl("`n`n");
	output("`^2.  Battles must have a minimum of 3 clan members entered to start.");
	output_notl("`n`n");
	output("`&3.  The maximum number of clan members able to enter a battle is 10.");
	output_notl("`n`n");
	output("`^4.  There are no buffs used in this arena, and the creatures you will meet, are based upon the overall stats of all clan members fighting");
	output_notl("`n`n");
	output("`&5.  These battles are not designed to be over quickly, you may only signup for one battle at a time for your Clan.  Expect a battle to run over a number of days.");
	output_notl("`n`n");
	output("`^6.  Battles that do not reach the minimum number needed to start, will automatically be cancelled in 2 real life days from registration.`b");
	addnav("Return to Colliseum","runmodule.php?module=colliseum&op=colliseum");
	villagenav();
}
if ($op=="clanhof"){
	page_header("Clan Points");
	$cl = db_prefix("clans");
	$mp = db_prefix("module_objprefs");
	$sql = "SELECT $cl.clanname AS name,
	$cl.clanid AS clanid,
	$cl.clanname AS clanname,
	$mp.value AS points,
	$mp.objid FROM $mp INNER JOIN $cl
	ON $cl.clanid = $mp.objid
	WHERE $mp.modulename = 'colliseum'
	AND $mp.setting = 'clanwins'
	AND $mp.objtype = 'clans'
	AND $mp.value > 0 ORDER BY ($mp.value+0)
	DESC limit 25";
	$result = db_query($sql);
	$rank = translate_inline("Clan Points");
	$name = translate_inline("Clan Name");
	output("`n`b`c`EClan Points`n`n`c`b");
	rawoutput("<table border='0' cellpadding='2' cellspacing='1' align='center'>");
	rawoutput("<tr class='trhead'><td align=center>$name</td><td align=center>$rank</td></tr>");
	for ($i=0;$i < db_num_rows($result);$i++){
		$row = db_fetch_assoc($result);
		if ($row['clanid']==$session['user']['clanid']){
			rawoutput("<tr class='trhilight'><td>");
		}else{
			rawoutput("<tr class='".($i%2?"trdark":"trlight")."'><td align=left>");
		}
		output_notl("%s",$row['name']);
		rawoutput("</td><td align=right>");
		output_notl("%s",$row['points']);
		rawoutput("</td></tr>");
	}
	rawoutput("</table>");
	addnav("Back to HoF", "hof.php");
	villagenav();
	page_footer();
}
page_footer();
?>