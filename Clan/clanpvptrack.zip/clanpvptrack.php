<?php

function clanpvptrack_getmoduleinfo(){
	$info = array(
		"name"=>"Clan PvP Tracking",
		"author"=>"`!Q`)wyxzl`0",
		"version"=>"0.9",
		"category"=>"Clan",
		"download"=>"http://dragonprime.net/index.php?topic=8789.0",
		"settings"=>array(
			"Clan PvP Tracking Settings,title",
			"hofnum"=>"Display how many results in the HoF page,int|50",
			"clannum"=>"Display how many results in the clan page,int|25"
		),
		"prefs"=>array(
			"Clan PvP Tracking Prefs,title",
			"wins"=>"Amount of PvP wins, int|0"
		)
	);
	return $info;
}

function clanpvptrack_install(){
	module_addhook("pvpwin");
	module_addhook("pvploss");
	module_addhook("process-create");
	module_addhook("footer-clan");
	module_addhook("footer-hof");
	$sql = "SELECT value FROM " . db_prefix("module_userprefs") . " WHERE modulename = 'clanpvptrack'";
	$result = db_query($sql);
	if(db_num_rows($result)  == 0){	
		$sql = "SELECT acctid FROM " . db_prefix("accounts");
		$result = db_query($sql);
		if(db_num_rows($result) > 0){
			while($row = db_fetch_assoc($result)){
				$acctid = $row['acctid'];
				$sql = "INSERT INTO " . db_prefix("module_userprefs") . " (modulename, setting, userid, value) VALUES ('clanpvptrack', 'wins', '$acctid', '0')";
				db_query($sql);
			}
		}
	}
	return true;
}

function clanpvptrack_uninstall(){
	return true;
}

function clanpvptrack_dohook($hookname, $args){	
	switch ($hookname){
		case "pvpwin":
			increment_module_pref("wins");
		break;
		case "pvploss":
			$id = $args['badguy']['acctid'];
			increment_module_pref("wins", 1, false, $id);
		break;
		case "process-create":
			$id = $args['acctid'];
			set_module_pref("wins", 0, false, $id);
		break;
		case "footer-clan":
			global $session;
			if($session['user']['clanid'] != 0){
				addnav("PvP Information");
				addnav("PvP Rankings","runmodule.php?module=clanpvptrack&op=clan");
			}
		break;
		case "footer-hof":
			addnav("Warrior Rankings");
			addnav("PvP by Clan","runmodule.php?module=clanpvptrack&op=hof");
		break;
		}
	return $args;
}

function clanpvptrack_run(){
	global $session;
	$op = httpget('op');
	$page = httpget('page');
	$accounts = db_prefix("accounts");
	$clans = db_prefix("clans");
	$userpref = db_prefix("module_userprefs");
	$pageoffset = (int)$page;
	$id = $session['user']['clanid'];
	
	if($pageoffset > 0){ 
		$pageoffset--;
	}
	if($op == "hof"){
		$numdisp = get_module_setting("hofnum");
	}elseif ($op == "clan"){
		$numdisp = get_module_setting("clannum");
	}
	if($numdisp < 1){
		$numdisp = 1;
	}
	$pageoffset *= $numdisp;
	$limit = "LIMIT $pageoffset, $numdisp";
	
	switch ($op){
		case "hof":
			$sql = "SELECT COUNT(clanid) AS count FROM $clans";
			$result = db_query($sql);
			$row = db_fetch_assoc($result);
			$total = $row['count'];
			$sql = "SELECT clanname FROM $clans WHERE clanid = $id";
			$result = db_query($sql);
			$row = db_fetch_assoc($result);
			$myclan = $row['clanname'];
			$sql = "SELECT clanname, SUM(value) AS totalkills, COUNT($accounts.clanid) AS nummembers  
				      FROM $accounts, $clans, $userpref 
				     WHERE $accounts.clanid = $clans.clanid 
				  	   AND modulename = 'clanpvptrack' 
				       AND userid = acctid 
				       AND setting = 'wins' 
				  GROUP BY $clans.clanid 
				  ORDER BY totalkills DESC, nummembers ASC 
                   $limit";
			$result = db_query($sql);
			$rank = translate_inline("Rank");
			$name = translate_inline("Name");
			$pk = translate_inline("PvP Wins");
			page_header("Hall of Fame");
			rawoutput("<big>");
			output("`c`b`^Fiercest Clans in the Land`b`c`0`n");
			rawoutput("</big>");
			rawoutput("<table border='0' cellpadding='2' cellspacing='1' align='center' bgcolor='#999999'>");
			rawoutput("<tr class='trhead'><td>$rank</td><td>$name</td><td>$pk</td></tr>");
			if ($total > 0){
				$i = 0;
				while($row = db_fetch_assoc($result)){
					$i++;
					if ($row['clanname'] == $myclan){
						rawoutput("<tr class='trhilight'><td>");
					} else {
						rawoutput("<tr class='".($i%2?"trdark":"trlight")."'><td>");
					}
					$num = $pageoffset + $i;
					output_notl("$num.");
					rawoutput("</td><td>");
					output_notl("`&%s`0",$row['clanname']);
					rawoutput("</td><td>");
					output_notl("`c`@%s`c`0",$row['totalkills']);
					rawoutput("</td></tr>");
				}
			}
			rawoutput("</table>");
			if($total > $numdisp){
				addnav("Pages");
				for ($p = 0; $p < $total; $p += $numdisp){
					$page = ($p / $numdisp + 1);
					addnav(array("Page %s (%s-%s)", $page, ($p + 1), min($p + $numdisp, $total)), "runmodule.php?module=clanpvptrack&op=hof&page=".$page);
				}
			}
			addnav("Back");
			addnav("Back to HoF", "hof.php");
			page_footer();
		break;
		case "clan":
			$sql = "SELECT SUM(value) AS numkills, COUNT(name) AS total
					  FROM $accounts, $userpref 
				     WHERE clanid = $id 
				  	   AND modulename = 'clanpvptrack' 
				       AND userid = acctid 
				       AND setting = 'wins'";
			$result = db_query($sql);
			$row = db_fetch_assoc($result);
			$total = $row['total'];
			$numkills = $row['numkills'];
			$myname = $session['user']['name'];
			$sql = "SELECT name, dragonkills, value  
				      FROM $accounts, $userpref 
				     WHERE clanid = $id 
				  	   AND modulename = 'clanpvptrack' 
				       AND userid = acctid 
				       AND setting = 'wins' 
				  ORDER BY value DESC, dragonkills ASC 
                   $limit";
			$result = db_query($sql);
			$rank = translate_inline("Rank");
			$name = translate_inline("Name");
			$pk = translate_inline("PvP wins");
			page_header("Clan PvP Information");
			rawoutput("<big>");
			output("`\$`b`cTotal PvP wins for the Clan %s`c`b`n", $numkills);
			output("`c`b`^Fiercest Warriors in the Clan`b`c`0`n");
			rawoutput("</big>");
			rawoutput("<table border='0' cellpadding='2' cellspacing='1' align='center' bgcolor='#999999'>");
			rawoutput("<tr class='trhead'><td>$rank</td><td>$name</td><td>$pk</td></tr>");
			if ($total > 0){
				$i = 0;
				while($row = db_fetch_assoc($result)){
					$i++;
					if ($row['name'] == $myname){
						rawoutput("<tr class='trhilight'><td>");
					} else {
						rawoutput("<tr class='".($i%2?"trdark":"trlight")."'><td>");
					}
					$num = $pageoffset + $i;
					output_notl("$num.");
					rawoutput("</td><td>");
					output_notl("`&%s`0",$row['name']);
					rawoutput("</td><td>");
					output_notl("`c`@%s`c`0",$row['value']);
					rawoutput("</td></tr>");
				}
			}
			rawoutput("</table>");
			if($total > $numdisp){
				addnav("Pages");
				for ($p = 0; $p < $total; $p += $numdisp){
					$page = ($p / $numdisp + 1);
					addnav(array("Page %s (%s-%s)", $page, ($p + 1), min($p + $numdisp, $total)), "runmodule.php?module=clanpvptrack&op=hof&page=".$page);
				}
			}
			addnav("Back");
			addnav("Back to clan halls", "clan.php");
			page_footer();
		break;
		}
}
?>