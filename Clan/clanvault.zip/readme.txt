This module is a bit buggy in places. You would be best to make sure you 
get all of the updates that are discussed in the release thread.

Thank you.