<?php
	$vaulttime = get_module_setting('vaulttime') * 3600;
			if ($session['user']['clanid']!=0 and httpget("op")=="" && $session['user']['clanjoindate'] < date("Y-m-d H:i",time()-$vaulttime)) {
				if ($session['user']['clanrank']>0) {
					addnav("~");
					addnav("Clan Vault","runmodule.php?module=clanvault&op=enter");
				}
			}
?>