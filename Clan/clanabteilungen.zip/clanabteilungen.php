<?php

/*
Erstmalig auf Anagromataf.de erschienen
Bugs und Fehler an arvex@anagromataf.de

Version-Infos:
 	V1.00 - Erster Offizieller Release
*/

function clanabteilungen_getmoduleinfo() {
	$info = array(
		"name"=>"Clanabteilungen",
		"author"=>"`)Arvex",
		"version"=>"1.00",
		"category"=>"Clan",
		"download"=>"http://www.arvex.de/index.php?showforum=3",
		"settings"=>array(
			"Gew�lbekeller, title",
				"schatzmeister"=>"Name des Schatzmeister,text|Wiggl",
				"schatzgr��e"=>"Auf wieviel mu� gespart werden?,range,1000000,5000000,250000|2500000",
				),
                "prefs"=>array(
                        "Gew�lbekeller - User Preferences,title",
                        "schatzmenge"=>"Wieviel hat der User angespart?,int|0",
                        "sparungen"=>"Wie oft hat der User die Schatzgr��e insgesamt angespart?,int|0",
                        "bonus"=>"Hat der User den Bonus erhalten?,int|0",
                        "vertiefung"=>"Hat der User heute schon die Vertiefung untersucht?,bool|0",
                        ),
		);
       return $info;
}
function clanabteilungen_install() {
	include("modules/arvex/clanabteilungen/clanabteilungen_install.php");
    	return true;
}

function clanabteilungen_uninstall() {
    	return true;
}

function clanabteilungen_dohook($hookname,$args) {
	global $session;
	switch ($hookname){
		case "footer-clan":
			include("modules/arvex/clanabteilungen/clanabteilungen_footer-clan.php");
		break;
		case "newday":
			include("modules/arvex/clanabteilungen/clanabteilungen_newday.php");	
		break;
		case "dragonkill":
			set_module_pref('bonus', 0);
		break;	
	}
	return $args;
}

function clanabteilungen_run(){
    	global $session;
    	require_once("lib/http.php");
	$op = httpget('op');
		
    	if ($op=="vorschlag"){
    		include("modules/arvex/clanabteilungen/clanabteilungen_vorschlag.php");	
	}
	if ($op=="gewoelbe"){
		include("modules/arvex/clanabteilungen/clanabteilungen_gewoelbe.php");
	}
	if ($op=="keller"){
		$act = httpget('act');
		$schatzmeister = get_module_setting("schatzmeister");
		$schatzgr��e = get_module_setting("schatzgr��e");
		$vertiefung = get_module_pref("vertiefung");
		if ($act=="podest"){
			include("modules/arvex/clanabteilungen/clanabteilungen_podest.php");
		}
		if ($act=="dukaten"){
			include("modules/arvex/clanabteilungen/clanabteilungen_dukaten.php");
		}
		if ($act=="kammer"){
			$schatzmenge = get_module_pref("schatzmenge");
			include("modules/arvex/clanabteilungen/clanabteilungen_kammer.php");
		}
		if ($act=="deponieren"){
			$schatzmenge = get_module_pref("schatzmenge");
			$dukaten = $session['user']['gold'];
			$neudukaten = $schatzmenge + $dukaten;
			set_module_pref('schatzmenge', $neudukaten);
			$session['user']['gold'] = 0;
			
			include("modules/arvex/clanabteilungen/clanabteilungen_deponieren.php");			
		}
		if ($act=="verlassen"){
				include("modules/arvex/clanabteilungen/clanabteilungen_verlassen.php");
		}
		if ($act=="vertiefung"){
			set_module_pref('vertiefung', 1);
			include("modules/arvex/clanabteilungen/clanabteilungen_vertiefung.php");
		}	
	}
}
?>