<?php
page_header("Vertiefung");
		output("`c`b`QDie Vertiefung`b`c`n`n");
		output("`7Du n�herst dich vorsichtig der Vertiefung in der Wand.");
		output("Ratlos schaust du dir die Vertiefung genau an und bemerkst wie perfekt diese Vertiefung ist.");
		output("Absolut ohne jede makulatur wurde diese Vertiefung in den Stein gesetzt.`n`n");
		output("In der Mitte der quadratischen Vertiefung kannst du einen winzigen Punkt erkennen.");
		output("`Q\"War der schon vorher da?\"`7, fragst du dich oder spielen dir deine Sinne nur einen Streich...`n`n");
		output("Nein, deine Sinne spielen dir keinen Streich.");
		output("Der Punkt wird immer gr��er und erreicht eine bedrohliche Gr��e.");
		output("Du m�chtest einen Schritt zur�ck machen, bist aber bereits in diesem magischen Strudel gefangen.`n`n");
		output("`%Innerhalb des magischen Strudels wirst du wild durch die Gegend geschleudert.");
		output("Nach einiger Zeit wird dir schlecht und du k�mpfst mit deiner �belkeit.");
		output("Schlu�endlich bekommst du irgendwas innerhalb des Wirbels zu fassen.");
		output("Kurz darauf befindest du dich vor der Vertiefung wieder.`n`n");
		require_once('lib/e_rand.php');
			switch(e_rand(1,10)){
				case 1:
				if ($session['user']['turns'] > 0) {
				output("`7Du hast einen Waldkampf verloren.");
				$session['user']['turns']--;
				break;
				}
				elseif ($session['user']['turns'] = 0) {
				output("`7Du hast einen Waldkampf gewonnen.");
				$session['user']['turns']++;
				break;
				}
				case 2:
				if ($session['user']['charm'] > 0) {
				output("`7Du hast an Charme verloren.");
				$session['user']['charm']--;
				break;
				}
				elseif ($session['user']['charm'] = 0) {
				output("`7Du hast an Charm gewonnen.");
				$session['user']['turns']++;
				break;
				}
				case 3:
				if ($session['user']['hitpoints'] > 10) {
				output("`7Du hast viele Lebenspunkte verloren.");
				$session['user']['hitpoints'] = 1;
				break;
				}
				elseif ($session['user']['hitpoints'] <= 10) {
				output("`7Du hast tempor�re Lebenspunkte erhalten.");
				$temphp = round($session['user']['level'] * 7.5) ;
				$session['user']['hitpoints'] += $temphp ;
				break;
				}
				case 4:
				if ($session['user']['goldinbank'] > 0) {
				output("`7Dein Guthaben auf der Bank hat sich um %s Dukaten verringert.", $verringert);
				$verringert = round(($session['user']['goldinbank'] - $session['user']['level'])/3);
				$session['user']['goldinbank'] -= $verringert;
				break;
				}
				elseif ($session['user']['goldinbank'] = 0) {
				output("`7Die Bank hat dir %s Duakten gutgeschrieben.", $guthaben);
				$guthaben = round($session['user']['level'] * 13);
				$session['user']['goldinbank'] += $guthaben;
				break;
				}
				case 5:
				if ($session['user']['deathpower'] > 0) {
				output("`7Du hast alle Gefallen bei Ramius verloren.");
				$session['user']['deathpower'] = 0;
				break;
				}
				elseif ($session['user']['deathpower'] = 0) {
				output("`7Du hast bei Ramius 25 zus�tzliche Gefallen bekommen.");
				$session['user']['deathpower'] += 25;
				break;
				}
				case 6:
				if ($session['user']['level'] >= 8) {
				output("`7Du verlierst einige Erfahrungspunkte.");
				$session['user']['experience'] *= 0.90;
				break;
				}
				elseif ($session['user']['level'] <= 7) {
				output("`7Du erh�lst einige Erfahrungspunkte.");
				$session['user']['experience'] *= 1.10;
				break;
				}
				case 7:
				if ($session['user']['gems'] > 0) {
				output("`7Du verlierst deine Edelsteine.");
				$session['user']['gems'] = 0;
				break;
				}
				elseif ($session['user']['gems'] = 0) {
				output("`7Du findest einen Edelstein.");
				$session['user']['gems']++;
				break;
				}
				case 8:
				case 9:
				if ($session['user']['hitpoints'] = $session['user']['maxhitpoints']) {
				output("`7Du hast dich dabei stark verletzt.");
				$hurt1 = round($session['user']['hitpoints'] * 0.80);
				$session['user']['hitpoints'] -= $hurt1;
				break;
				}
				elseif ($session['user']['hitpoints'] < $session['user']['maxhitpoints']) {
				output("`7Du hast dich dabei leicht verletzt.");
				$hurt2 = round($session['user']['hitpoints'] * 0.20);
				$session['user']['hitpoints'] -= $hurt2;
				break;
				}
				case 10:
				$session['user']['alive']=false;
				output("`7Du hast eine vergiftete Klinge erwischt, du `4STIRBST`7.");
				$session['user']['turns']=0;
				$session['user']['hitpoints']=0;
				addnav("Optionen");
				addnav("T�gliche News","news.php");
				addnews("%s `7griff in eine vergiftete Klinge und starb einen qualvollen Tod.`n`)Neugierde kann t�dlich sein...",$session['user']['name']);
				blocknav("runmodule.php?module=clanabteilungen&op=keller&act=podest");
				blocknav("clan.php");
			break;
			}
			addnav("Optionen");
			addnav("Steinpodest", "runmodule.php?module=clanabteilungen&op=keller&act=podest");
			addnav("Zur�ck zum Clan","clan.php");
		
		page_footer();
?>