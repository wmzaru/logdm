<?php
page_header("Schatzkammer");
		output("`c`b %s `QSchatzkammer`b`c`n`n", $session['user']['name']);
		
		if ($neudukaten < $schatzgr��e) {
			output("`7Du �ffnest eine deiner Schatztruhen mit dem rostigen alten Schl�ssel.`n");
			output("In deine Schatztruhe deponierst du `6%s Dukaten`7.`n", $dukaten);
			output("Insgesamt hast du in deinen Schatztruhen jetzt `6%s Dukaten`7 zusammengespart.", $neudukaten);
			output("Einen kleinen Moment lang vergi�t du alles um dich herum und fragst dich ob das wirklich richtig war.`n`n");
			output("Du schlie�t deine Schatztruhe wieder sorgf�ltig ab, und wirfst noch einen letzten Blick auf die daneben stehenden Truhen.");
			output("Dann �ffnest du die schwere antike Eichent�re, auf der mittig ein goldenes Schild mit der Beschriftung `QAusgang`7 angebracht ist.");
			output("Z�gig durchquerst du den Raum mit dem Steinpodest und begibst dich wieder durch die antiken Gew�lbekeller in Richtung Clan Hallen.");
		
			addnav("Zur�ck zum Clan","clan.php");
		}
		if ($neudukaten >= $schatzgr��e) {
			output("`7Du �ffnest eine deiner Schatztruhen mit dem rostigen alten Schl�ssel.`n");
			output("In deine Schatztruhe deponierst du `6%s Dukaten`7.`n`n", $dukaten);
			output("`2\"GL�CKWUNSCH %s\"`7, schreit dich wie aus dem Nichts der Schatzmeister `2%s`7 dich an.", $session['user']['name'], $schatzmeister);
			output("Unwillk�rlich zuckst du zusammen und �berlegst dir einen kleinen Moment lang, ob du den vorlauten Zwerg erschlagen solltest...");
			output("Doch dann spricht der Zwerg `2\"Dein Verm�gen gleicht dem, was die alten ehrw�rdigen Zwerge zu sch�tzen gewu�t h�tten\"`7.");
			output("`2\"Du hast dir eine Belohnung redlich verdient\"`7, spricht er und macht einen gro�en Schritt auf dich zu.`n`n");
			output("`QEr zwinkert dir kurz zu, und im n�chsten Moment f�hlst du dich `@ST�RKER`Q.`n");
			output("`7Wie von Magie geleitet gehst du zur�ck zum Clan.");
			if ($session['user']['level'] > 1) {
				require_once("lib/battle-skills.php");
				$session['user']['attack']++;
				$session['user']['defense']++; 
			}
			set_module_pref('schatzmenge', 0);
			set_module_pref('sparungen', get_module_pref('sparungen')+1);
			set_module_pref('bonus', 0);
		
			addnav("Zur�ck zum Clan","clan.php");
		}
		page_footer();
?>