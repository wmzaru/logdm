<?php
page_header("Schatzkammer");
		output("`c`b %s `QSchatzkammer`b`c`n`n", $session['user']['name']);
		output("`7Mit dem rostigen Schl�ssel �ffnest du wiederwartend ohne Probleme die schwere Eichent�r und tritts in den dahinter liegenden Raum ein.");
		output("Die W�nde sind mit erdfarbenen Vorh�ngen verkleidet und geben dem Raum eine warme Atmosph�re.");
		output("Von der Decke h�ngt ein gewaltiger Leuchter herunter in dem gut an die Hundert Kerzen brennen.`n`n");
		output("Auf dem Boden, entlang der W�nde stehen mehrere massive aus Adamit bestehende Schatztruhen");
		output("Insgesamt hast du in deinen Schatztruhen schon `6%s Dukaten`7 zusammengespart.", $schatzmenge);
		output("Vielleicht, denkst du dir, schaffst du es eines Tages insgesamt `6%s Dukaten`7 zusammen zu tragen um vom Schatzmeister die Belohnung zu erhalten.`n`n", $schatzgr��e);
		output("Du schaust dir einige Zeit deine Reicht�mer an und entsinnst dich, weswegen du eigentlich hier herkamst.");
		output("Dessen bewu�t, dass deine Reicht�mer diesen Raum nie wieder verlassen werden, kannst du nur die Dukaten die du bei dir tr�gst in den Schatztruhen deponieren.");
		
		addnav("Optionen");
		addnav("Dukaten deponieren", "runmodule.php?module=clanabteilungen&op=keller&act=deponieren");
		addnav("Raum verlassen", "runmodule.php?module=clanabteilungen&op=keller&act=verlassen");
		page_footer();
?>