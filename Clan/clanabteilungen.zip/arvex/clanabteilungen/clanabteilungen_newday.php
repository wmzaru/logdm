<?php
set_module_pref('vertiefung', 0);
			if (get_module_pref('sparungen') > 0 && $session['user']['level'] == 1){
				if (get_module_pref('bonus') == 0){
				$belohnung = get_module_pref('sparungen');
				require_once("lib/battle-skills.php");
				$session['user']['attack']+=$belohnung;
				$session['user']['defense']+=$belohnung;
				output("`n`7Du erh�lst eine Belohnung, weil deine Reicht�mer denen der alten und ehrw�rdigen Zwerge glichen.`n");
				set_module_pref('bonus', 1);
			}
		}
?>