<?php
page_header("Steinpodest");
		output("`c`b`QSteinpodest`b`c`n`n");
		output("Du steigst auf das Podest aus Stein, die Fackeln flammen auf und blenden leicht.");
		output("Ein Zwerg schreitet in der Vertiefung gegen�ber durch die massive Wand hindurch, und kommt auf dich zu.");
		output("Er bleibt genau auf der H�lfte zwischen dir und der Vertiefung stehen.`n`n");
		output("`2\"Hi-ho %s, willkommen im Gew�lbekeller.\"`7, so begr��t dich der Schatzmeister `2%s`7.",($session['user']['name']), $schatzmeister);
		output("`2\"Ich bin der Schatzmeister und verwalte deine Dukaten auf eine besondere Art und Weise\"`7, erkl�rt er dir.");
		output("`2\"Du sparst hier f�r die Ewigkeit ...\"`7, kichert, und macht eine k�nstlerische Atempause.");
		output("`2\" ... lange ... sehr lange kannst du hier sparen\"`7, erkl�rt er dir und �berreicht ein Pergament an dich.`n`n");
		output("Auf dem Pergament steht in goldenen Lettern:`n");
		output("`6Heiliger und Magischer Ort, verwaltet vom Schatzmeister `2%s`6.`n", $schatzmeister);
		output("Dieser Ort wurde von den �ltesten Zwergen vor Urzeiten erschaffen.`n");
		output("Mehre dein Verm�gen, vergr��ere deine Besitzt�mer, und der Schatzmeister `2%s`6 wird dich Belohnen.`n", $schatzmeister);
		output("Spare hier ein Verm�gen von `^%s`6 an!`n`n", $schatzgr��e);
		output("`7Du rollst das Pergament wieder zusammen und �berlegst wie du dich entscheiden sollst.");
		
		addnav("Optionen");
		addnav("Dukaten anh�ufen", "runmodule.php?module=clanabteilungen&op=keller&act=dukaten");
		if ($vertiefung == 0) addnav("Vertiefung untersuchen", "runmodule.php?module=clanabteilungen&op=keller&act=vertiefung");
		addnav("Zur�ck zum Clan","clan.php");
		page_footer();
?>