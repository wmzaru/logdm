<?php
page_header("Dukaten ansparen");
		output("`c`b`QDukaten ansparen`b`c`n`n");
		if ($session['user']['gold'] == 0) {
			output("`7Grade als du dich dazu entschlie�t deine Dukaten zu sparen, bemerkst du das du gar keine dabei hast.");
			output("Du hast den ganzen Weg hierhin umsonst gemacht, denkst du dir und �rgerst dich selbst �ber deine Schusseligkeit.");
			output("Aber als ob das nicht schon schlimm genug w�re, spricht der Schatzmeister `2%s`7 zu dir:`n`n", $schatzmeister);
			output("`2\"Du hast keine Dukaten bei dir?\"`7, fragt er dich.");
			output("`2\"Das wird dich teuer zu stehen kommen %s\"`7, und spricht einen Zauber �ber dich aus.`n`n",($session['user']['name']));
			require_once('lib/e_rand.php');
			switch(e_rand(1,2)){
				case 1:
        			if ($session['user']['experience'] > 100) {
        				output("`7Du f�hlst eine noch gr��ere innere Leere in deinem Kopf, als wie sie schon vorher war.`n");
        				output("`7Du verlierst `4%s`7 Erfahrungspunkte.",round($session['user']['experience']*0.05));
					$session['user']['experience']=round($session['user']['experience']*0.95);
				}
				elseif ($session['user']['experience']<=100){
					output("`7Du f�hlst eine noch gr��ere innere Leere in deinem Kopf, als wie sie schon vorher war.`n");
        				output("`7Du verlierst `4ALLE`7 Erfahrungspunkte.");
        				$session['user']['experience']=0;
        			}
				break;
				case 2:
				if ($session['user']['hitpoints']<=10) {
					output("`7Du wartest, doch nichts passiert.");
					output("Dann h�lt dir der Schatzmeister einen Spiegel vors Gesicht und du zuckst beim Anblick zusammen.`n");
					output("Du hast deutlich an Charme verloren.");
					$session['user']['charm']-=2;
				}
				elseif ($session['user']['hitpoints']>=11) {
					output("`7Eine magische Faust erscheint und schmettert dich zu Boden.`n");
					output("Du �berlebst den magischen Angriff mit M�he und Not.");
					$session['user']['hitpoints']=1;
				}
				break;
			}
			output("`n`n`2\"La� dir das eine Lehre sein\"`7, ruft `2%s`7 hinter dir her.", $schatzmeister);
			addnav("Zur�ck zum Clan","clan.php");
		}
		elseif ($session['user']['gold'] > 0) {
			output("`7Du hast dich entschlossen deine Dukaten hier zu sparen.");
			output("Vorsichtig sagst du `Q\"Ich m�chte meine Dukaten hier sparen, aber ... \"");
			output("`#\"Genug! Schweig!\"`7, bricht der Schatzmeister dich ab und geleitet dich vor die Vertiefung in der Wand.");
			output("Etwas irritiert stehst du da und beobachtest, wie der Zwerg uralte mystische Beschw�rungen murmelt.");
			output("Ein Blitz zuckt durch den Gew�lbekeller und taucht den gesamten Raum f�r kurze Zeit in ein bl�uliches Licht.`n`n");
			output("Jetzt siehst du in der Vertiefung einen winzigen wirbelnden Strom.");
			output("Langsam w�chst der Wirbel an, un du erkennst darin unz�hlige kleine T�ren die alle im Strom kreisen.");
			output("Es gibt einen lauten `QKNALL `7 und du weichst einen Schritt zur�ck.`n`n");
			output("Vor dir ist jetzt keine Vertiefung mehr zu erkennen, stattdessen steht dort eine Eichent�r.");
			output("Die Eichent�r ist mit einer vielzahl von Schnitzerreien verziert und mit schweren Mithrillbeschl�gen versehen.");
			output("In der Mitte der Eichent�r ist ein kleines Schild angebracht, mit der Aufschrift:`n`n");
			output("`QPrivate Schatzkammer`n");
			output("Eigent�mer: %s`n`n", $session['user']['name']);
			output("`7Der Schatzmeister reicht dir einen gro�en alten, und vor allem, rostigen Schl�ssel.");
			
			addnav("Private Schatzkammer");
			addnav("Eintreten", "runmodule.php?module=clanabteilungen&op=keller&act=kammer");
		}
		page_footer();
?>