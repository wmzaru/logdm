<?php
if ($session['user']['clanrank'] >= CLAN_MEMBER){
				addnav("Abteilungen");
				addnav("Vorschlagzimmer", "runmodule.php?module=clanabteilungen&op=vorschlag");
				addnav("Gew�lbekeller", "runmodule.php?module=clanabteilungen&op=gewoelbe");
			}
?>