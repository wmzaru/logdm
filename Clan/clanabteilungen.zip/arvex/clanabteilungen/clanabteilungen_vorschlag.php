<?php
page_header("Vorschlagzimmer");
			output("`c`b`QVorschlagzimmer`b`c`n`n");
			output("`7Du tritts durch eine, selbst f�r Zwerge, wirklich kleine T�r in einen noch kleiner wirkenden Raum.");
			output("Erstaunt dar�ber, dass selbst in diesem Raum noch ein kleiner wackliger Tisch untergebracht wurde schaust du dich weiter um.");
			output("�berall in diesem Raum liegen leere und beschriebene Zettel herum, sei es auf dem Boden, an der Wand, hinter der T�r oder auf dem Tisch.");
			output("Erst jetzt bemerkst du ein sehr kunstvolles und edel verziertes Schild �ber dem Tisch:`n`n");
			output("`QWillkommen im Vorschlagzimmer`n`n`7");
			output("Darunter befindet sich ein, wahrscheinlich damit es nicht verloren geht, sorgf�ltig eingerahmtes Pergament.");
			output("Es ist f�r dich etwas schwierig die Schrift zu entziffern, da es sich um eine l�ngst nicht mehr gesprochene Sprache handelt.");
			output("Schlu�endlich hast du einen Teil davon entziffern k�nnen und reimst dir daraus folgenden Inhalt zusammen:`n`n");
			output("`QHier kannst du Vorschl�ge hinterlassen`n");
			output("Nimm dir einen Zettel und hinterlasse deinen Vorschlag`n");
			output("Sei dir bewu�t dar�ber, dass dein Vorschlag �berlesen werden kann`n");
			output("Sei dir bewu�t dar�ber, dass dein Vorschlag bewu�t ignoriert werden kann`n");
			output("Gezeichnet: `4Die ehrw�rdige Clanf�hrung`7`n`n");
			output("Nun liegt es ganz an dir, ob du den Mumm hast einen Vorschlag hier zu hinterlassen, obwohl dieser ignoriert werden k�nnte.`n`n`n");
			output("`@Bereits eingereichte Vorschl�ge:`n");
			
			require_once("lib/commentary.php");
			addcommentary();
                	viewcommentary ("Clan - Vorschlag", "Vorschl�ge", 15, "sagt");
                	if ($session['user']['clanrank'] >= CLAN_MEMBER){
				addnav("Abteilungen");
				addnav("Vorschlagzimmer", "runmodule.php?module=clanabteilungen&op=vorschlag");
				addnav("Gew�lbekeller", "runmodule.php?module=clanabteilungen&op=gewoelbe");
				addnav("Zur�ck zum Clan","clan.php");
			}
			page_footer();
?>