<?php
module_addhook("footer-clan");
    	module_addhook("newday");
    	module_addhook("dragonkill");
?>