<?php
page_header("Schatzkammer");
		output("Irgendwie kommen dir Zweifel und du denkst das dies nicht der richtige Zeitpunkt ist, wirfst noch einen letzten Blick auf die an der Wand stehenden Schatztruhen.");
		output("Dann �ffnest du die schwere antike Eichent�re, auf der mittig ein goldenes Schild mit der Beschriftung 'QAusgang`7 angebracht ist.");
		output("Z�gig durchquerst du den Raum mit dem Steinpodest und begibst dich wieder durch die antiken Gew�lbekeller in Richtung Clan Hallen.");
		
		addnav("Zur�ck zum Clan","clan.php");
		page_footer();
?>