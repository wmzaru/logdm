<?php
$vertiefung = get_module_pref("vertiefung");
		page_header("Gew�lbekeller");
		output("`c`b`QGew�lbekeller`b`c`n`n");
		output("`7Du steigst eine schmale, aus Stein gehauene, Treppe in den Gew�lbekeller deines Clans herunter.");
		output("Am Fu�ende der Treppe stehst du in absoluter Schw�rze, doch wie aus Gewohnheit tastet du an der linken Wand nach den dort h�ngenden Fackeln.");
		output("Du ziehst eine aus der Halterung und unmittelbar danach entz�ndet sie sich auf magische Weise.");
		output("Vor dir erstreckt sich nicht ein einfacher Gew�lbekeller, sondern ein beinahe antikes Labyrinth.`n`n");
		output("Die W�nde des Gew�lbekellers sind in regelm��igen Abst�nden mit Facken gespickt, die sich immer wenn du in Reichweite kommst selber entz�nden und dir so den Weg ausleuchten.");
		output("Der Boden ist �ber Millenien hinweg mit Moos zugewachsen und bildet so einen nat�rlichen Teppich.");
		output("Die W�nde sind nicht g�nzlich mit Moos bewachsen und so kannst du noch die Struktur der altert�mlichen von Hand gehauenen Quader erkennen.`n`n");
		output("Langsam, ganz langsam gehst du den dir bekannten Weg entlang.");
		output("`Q\"Was war das?\"`7denkst du dir, hast du da ein Ger�usch geh�rt oder Spielen dir deine Sinne hier unten nur einen Streich?");
		output("Du beschleunigst deine Schritte etwas, bis du vor einer schweren massiven Holzt�re stehst.`n`n");
		output("Deine Fackel verlischt in dem Moment, wo du die schwere Holzt�re �ffnest.");
		output("Der Raum in dem du dich jetzt befindest ist, im Gegensatz zu den vorherigen G�ngen, sehr gut ausgeleuchtet und bietet dank seiner quadratischen Form, mehr Platz.");
		output("Mittem im Raum befindet sich ein kleines aus Stein gehauenes Podest, und genau gegen�ber der Eingangst�re befindet sich eine rechteckige Vertiefung in der Wand.");
		
		addnav("Optionen");
		addnav("Aufs Podest steigen","runmodule.php?module=clanabteilungen&op=keller&act=podest");
		if ($vertiefung == 0) addnav("Vertiefung untersuchen","runmodule.php?module=clanabteilungen&op=keller&act=vertiefung");
		addnav("Zur�ck zum Clan","clan.php");
		page_footer();
?>