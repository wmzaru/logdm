<?php
// 1Feb2006
// this is a hack of clan news module

function citynews_getmoduleinfo(){
	$info = array(
		"name"=>"City News",
		"category"=>"Village",
		"author"=>"`2Robert `7based on`ndying Clan News",
		"version"=> "1.1",
		"download"=>"http://dragonprime.net/index.php?topic=2215.0",
		"settings"=> array(
			"City News Settings, title",
			"maxevents"=>"Maximum number of news events to display,range,1,5,1|1",
			"cityloc"=>"Which city does the news appear,location|".getsetting("villagename", LOCATION_FIELDS),
			"newdaytime"=>"Display in village - time till new day?,bool|1",
			"newdaytime2"=>"Display in Shades - time till new day?,bool|1",
		)
	);
	return $info;
}

function citynews_install(){
	module_addhook("changesetting");
	module_addhook("village-desc");
	module_addhook("shades");
	return true;
}

function citynews_uninstall(){
	return true;
}

function citynews_dohook($hookname, $args){
	global $session;
	switch ($hookname) {
	case "changesetting":
	if ($args['setting'] == "villagename") {
		if ($args['old'] == get_module_setting("cityloc")) {
			set_module_setting("cityloc", $args['new']);
		}
	}
	break;
	case "village-desc":
	$vtime=get_module_setting("newdaytime");
	if ($vtime == 1) {
	$secstonewday = secondstonextgameday();
	output("`@Next new game day in: `!%s`0`n",
			date("G\\h, i\\m, s\\s \\(\\r\\e\\a\\l\\ \\t\\i\\m\\e\\)",$secstonewday));
	}
	$maxevents = get_module_setting("maxevents");
	$sql = "SELECT " . db_prefix("news") . ".* FROM " . db_prefix("news") . " ORDER BY " . db_prefix("news") . ".newsid DESC LIMIT " . $maxevents;
	$res = db_query($sql);
	if (db_num_rows($res)) {
		output("`n`b`&Recent News:`b`0`n");
		rawoutput("<ul type='square'>");
		tlschema("news");
		for ($i=0; $i<db_num_rows($res); $i++) {
			$row = db_fetch_assoc($res);
			tlschema($row['tlschema']);
			if ($row['arguments'] != "") {
				$args = unserialize($row['arguments']);
				array_unshift($args, $row['newstext']);
				$news = call_user_func_array("sprintf_translate", $args);
			}else{
				$news = translate_inline($row['newstext']);
			}
			tlschema();
			if ($i!=0) citynews_outputseparator();
			rawoutput("<li>");
			output_notl(" $news`0");
		}
		rawoutput("</ul>");
		tlschema();
	}
	break;
	case "shades":
	global $session;
	$shadestime=get_module_setting("newdaytime2");
	if ($shadestime == 1) {
	$secstonewday = secondstonextgameday();
	output("`@Next new game day in: `!%s`0`n",
			date("G\\h, i\\m, s\\s \\(\\r\\e\\a\\l\\ \\t\\i\\m\\e\\)",$secstonewday));
	}
	break;
}
	return $args;
}
function citynews_outputseparator(){
	rawoutput("<table cellspacing=0><tr><td height=3></td></tr></table>");
}
?>