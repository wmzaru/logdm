<?php
if ($_GET['op']=="download"){ // this offers the module on every server for download
 $dl=join("",file("cityevents1b.php"));
 echo $dl;
}
/**************
Name: City Events 1b
Author: eph, based very loosely on Azrael by Shannon Brown 
Version: 1.0
Release Date: 09-30-2005
About: Just some random flavour texts for my villages.
Requires the popular alignment mod. The flavour texts are especially for the Toki (rabbit) race, just change them harcoded or with the translator tool if you want more generic ones.

This differs from City Events 1 which runs on brassfortress.de, as this one doesn't require the collectible system to work.
*****************/
//require_once("common.php");
//require_once("lib/sanitize.php");
require_once("lib/villagenav.php");
require_once("lib/http.php");
function cityevents1b_getmoduleinfo(){
	$info = array(
		"name"=>"City Events 1b (Toki)",
		"version"=>"1.0",
		"author"=>"eph",
		"category"=>"Village Specials",
		"download"=>"modules/cityevents1b.php?op=download",
        "settings"=>array(
            "City Events - Settings,title",
			"cityevents1bloc"=>"Use the events for what city?,location|".getsetting("villagename", LOCATION_FIELDS)
        )
		);
    return $info;
}

function cityevents1b_install(){
	module_addhook("changesetting");
	module_addeventhook("village", "require_once(\"modules/cityevents1b.php\"); return cityevents1b_test();");
    return true;
}

function cityevents1b_uninstall(){
    return true;
}

function cityevents1b_dohook($hookname,$args){
    global $session;
    switch($hookname){
   	case "changesetting":
		if ($args['setting'] == "villagename") {
			if ($args['old'] == get_module_setting("cityevents1bloc")) {
				set_module_setting("cityevents1bloc", $args['new']);
			}
		}
		break;
	}
    return $args;
}

function cityevents1b_test(){
	global $session;
	if ($session['user']['location'] == get_module_setting("cityevents1bloc","cityevents1b")) {
		$canappear = 1;
	}else{
		$canappear = 0;
	}
	$chance=($canappear?100:0);
	return $chance;
}

function cityevents1b_runevent($type) {
    global $session;
   	$session['user']['specialinc'] = "";
	$from = "village.php?";
	$op = httpget('op');
	$encounter=e_rand(1,8);
	if ($op == "") {
		switch($encounter)
		{
			case"1":
 				// give a small hp bonus
		   		$session['user']['specialinc'] = "module:cityevents1b";
				output("As you spend some time relaxing with a cup of tea in a street cafe, you spot some toki boys playing \"catch\" on the street. Some girls with fluffy bright fur stand aside and giggle at the scene, occasionally giving shouts of encouragement for one or the other.`n`n Watching these kids calms you down. It's good to know some people can live in peace, without fear of the dragon.`n`n You feel relaxed and gain some hitpoints.`n`n");
				$session['user']['hitpoints']+=3;
			break;
			case"2":
				// just a flavour text
	    		$session['user']['specialinc'] = "module:cityevents1b";
				output("All of a sudden a shadow fills the sky and everyone in the city dives for cover. You quickly duck into a narrow alley and peek around the corner to see what's happening.`n");
				output("In the sky, you spot a dragon. The mighty beast casually swoops down on the village, almost touching the roofs of the tallest buildings. It lets out a tremendous roar before it returns to the sky and vanishes out of sight.`n`n");
				output("Slowly the streets fill with people again, but everyone is a bit touchy about loud noises right now. Toki ears move nervously at every sound.`n It seems the dragon was just bored and not on the hunt. You were lucky.`n`n");
			break;
			case"3":
				// give a positive buff if player is Toki, else just give a flavour text
	 	  		$session['user']['specialinc'] = "module:cityevents1b";
				output("A big festival takes place at the village. You ask one of the villagers what's going on and get told it's the time of the Big Clover Festival today. `n");
				output("Several times a year the toki celebrate their harvest with a big party.`n`n You listen to the troubadours and watch the girls dance for a while.`n`n");
				if ($session['user']['race'] == "Toki"){
					output("Your fellow Toki invite you to join the party, and you happily comply.`n When you leave the festival some time later to go on with your business, a young girl quickly pins a lucky clover on your armour.`n`n"); 
					// This buff survives new day.
					apply_buff('cityevents1b',
					array(
						"name"=>"`@Lucky Clover",
						"rounds"=>15,
						"wearoff"=>"Your lucky charm wears off.",
						"defmod"=>1.02,
						"survivenewday"=>1,
						"roundmsg"=>"Your good-luck charm helps you evade attacks.",
						)
					);
				}		
			break;
			case"4":
				// let the user lose some charm 
		  		$session['user']['specialinc'] = "module:cityevents1b";
				output("You are sauntering down the street, not suspecting that anything might be wrong, as out of the blue a dove swoops over your head and drops one of its bombs on you. SPLASH!`n`n");
				output("It leaves an ugly stain on your armour. You lose 1 charm!`n`n");
				$session['user']['charm']-=1;
			break;
			case"5":
				// have the user find a bag with random outcomes
				$session['user']['specialinc'] = "module:cityevents1b";
				output("In the middle of the street you find a lonely bag, and nobody around who might own it. You pick it up, and it has quite some weight.");
				addnav("Search for the owner",$from."op=baghelp");
				addnav("Loot the bag",$from."op=bagsteal");
				addnav("Leave it where it is",$from."op=bagignore");
			break;
			case"6":
				// just another flavour text
				output("In a dark alley you spot shady figures. As you look closer you notice one toki stealthily giving a dark bundle to another toki guy. Sure to be on the track of smugglers you sneak up closer to the scene.`n");
				output("Suddenly something drops from the bundle. It is... a carrot! Some smugglers those are!`n");
				output("Embarrassed you quickly make off to the open street with an inconspicious whistle.`n`n");
		addnews("%s proved to have zero detective skills!", $session['user']['name']);
			break;			
			case"7":
				// just another flavour text
				output("You stop to watch a toki family working on their new home.`n");
				output("Their architectural style is very fascinating. While the mother and daughter dig a deep burrow, the husband and son sit aside and have lunch.`n");
				output("After pondering for a while about this lifestyle you decide it's time to go on with your own affairs.`n`n");
			break;			
			case"8":
				// just another flavour text
				output("You stop for a moment to study the items in a shop decoration when all of a sudden someone runs into you.`n");
				output("Staggering some you manage to keep your balance. With a curse you wheel around to ask what that was supposed to mean. Behind you, a male toki with bright white fur crawls on all four. \"Where is it... My watch, where is it? I'm late! The queen will be angry...\"`n");
				output("Finally he finds what he dropped before when he bumped into you. The toki jumps to his feet, a golden pocket watch in his palm. \"The queen will be angry! I'm late!\" Without even noticing you he vanishes down the street in long leaps.`n`n");
			break;			
		}

	}elseif ($op == "baghelp") {
		output("Going from house to house you try to find the owner of the bag. Finally you arrive at Mrs. Honeybunny's cottage, where you meet an old Toki lady who is delighted to get her bag back. While this deed leaves a warm feeling in your chest, you notice the sun setting. The search has cost you the time for a forest fight.`n`n");
			if ($session['user']['turns']>=1) {
				$session['user']['turns']-=1;
			}
		$bagHelpReward=e_rand(1,3);
			if ($bagHelpReward == 1) {
				output("The old lady presses a small object in your palm and thanks you again before vanishing in her house. In your hand is `5a GEM`0!`n`n");
				$session['user']['gems']+=1;
			}
			if ($bagHelpReward == 2) {
				output("The old lady presses a small purse in your palm and thanks you again before vanishing in her house. In the purse you find `6 100 GOLD`0!`n`n");
				$session['user']['gold']+=100;
			}
			if ($bagHelpReward == 3) {
				output("The old lady thanks you again and promises to tell everyone about your noble deed before vanishing in her house. While the search didn't gain you something material, at least you feel like an exceptionally good person.");
				if (is_module_active('alignment')) {
					set_module_pref('alignment',(get_module_pref('alignment','alignment')+2),'alignment');
				}
				addnews("%s heroically returned a lost bag of goods to Mrs. Honeybunny!", $session['user']['name']);
			}
	
	}
	elseif ($op == "bagsteal") {
		output("You pick up the bag and decide to loot it, since there seems to be no owner around.`n`n");
		$bagSteal=e_rand(1,3);
			if ($bagSteal == 1) {
				output("You carefully open the bag and peek inside. In the bag you find `5a GEM`0!`n");
				output("But unfortunately, the town gossip spots you and gives you an accusing glare. You feel like a bad person.`n`n");
				$session['user']['gems']+=1;
				if (is_module_active('alignment')) {
					set_module_pref('alignment',(get_module_pref('alignment','alignment')-1),'alignment');
				}
				addnews("%s was seen looting Mrs. Honeybunny's handbag!", $session['user']['name']);
			}
			if ($bagSteal == 2) {
				output("You carefully open the bag and peek inside. In the bag you find `6 300 GOLD`0!`n`n");
				output("But unfortunately, the town gossip spots you and gives you an accusing glare. You feel like a bad person.`n`n");
				$session['user']['gold']+=300;
				if (is_module_active('alignment')) {
					set_module_pref('alignment',(get_module_pref('alignment','alignment')-1),'alignment');
				}
				addnews("%s was seen looting Mrs. Honeybunny's handbag!", $session['user']['name']);
			}
			if ($bagSteal == 3) {
				output("You carefully open the bag and peek inside. Suddenly the bag develops razor sharp teeth and bites you in the hand!`n`n");
				output("Attracted by your scream a toki wizard comes around the corner. With a mean smile he grabs his bag and walks off, leaving you bleeding on the street.");
				output("You lose half of your current hitpoints!`n`n");
				$session['user']['hitpoints']=(int)($session['user']['hitpoints']/2);
				addnews("%s has been bitten by a malicious handbag!", $session['user']['name']);
			}
	}
	elseif ($op == "bagignore") {
		output("You decide the owner will surely come looking for it, and since you don't know anybody in this street you simply leave the bag where it is and walk away.");
	}
}
?>
