City Creator v1.0.1 Beta

Requires the modified 'cities' module v1.2 which you'll find in this zip.

If you have the 'cityprefs' module installed then upload the modified v1.1.0 which is in this zip. If you don't have it installed then it's safe to ignore.

Additional module 'city_routes' is also included.

:)