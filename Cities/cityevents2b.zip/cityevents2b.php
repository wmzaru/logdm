<?php
if ($_GET['op']=="download"){ // this offers the module on every server for download
 $dl=join("",file("cityevents2b.php"));
 echo $dl;
}
/**************
Name: City Events 2b (Elves)
Author: eph, based very loosely on Azrael by Shannon Brown 
Version: 1.0
Release Date: 09-30-2005
About: Just some random flavour texts for my villages.
Works with the popular alignment mod. The flavour texts are especially for the Elven race, just change them harcoded or with the translator tool if you want more generic ones.

*****************/
//require_once("common.php");
//require_once("lib/sanitize.php");
require_once("lib/villagenav.php");
require_once("lib/http.php");
function cityevents2b_getmoduleinfo(){
	$info = array(
		"name"=>"City Events (Elves)",
		"version"=>"1.0",
		"author"=>"eph",
		"category"=>"Village Specials",
		"download"=>"modules/cityevents2b.php?op=download",
        "settings"=>array(
            "City Events - Settings,title",
			"cityevents2bloc"=>"Use the events for what city?,location|".getsetting("villagename", LOCATION_FIELDS)
        )
		);
    return $info;
}

function cityevents2b_install(){
	module_addhook("changesetting");
	module_addeventhook("village", "require_once(\"modules/cityevents2b.php\"); return cityevents2b_test();");
    return true;
}

function cityevents2b_uninstall(){
    return true;
}

function cityevents2b_dohook($hookname,$args){
    global $session;
    switch($hookname){
   	case "changesetting":
		if ($args['setting'] == "villagename") {
			if ($args['old'] == get_module_setting("cityevents2bloc")) {
				set_module_setting("cityevents2bloc", $args['new']);
			}
		}
		break;
	}
    return $args;
}

function cityevents2b_test(){
	global $session;
	if ($session['user']['location'] == get_module_setting("cityevents2bloc","cityevents2b")) {
		$canappear = 1;
	}else{
		$canappear = 0;
	}
	$chance=($canappear?100:0);
	return $chance;
}

function cityevents2b_runevent($type) {
    global $session;
   	$session['user']['specialinc'] = "";
	$from = "village.php?";
	$op = httpget('op');
	$encounter=e_rand(1,8);
	if ($op == "") {
		switch($encounter)
		{
			case"1":
 				// take some hitpoints away
		   		$session['user']['specialinc'] = "module:cityevents2b";
				output("Many small animals call the rustling treetops of the elven city their home. As you sit in the shadow of an oak to have a snack from your backpack, a curious squirrel comes down to you. Intently it reviews your lunchpack from a low branch.`n");
				output("The animal is so cute, you can't help yourself but reach out for it, offering some breadcrumbs on your open palm.`n`n");
				output("The squirrel, however, isn't pleased with your generous offer. It bites you in the thumb!");
				output("Although the wound isn't deep, the throbbing pain is quite annoying. You lose some hitpoints!`n`n");
				$session['user']['hitpoints']-=3;
			break;
			case"2":
				// just a flavour text
	    		$session['user']['specialinc'] = "module:cityevents2b";
				output("As you step out from one of the log houses on the ground you get to witness an interesting scene.`n");
				output("An elven wizard and a faerie have an argument, and while the wizard tries to cast one \"Gush of Water\" spell after the other on the tiny creature, she buzzes around his head and keeps hitting on him with a tiny club. `n`n");
				output("You stand there for a while, watching this mostly irritating battle and wondering how it came to pass. Suddenly both combatants stop in their actions and turn towards you. \"Hey, what'cha staring at, eh?!\" the faerie demands to know, pouting. \"Never seen a lovers' quarrel before?!\" The elven wizard just raises an eyebrow. \"Uhm... nothing.\" you reply and make for a speedy getaway.`n`n");
			break;
			case"3":
				// give a positive buff if player is elf, else just give a flavour text
	 	  		$session['user']['specialinc'] = "module:cityevents2b";
				output("You sit on a large log which serves as a rustic bench and enjoy the quiet serenity of the elven village for a while, when you notice something moving between the trees at the edge of the merchant quarter.`n`n");
				output("You look closer and barely believe your eyes, for it is a dryad. The green-skinned woman is naked and of breath-taking beauty, her long dark hair growing up from her head like the twigs of a young tree.`n`n");
				output("You sit there in awe with your jaw dropped at the sight of this rare guardian of the woods. The dryad looks you in the eyes for a moment, then her claws twitch for a second and she vanishes into the bark of a large tree.`n`n");
				if ($session['user']['race'] == "Elf"){
					output("The leaves of the tree softly whisper to you. You understand the dryad acknowledges you as an ally against the dark creatures that dwell in the woods, and she grants you a favour today`n`n"); 
					// This buff survives new day.
					apply_buff('cityevents2b',
					array(
						"name"=>"`qDryad's Favour",
						"rounds"=>15,
						"wearoff"=>"The trees go silent.",
						"atkmod"=>1.02,
						"survivenewday"=>1,
						"roundmsg"=>"Tree branches swat your enemy.",
						)
					);
				}		
			break;
			case"4":
				// let the user gain some charm 
		  		$session['user']['specialinc'] = "module:cityevents2b";
				output("Stepping into the open from a cozy tea house you are faced with a white rabbit bouncing directly in your direction. Out of reflex you snatch it and pick it up.`n A small elven girl runs up to you, panting. She can't be older than 3 or 4 years, and rivers of tears flow from the large eyes in her round face. \"Hoppie, never do that again!\" she cries, taking the runaway from you and cuddling it in her arms. \"I'm Hannah. Thank you very much for catching my little Hoppie for me!\" she says and walks back home with her load.`n`n");
				output("Your noble deed doesn't go unnoticed. You gain 1 charm!`n`n");
				$session['user']['charm']+=1;
			break;
			case"5":
				// have the user find a scroll with random outcomes
				$session['user']['specialinc'] = "module:cityevents2b";
				output("In the shadow of a tree house you pick up a lonely sheet of paper behind a trash can. When you unfold it you discover it's actually an instant spell scroll!`n While the actual magic formula is clearly readable, the spell description must have been written by a dyslexic with chills - it's utterly illegible! So you have a scroll but don't know what it does.");
				addnav("Cast the spell anyway",$from."op=spellread");
				addnav("Try to sell it to a magician",$from."op=spellsell");
				addnav("Put it in the trashcan",$from."op=spellignore");
			break;
			case"6":
				// just another flavour text
				output("Today the elves celebrate the rich apple harvest with a big festival. There are apple cakes, apple pancakes, chocolate coated apples and loads of other apple recipes.`n The villagers urge you to sample everything, and an hour later you are stuffed up to your ears and decide it's time to part with the partying villagers.`n`n");
				output("You almost feel like an apple yourself as you leave the festival place.`n`n");
			break;			
			case"7":
				// just another flavour text
				output("Some elves sit at the small river which crosses the city.`n");
				output("They chatter lazily while watching their fishing poles.`n");
				output("For a second you think that it would be nice to go fishing too, but then you remember your business and walk on.`n`n");
			break;			
			case"8":
				// see elven queen/king, gain forest fight
				output("You are sauntering down the market alley, when you are faced with a most marvelous sight: The elven %s %s came to town for a visit! The undisputed leader of the elven race gazes over the city from a balcony.`n",$session['user']['sex']?"queen":"king",$session['user']['sex']?"herself":"himself");
				output("Filled with awe you stand still as a statue, staring at the most important member of the elven race. %s is of legendary beauty, wearing ornamented silken robes with golden embroidery. Long silver hair frames a face with almost black eyes and porcelain skin.`n",$session['user']['sex']?"Titania":"Oberon");
				output("You fall in love at first sight. With a sigh you return to the forest, determined to save the home of this most charming being from the evil creatures`n`n");
				output("You gain a forest fight!");
				addnews("%s was seen lovesick at Silent Whisper!", $session['user']['name']);
				$session['user']['turns']+=1;
			break;			
		}

	}	elseif ($op == "spellread") {
		output("Feeling bold you read the magic formula from the instant spell scroll. The paper glows for a moment before it crumbles to dust. A tingling feeling crawls through your body.`n`n");
		$scrollReward=e_rand(1,3);
			if ($scrollReward == 1) {
				output("Red light cascades down on you and you gain a forest fight!`n`n");
				$session['user']['turns']+=1;
			}
			if ($scrollReward == 2) {
				output("Black light cascades down on you and you notice there's something wrong with your gem pouch!`n`n");
				if ($session['user']['gems']>1){
				output("One of your gems turned into black sludge!`n`n");
				$session['user']['gems']-=1;
				}
				else {
				output("Luckily you had no gems on you!`n`n");
				}
			}
			if ($scrollReward == 3) {
				output("Golden light cascades down on you. In front of you forms a pile of gold!");
				output("You quickly count your new riches, and they sum up to `6 300 GOLD`0!`n`n");
				$session['user']['gold']+=300;
			}
	
	}
	elseif ($op == "spellsell") {
		output("You don't trust this makeshift scroll, but you hope the elven wizards can make some use from it. Maybe it can reek you some benefit after all.`n`n");
		$scrollSell=e_rand(1,3);
			if ($scrollSell == 1) {
				output("You show the scroll to a group of wizards and one of them recognizes it as his own. As it turns out it's actually a shopping list accompanied by a small \"Remember me!\" spell, and the embarrassed elf makes quite a scene and hurls a lightning bolt at you. You make for a speedy getaway and dump the scroll in the nearest trashbin.`n`n");
				output("But unfortunately, the town gossip spots you and starts laughing. You lose some charm!`n`n");
				if ($session['user']['charm']>=1) {
				$session['user']['charm']-=1;
				}
				addnews("%s was spotted running away from the elven city with a lightning bolt closely behind!", $session['user']['name']);
			}
			if ($scrollSell == 2) {
				output("The scroll turns out to contain only a minor fertilizer spell, but after some haggling you manage to get `5 1 gem`0 for it!`n`n");
				$session['user']['gems']+=1;
			}
			if ($scrollSell == 3) {
				output("After some searching you meet a very talkative young elven woman who introduces herself as Lena the Apprentice. She thanks you over and over for finding the scroll she lost just this morning, and without further ado she takes it away from you and makes off with it!`n`n");
				output("Seems like this deed didn't gain you more than a satisfied feeling.");
				output("You feel like a good person!`n`n");
				if (is_module_active('alignment')) {
					set_module_pref('alignment',(get_module_pref('alignment','alignment')+1),'alignment');
				}
			}
	}
	elseif ($op == "spellignore") {
		output("You simply don't understand people who can't even dispose correctly of their trash. Muttering something about pollution you pick up the scroll and throw it in the trashbin.");
	}
}
?>
