<?php
/*YOU MUST REPORT ALL MODIFICATIONS TO THIS FILE ***IMMEDIATELY*** to dragonprime.  You are violating the license by not releasing modifications to this file.
post changes you've made, working or not working to:
*/
function cityleaders_getmoduleinfo(){
    $info = array(
        "name"=>"City Leaders",
        "version"=>"20070207",
        "author"=>"Sixf00t4 - idea from Sneakabout",
        "category"=>"Cities",
        "download"=>"http://dragonprime.net/index.php?topic=6316.0",
        "description"=>"allows players to nominate a village leader",
        "requires"=>array(
	       "cityprefs"=>"20051101|By Sixf00t4, available on DragonPrime",
		   ), 
        "settings"=>array(
	       "anarchy"=>"What percent need to call for an election?,range,1,100,1|51",
	       "clength"=>"How long is the campaigning length?,datelength|1 week",
	       "vlength"=>"How long is the voting stage?,datelength|2 days",
	       "term"=>"Use terms? (leader will need to be voted out otherwise),bool|0",           
	       "tlength"=>"How long is a term?,datelength|1 month",
	       "gemscost"=>"How many gems does it cost to run?,int|5",           
	       "goldcost"=>"How much gold does it cost to run?,int|5000",
		   ),
        "prefs"=>array(
	       "voted"=>"Did this person vote this election?,bool|0",
           "votes"=>"How many votes have they received?,int|0",
	       "run"=>"Is this person running in the election?,bool|0",
	       "banner"=>"What is this person's banner?,textarea|",
		   ),
       "prefs-city"=>array(
	       "on"=>"Allow leaders for this city?,bool|1",
	       "newcits"=>"Are players allowed to apply for new citizenship?,bool|1",
           "date"=>"Last time city had a revolt -,text|2005-01-01 00:00:00",
	       "cityhall"=>"What is the name of the city hall?,text|City Hall",
	       "leader"=>"Who is the city leader?,int|0",
	       "title"=>"What is the title of the leader?,text|Mayor",
	       "header"=>"What is the placard notice?,textarea|I'll get around to changing this when I figure out how.",
	       "cheader"=>"What is the header for the city hall?,textarea|You enter the city hall, where nothing really seems to be going on at the moment.",
	       "votes"=>"How many votes for an election?,int|0",
	       "citizens"=>"What are citizens called?,text|citizens",
	       "status"=>"What is the status of this village?,enum,
                1,Leader elected,
                2,Taking runners,
                3,Voting|2",
		   ),
    );        
    return $info;
}

function cityleaders_install(){
    module_addhook("village");
    module_addhook("bioinfo");
    module_addhook("superuser");
	$sql="Select cityid from ".db_prefix("cityprefs")."";
	$res=db_query($sql);
	for($i=1;$i<db_num_rows($res)+1;$i++){
		set_module_objpref("city",$i,"date",date("Y-m-d H:i:s"));
	}
    return true;
}

function cityleaders_uninstall() {
	return true;
}

function cityleaders_dohook($hookname,$args) {
	global $session;
    require_once("modules/cityprefs/lib.php");
    $cityid=get_cityprefs_cityid("cityname",$session['user']['location']);        
    if(get_module_objpref("city",$cityid,"on")==0) return $args; 
    $status=get_module_objpref("city",$cityid,"status");
	switch ($hookname) {
        case "bioinfo":
			rawoutput("<table><tr><td valign='top'>");
			output("Allegiance to: %s`0",get_module_pref("homecity","cities",$args['acctid']));
			rawoutput("</td></tr></table>");
		break;
        case "superuser":
			addnav("Other");
			addnav("The U.K.","runmodule.php?module=cityleaders&op=uk&from=grotto");
		break;
        case "village":
			$start=strtotime(get_module_objpref("city",$cityid,"date"));
			$length="clength";
			if($status==3) $length="vlength";
			if($status==1 && get_module_setting("term")) $length="tlength";
			$end = strtotime(get_module_setting($length), $start);
            if($status==1){
				$lead=get_module_objpref("city",$cityid,"title");
                $msg=stripslashes(get_module_objpref("city",$cityid,"header"));
                output("`n`0A nearby placard shows the %s`0's latest notice:`n`c %s`c`n`n",$lead,$msg);
            }else{
				if($end<time()){
                    if($status==1 && get_module_setting("term")) set_module_objpref("city",$cityid,"status",2);
                    elseif($status==2) set_module_objpref("city",$cityid,"status",3);
                    elseif($status==3) cityleaders_inaugurate($cityid);
					set_module_objpref("city",$cityid,"date",date("Y-m-d H:i:s"));
                }
                output("`n`b`\$The village is in revolt!  Everyone is talking about who is most fit to be the next leader!`0`n`b");
                $sql="select userid from ".db_prefix("module_userprefs")." where modulename='cityleaders' and setting='run' and value=1";
                $res=db_query($sql);
                for($i=0;$i<db_num_rows($res);$i++){
                    $row=db_fetch_assoc($res);
                    if(get_module_pref("homecity","cities",$row['userid'])==$session['user']['location'] && get_module_pref("banner","cityleaders",$row['userid'])!=""){
                        rawoutput("<div align=\"center\"><table border=\"1\" cellpadding=\"0\" cellspacing=\"0\" width=\200\" bordercolor=\"#000000\"><tr><td width=\"90%\">");
                        rawoutput("<center>");
                        $msg=stripslashes(get_module_pref("banner","cityleaders",$row['userid']));
                        output_notl("%s",$msg);
                        rawoutput("</center></td></tr></table></div><br>");
                    }
                }
            }
			$tl=cityleaders_timeleft(time(), $end);
			if($status==3) output("`nYou have %s left to vote.`n",$tl);
			elseif($status==2) output("`nThe Voting booths will open in %s.`n",$tl);
			elseif($status==1 && get_module_setting("term")) output("`nThere will be a new election in %s.`n",$tl);
            tlschema($args['schemas']['tavernnav']);
            addnav($args['tavernnav']);
            tlschema();
            addnav(array("%s",get_module_objpref("city",$cityid,"cityhall")),"runmodule.php?module=cityleaders");
        break;
	}
    return $args;
}

function cityleaders_run(){
    global $session;
    $op = httpget("op");
    $sop = httpget("sop");
    require_once("modules/cityprefs/lib.php");
    $cityid=get_cityprefs_cityid("cityname",$session['user']['location']);
    $cityhall=get_module_objpref("city",$cityid,"cityhall");
    $leader=get_module_objpref("city",$cityid,"leader");
    $status=get_module_objpref("city",$cityid,"status");
	require_once("lib/sanitize.php");
    page_header("%s",sanitize($cityhall));
    addnav("Navigation");
    if($op!="") addnav(array("Back to %s",$cityhall),"runmodule.php?module=cityleaders");
    villagenav();
    $submit=translate_inline("Submit");
    
    
	switch ($op) {
        case "chambers":
            $var=httpget('var');
            $ch=get_module_objpref("city",$cityid,"cityhall");
			addnav("Options");
			addnav(array("Change %s description",$ch),"runmodule.php?module=cityleaders&op=chambers&sop=header&var=cheader");
            addnav("Change placard message","runmodule.php?module=cityleaders&op=chambers&sop=header&var=header");
            addnav("Change title","runmodule.php?module=cityleaders&op=chambers&sop=change&var=title");
            if(get_module_objpref("city",$cityid,"newcits")) addnav("Auto deny new citizen applications","runmodule.php?module=cityleaders&op=chambers&sop=appl&var=0");
			else addnav("Allow new citizen applications","runmodule.php?module=cityleaders&op=chambers&sop=appl&var=1");
			addnav("citizen appellation","runmodule.php?module=cityleaders&op=chambers&sop=change&var=citizens");
            addnav(array("%s name",$ch),"runmodule.php?module=cityleaders&op=chambers&sop=change&var=cityhall");
			addnav("Other");
			addnav("The U.K.","runmodule.php?module=cityleaders&op=uk");
            modulehook("cityleaders-leader");
            switch ($sop) {
                case "header":
                    $newname = httppost('newname');
                    if($newname==""){
                        output("`n`n`2What would you like to change the placard message to? (max. 255 characters including color codes)`n");
                        rawoutput("<form action='runmodule.php?module=cityleaders&op=chambers&sop=header&var=$var' method='POST' autocomplete='false'>");
                        addnav("","runmodule.php?module=cityleaders&op=chambers&sop=header&var=$var");
                        $header = stripslashes(get_module_objpref("city",$cityid,$var));
                        rawoutput("<textarea name='newname' cols=50 rows=5>$header</textarea><br>");
                        rawoutput("<input type='submit' class='button' value='$submit'><br>");
                        rawoutput("<div id='previewtext'></div></form>");
                    }else{
                        require_once("lib/sanitize.php");
                        $newname = sanitize(httppost('newname'));
                        $newname = str_replace(chr(1),"`",$newname);
                        set_module_objpref("city",$cityid,$var,$newname);
						require_once("lib/nltoappon.php");
                        $newname = stripslashes(nltoappon($newname));
                        output("`2The placard message has been changed to:`n$newname");
                    }
                break;
				
				case "change":
					$msg="New applicants for citizenship are now disabled";
					if($var==1) $msg="New applications for citizenship are now enabled";
					output($msg);
					set_module_objpref("city",$cityid,$var,"newcits");				
				break;
                
				case "change":
                    $new = httppost('new');
                    if($new!=""){
                        $new = stripslashes(str_replace("`n", "", $new));
                        $what=get_module_objpref("city",$cityid,$var);
                        set_module_objpref("city",$cityid,$var,$new);
						output("`2%s`0 will now be called %s`2.",$what,$new);

                    }else{
                        $submit=translate_inline("Submit");
                        rawoutput("<form action='runmodule.php?module=cityleaders&op=chambers&sop=change&var=$var' method='POST'>");
                        addnav("","runmodule.php?module=cityleaders&op=chambers&sop=change&var=$var");
                        $old=get_module_objpref("city",$cityid,$var);
                        output($old);
                        rawoutput("<input name='new' id='new' value='".$old."' size='40' maxlength='255'><br>");
                        rawoutput("<input type='submit' class='button' value='$submit'><br>");
                        rawoutput("</form>");
                    }                
                break;
            }

        break;
        
        case "uk":
			output("You have entered a large auditorium of sorts.  Large paintings of doves with branches in their beaks decorate the walls.");
			output("  There are lots of other leaders from all around the kingdom here.  Discussions have already begun about diplomacy, kingdom peace, exchange rates, and about global farmboy poverty.`n`n");
			$from=httpget('from');
            page_header("The United Kingdoms");
			if($from=="")addnav("Back to your chambers","runmodule.php?module=cityleaders&op=chambers");
			else addnav("Back to the Grotto","superuser.php");
			if($from=="grotto")blocknav("runmodule.php?module=cityleaders");
			require_once("lib/commentary.php");
            addcommentary();
            viewcommentary("The-UK","Many leaders express their ideas here", 15, "diplomatically says"); 
		break;
        case "apply":
            switch($sop){
                case "":
                    output("If you chose to call %s home, you will be abandoning your current allegiance to %s.",$session['user']['location'],get_module_pref("homecity","cities"));
					addnav(array("Pledge allegiance to %s",$session['user']['location']),"runmodule.php?module=cityleaders&op=apply&sop=2");				
				break;
				
                case "2":
                    output("%s welcomes you.",$session['user']['location']);
					addnews("%s has pledged allegiance to %s!  They have abandoned their citizenship to %s!",$session['user']['name'],$session['user']['location'],get_module_pref("homecity","cities"));
					set_module_pref("homecity",$session['user']['location'],"cities");
					set_module_pref("run",0);
					set_module_pref("banner","");
				break;            
            }
        break;
        
        case "election":
            switch($sop){
                case "ask":
					if(get_module_pref("voted")){
						output("I know it only takes one to lead a revolution, but your desire for a revolt has already been noted.");
					}else{
						output("If you the majority of the population in this city call for an election, the current leader will be ousted and a new leader can be elected.");
						output("`n`nAre you sure you want to contribute to the revolt?");
						addnav("Navigation");
						addnav("Yes","runmodule.php?module=cityleaders&op=election&sop=yes");
					}
                break;
                
                case "yes":
                    $votes=get_module_objpref("city",$cityid,"votes")+1;
                    set_module_objpref("city",$cityid,"votes",$votes);
					set_module_pref("voted",1);
                    $sql="select value from ".db_prefix("module_userprefs")." where value='".$session['user']['location']."' and setting='homecity' and modulename='cities'";
                    $res=db_query($sql);
                    $c=db_num_rows($res);
                    if((round($c/$votes)>=get_module_setting("anarchy"))){
                        set_module_objpref("city",$cityid,"status",2);
                        set_module_objpref("city",$cityid,"votes",0);
                        output("You have begun the revolt!  New potential leaders may now enter their interest in being elected!");
                    }else{
                        output("Your request to have a new election has been noted.  %s votes are still needed.",round($c*get_module_setting("anarchy")/100));
                    }
                break;
                
                case "run":
                    $gold=get_module_setting("goldcost");
                    $gems=get_module_setting("gemscost");
                    if($session['user']['gold']<$gold || $session['user']['gems']<$gems){
                        output("You will need %s gold and %s gems in order to run for office.",$gold, $gems);
                    }else{
                        $session['user']['gold']-=$gold;
                        $session['user']['gems']-=$gems;
                        set_module_pref("run",true);
                        output("Your interest in running for the leader has been noted.  If you would like to buy a banner, you can do so with the option to your left.");
                        addnav("Buy a banner","runmodule.php?module=cityleaders&op=election&sop=banner");
                    }
                break;
                
                case "banner":
                    $newname = httppost('newname');
                    if($newname==""){
                        output("`n`n`2What would you like to change your campaign message to? (max. 255 characters including color codes)`n");
                        rawoutput("<form action='runmodule.php?module=cityleaders&op=election&sop=banner' method='POST' autocomplete='false'>");
                        addnav("","runmodule.php?module=cityleaders&op=election&sop=banner");
                        $header = get_module_pref("banner");
                        rawoutput("<textarea name='newname' cols=50 rows=5>$header</textarea><br>");
                        rawoutput("<input type='submit' class='button' value='$submit'><br>");
                        rawoutput("<div id='previewtext'></div></form>");
                    }else{
                        //require_once("lib/sanitize.php");
                        //$newname = sanitize(httppost('newname'));
                        //$newname = str_replace(chr(1),"`",$newname);
                        set_module_pref("banner",$newname);
                        $newname = stripslashes($newname);
                        output("`2Your campaign message has been changed to:`n$newname");
                    }
                break;
               
                case "vote":
                    addnav("Vote for...");
                    $sql="select userid from ".db_prefix("module_userprefs")." where modulename='cityleaders' and setting='run' and value=1";
                    $res=db_query($sql);
                    output("Outside the voting booths, you can see all the candidates banners, trying to get that last drop of political propaganda.`n`n");
                    for($i=0;$i<db_num_rows($res);$i++){
                        $row=db_fetch_assoc($res);
                        if(get_module_pref("homecity","cities",$row['userid'])==$session['user']['location']){
                            $sql2="select name from ".db_prefix("accounts")." where acctid=".$row['userid']."";
                            $res2=db_query($sql2);                            
                            $row2=db_fetch_assoc($res2);
                            addnav(array("%s",$row2['name']),"runmodule.php?module=cityleaders&op=election&sop=vote2&who={$row['userid']}");
                            output("%s - `#\"`@%s`#\"`n",$row2['name'],get_module_pref("banner","cityleaders",$row['userid']));
                        }
                    }
                break;
                
                case "vote2";
                    $who=httpget('who');
					$cvotes=get_module_pref("votes","cityleaders",$who);
                    set_module_pref("votes",$cvotes+1,"cityleaders",$who);
                    set_module_pref("voted",1);
                    output("Your vote has been entered.  Now you must wait until the voting period is over and a new leader is elected!");
                break;
            }
		break;
		
        case "council":
            page_header("%s Discussion",sanitize($cityhall));
            require_once("lib/commentary.php");
            addcommentary();
            viewcommentary("cityhall-".$cityid,"Many people express their ideas here", 15, "says"); 
		break;

		case "":
            modulehook("cityleaders",array(status=>$status));
            $t=stripslashes(get_module_objpref("city",$cityid,"cheader"));
            output("`n`c%s`c`n`0",$t);
			$homecity=get_module_pref("homecity","cities");
            if($homecity!=$session['user']['location'] && get_module_objpref("city",$cityid,"newcits")) addnav("Apply for citizenship","runmodule.php?module=cityleaders&op=apply");
            if($session['user']['acctid']==$leader){
                addnav("Navigation");
                addnav("Leader Chambers","runmodule.php?module=cityleaders&op=chambers");
            }
            if($status==1 && $homecity==$session['user']['location']){
                addnav("Options");
                addnav("Ask for an election","runmodule.php?module=cityleaders&op=election&sop=ask");                
            }
            if($status==2 && $homecity==$session['user']['location']){
                addnav("Options");
                if(get_module_pref("run")){
                   addnav("Buy or edit banner","runmodule.php?module=cityleaders&op=election&sop=banner");
                }else{
                   addnav("Run for leader","runmodule.php?module=cityleaders&op=election&sop=run");
                }
            }
            if($status==3 && $homecity==$session['user']['location']){
                addnav("Options");
                if(get_module_pref("voted")==0) addnav("Vote","runmodule.php?module=cityleaders&op=election&sop=vote");
            }
            addnav("Navigation");
            addnav("Center council","runmodule.php?module=cityleaders&op=council");
            $start=strtotime(get_module_objpref("city",$cityid,"date"));
            $length="clength";
            if($status==3) $length="vlength";
            if($status==1 && get_module_setting("term")) $length="tlength";
            $end = strtotime(get_module_setting($length), $start);
            $tl=cityleaders_timeleft(time(), $end);
            if($status==3 && get_module_pref("voted")==0 && get_module_pref("homecity","cities")==$session['user']['location']) output("`nYou have %s left to vote.`n",$tl);
            elseif($status==2) output("`nThe Voting booths will open in %s.`n",$tl);
            elseif($status==1 && get_module_setting("term")) output("`nThere will be a new election in %s.`n",$tl);
        break;
    }
    page_footer();
}
function cityleaders_inaugurate($cityid){
    $cityid=$cityid;        
    set_module_objpref("city",$cityid,"status",1);
    $sql="select userid from ".db_prefix("module_userprefs")." where modulename='cityleaders' and setting='votes' and value>0 order by value ASC";
    $res=db_query($sql);
    for($i=0;$i<db_num_rows($res);$i++){
        $row=db_fetch_assoc($res);
        if(get_module_pref("homecity","cities",$row['userid'])==get_cityprefs_cityname("cityid",$cityid)){
            set_module_pref("banner","","cityleaders",$row['userid']);
            if(($i+1)==db_num_rows($res)){//new leader
				set_module_objpref("city",$cityid,"leader",$row['userid']);
				require_once("lib/systemmail.php");
				$msg=translate_inline("You have been elected the new leader of %s!");
				$sub=translate_inline("`2You have been elected!`2");
				systemmail($row['userid'],$sub,array($msg,get_module_pref("homecity","cities",$row['userid'])));
				$sql1="select name from ".db_prefix("accounts")." where acctid=".$row['userid'];
				$res1=db_query($sql1);
				$row1=db_fetch_assoc($res1);
				addnews("%s has been elected as the new leader of %s!",$row1['name'],get_module_pref("homecity","cities",$row['userid']));
			}
            set_module_pref("votes",0,"cityleaders",$row['userid']);
            set_module_pref("run",0,"cityleaders",$row['userid']);
			}   
    }
    $sql2="select userid from ".db_prefix("module_userprefs")." where modulename='cityleaders' and setting='voted' and value>0";
    $res2=db_query($sql2);
    for($i=0;$i<db_num_rows($res2);$i++){
        $row2=db_fetch_assoc($res2);
        if(get_module_pref("homecity","cities",$row2['userid'])==get_cityprefs_cityname("cityid",$cityid)){
            set_module_pref("voted",0,"cityleaders",$row2['userid']);
        }
    }
}

function cityleaders_timeleft($start,$end){
	$x = abs($end - $start);
	$d = (int)($x/86400);
	$x = $x % 86400;
	$h = (int)($x/3600);
	$x = $x % 3600;
	$m = (int)($x/60);
	$x = $x % 60;
	$s = (int)($x);
	if ($d > 0)
		$o = "$d day".($d>1?"s":"").($h>0?", $h hour".($h>1?"s":""):"");
	elseif ($h > 0)
		$o = "$h hour".($h>1?"s":"").($m>0?", $m minute".($m>1?"s":""):"");
	elseif ($m > 0)
		$o = "$m minute".($m>1?"s":"").($s>0?", $s second".($s>1?"s":""):"");
	else
		$o = $s." second".($s>0?"s":"");		
	return $o;
}
?>