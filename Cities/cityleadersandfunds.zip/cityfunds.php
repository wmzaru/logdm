<?php
/*YOU MUST REPORT ALL MODIFICATIONS TO THIS FILE ***IMMEDIATELY*** to dragonprime.  You are violating the license by not releasing modifications to this file.
post changes you've made, working or not working to:
*/
function cityfunds_getmoduleinfo(){
	$info = array(
		"name"=>"City Funds",
		"version"=>"20070207",
		"author"=>"Sixf00t4",
		"category"=>"Cities",
		"download"=>"http://dragonprime.net/index.php?topic=6316.0",
		"prefs-city"=>array(
			"City funds Preferences,title",
			"tax"=>"What is the tax rate?,int|0",
			"gold"=>"How much gold does this city have?,int|0",
			"gems"=>"How many gems does this city have?,int|0",
		),
		"requires"=>array(
			"cityleaders"=>"20060210|By Sixf00t4, Not Available",
		),
	);
	return $info;
}

function cityfunds_install(){
	module_addhook("cityleaders-leader");
	module_addhook("newday");
	module_addhook("footer-hof");
	module_addhook("cityleaders");
	return true;
}

function cityfunds_uninstall(){
	return true;
}
function cityfunds_dohook($hookname,$args){
	global $session;
	switch ($hookname) {
		case "cityleaders":
			addnav("Options");
			addnav("Donate funds","runmodule.php?module=cityfunds&op=donate");		
		break;
		case "newday":
			require_once("modules/cityprefs/lib.php");
			$cityid=get_cityprefs_cityid("location",get_module_pref("homecity","cities"));
			$tax=get_module_objpref("city",$cityid,"tax","cityfunds");
			$leader=get_module_objpref("city",$cityid,"title","cityleaders");
			if($tax>0 && $tax<101){
				$amt=round(($session['user']['gold']+$session['user']['goldinbank'])*0.01*$tax);
				$bank=$session['user']['goldinbank'];
				if($bank>=$amt){
					$session['user']['goldinbank']-=$amt;
				}else{
					$session['user']['goldinbank']=0;
					$amtl=$amt-$bank;
					$session['user']['gold']-=$amtl;
				}
				set_module_objpref("city",$cityid,"gold",get_module_objpref("city",$cityid,"gold","cityfunds")+$amt,"cityfunds");
				output("`n`nThe %s of your city has set the tax at %s percent of your gold.`n",$leader,$tax);
				output("You gladly pay %s to the advancement and protection of your home city.",$amt);
			}
		break;
		case "cityleaders-leader":
			addnav("Options");
			addnav("City funds","runmodule.php?module=cityfunds&op=funds");		
		break;
		case "footer-hof":
			addnav("Cities");
			addnav("Richest Cities", "runmodule.php?module=cityfunds&op=hof");	
		break;	
	}
	return $args;
}
function cityfunds_run(){
	global $session;
	$op = httpget('op');
	require_once("modules/cityprefs/lib.php");
	$cityid=get_cityprefs_cityid("cityname",$session['user']['location']);
	$leader=get_module_objpref("city",$cityid,"title","cityleaders");
	$citizens=get_module_objpref("city",$cityid,"citizens","cityleaders");
	$cityhall=get_module_objpref("city",$cityid,"cityhall","cityleaders");
	page_header("City Funds");
	addnav("Navigation");
	if($op!="hof") addnav(array("Return to %s",$cityhall),"runmodule.php?module=cityleaders");
	villagenav();
	if($op=="donate"){
		output("Cities need gold and gems to maintain the city walls, army, economy, and the %s`0's fairy dust addiction.`n`n",$leader);
		output("Would you like to donate gold or gems?");
		addnav("Options");
		addnav("Donate Gold","runmodule.php?module=cityfunds&op=donate1&g=gold");
		addnav("Donate Gems","runmodule.php?module=cityfunds&op=donate1&g=gems");
	}
	elseif($op=="funds"){
		addnav("Manage");
		modulehook("cityfunds");
		addnav("Tax rate","runmodule.php?module=cityfunds&op=tax");
		output("Here you can see who donated to the betterment of your city and manage your city funds.`n");
		output("The city currently has %s gold and %s gems available.`n`n",get_module_objpref("city",$cityid,"gold","cityfunds"),get_module_objpref("city",$cityid,"gems","cityfunds"));
		require_once ("lib/commentary.php");
		addcommentary();
		viewcommentary("cityfunds-".$cityid,"A log of donations is kept here", 25, "says"); 
	}
	elseif ($op=="tax") {
		output("What do you want to set the tax rate to?`n`n");
		rawoutput("<form action='runmodule.php?module=cityfunds&op=tax2' method='POST'>");
		$donate=translate_inline("Donate");
		rawoutput("<input name='rate' id='rate' value='".htmlentities(get_module_objpref("city",$cityid,"tax"))."'><input type='submit' class='button' value=$donate></form>");
		addnav("","runmodule.php?module=cityfunds&op=tax2");
	}
	elseif ($op=="tax2") {
		$rate = httppost('rate');
		output("The tax rate has been set to %s percent of gold in bank and gold in hand.",$rate);
		set_module_objpref("city",$cityid,"tax",$rate);
	}
	elseif ($op=="donate1") {
		$g=httpget('g');
		output("What are you willing to donate?`n`n");
		rawoutput("<form action='runmodule.php?module=cityfunds&op=donate2&g=$g' method='POST'>");
		$donate=translate_inline("Donate");
		rawoutput("<input name='donate' id='donate'><input type='submit' class='button' value=$donate></form>");
		addnav("","runmodule.php?module=cityfunds&op=donate2&g=$g");
	}
	elseif ($op=="donate2"){
		$g=httpget('g');
		$donate = httppost('donate');
		$max = $session['user'][$g];
		if ($donate < 0) $donate = 0;
		if ($donate >= $max) $donate = ($max);
		if ($max < $donate) {
			output("You don't have enough %s to make that donation!",$g);
		}else{
			set_module_objpref("city",$cityid,$g,get_module_objpref("city",$cityid,$g)+$donate);
			output("The %s and the %s of %s thank you for your donation.",$leader,$citizens,$session['user']['location']);
			$session['user'][$g]-=$donate;
			debuglog("donated $donate $g to ".$session['user']['location']."");
			$message = sprintf_translate("::donated `4%s %s%s`&.", $donate, $g=="gems"?"`%":"`^", translate_inline($g));
			require_once("lib/commentary.php");
			injectrawcomment("cityfunds-$cityid", $session['user']['acctid'], $message);
			}
	}
	elseif ($op == "hof") {
		page_header("Hall of Fame");
		$sql = "SELECT objid FROM " . db_prefix("module_objprefs") . " WHERE objtype='city' and modulename = 'cityfunds' AND setting = 'gold' AND value > 0 order by value Desc";
		$result = db_query($sql);
		$row = db_fetch_assoc($result);
		$result = db_query($sql);
		$rank=translate_inline("Rank");
		$city=translate_inline("City");
		rawoutput("<table border='0' cellpadding='2' cellspacing='1' align='center' bgcolor='#999999'>");
		rawoutput("<tr class='trhead'><td>$rank</td><td align='center'>$city</td></tr>");
		for($i=0;$i<db_num_rows($result);$i++){
			$row = db_fetch_assoc($result);
			rawoutput("<tr class='".($i%2?"trdark":"trlight")."'><td>");
			$j=$i+1;
			$cityn=get_cityprefs_cityname("cityid",$row['objid']);
			rawoutput("$j.</td><td align='center'>$cityn</td></tr>");
		}
		rawoutput("</table>");
		addnav("Other");
		addnav("Back to HoF", "hof.php");
	}
	page_footer();
}
?>