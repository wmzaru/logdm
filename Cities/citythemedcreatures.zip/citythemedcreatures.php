<?php
/**
	Modified by MarcTheSlayer

	12/03/2016 - v20160312
	+ Rewrote the sql query to try and fix a problem Rayn's having.
*/

function citythemedcreatures_getmoduleinfo(){
    $info = array(
        "name"=>"City Themed Creatures",
        "version"=>"20160312",
        "author"=>"<a href='http://www.joshuadhall.com'>Sixf00t4</a>, modified by `@MarcTheSlayer",
        "category"=>"Forest",
        "vertxtloc"=>"http://www.legendofsix.com/",
        "description"=>"Allows creatures to only appear in certain forests",
        "download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=1189",        
        "settings"=>array(
			"usestats"=>"Use unbuffed creature hp/atk/def?,bool|0",
		), 
        "prefs"=>array(
			"lastloc"=>"Where was the player last?,text|Degolburg",
		), 
		"prefs-creatures"=>array(
			"creatureanywhere"=>"Is this creature available in every forest?,bool|1",
			"usestats"=>"Use unbuffed creature hp/atk/def?,bool|0",
            "creatureloc"=>"Where does this creature appear?,location|".getsetting("villagename", LOCATION_FIELDS)
		),    
	);
        return $info;
}

function citythemedcreatures_install(){
    module_addhook("buffbadguy"); 
    module_addhook("village");    
    return true;
}

function citythemedcreatures_uninstall() {
	return true;
}

function citythemedcreatures_dohook($hookname,$args) {
	global $session;

	switch ($hookname) {

        case "village":
            set_module_pref("lastloc",$session['user']['location'],"citythemedcreatures");
        break;
      
        case "buffbadguy":
			if(!get_module_objpref("creatures",$args['creatureid'],"creatureanywhere")
			&& (!get_module_objpref("creatures",$args['creatureid'],"creatureloc")!=
				get_module_pref("lastloc")))
			{
				/**
				$creatures = db_prefix("creatures");
				$module_objprefs = db_prefix("module_objprefs");
				$sql = "SELECT $creatures.creatureid as id, $module_objprefs.objid
						FROM $module_objprefs INNER JOIN $creatures 
							ON $creatures.creatureid = $module_objprefs.objid
						WHERE $module_objprefs.setting = 'creatureloc'
							AND $creatures.creaturelevel = ".$args['creaturelevel']."
							AND $module_objprefs.value = '".get_module_pref("lastloc")."'
							AND $creatures.forest=1
						ORDER BY rand(".e_rand().")";
				$result = db_query($sql) or die(db_error(LINK)); 
				$badguy = array();
				for ($i=0;$i<db_num_rows($result);$i++)
				{    
					$row=db_fetch_assoc($result);
					if(get_module_objpref("creatures",$row['id'],"creatureanywhere")==0)
					{
						$sql2="select * from ".db_prefix("creatures")." where creatureid=".$row['id'];
						$result2=db_query($sql2);
						$badguy=db_fetch_assoc($result2);
						if(get_module_setting("usestats") || get_module_objpref("creatures",$badguy['creatureid'],"usestats"))
						{
							$args=$badguy;
						}
						else
						{
							$args['creaturename']=$badguy['creaturename'];
							$args['creatureweapon']=$badguy['creatureweapon'];
							$args['creaturewin']=$badguy['creaturewin'];
							$args['creaturelose']=$badguy['creaturelose'];
							}
						$i=db_num_rows($result);
					}				
				}
				**/

				$creatures = db_prefix('creatures');
				$objprefs = db_prefix('module_objprefs');
				$sql = "SELECT $creatures.creatureid as id
						FROM $creatures
						INNER JOIN $objprefs
							ON $creatures.creatureid = $objprefs.objid
						WHERE $objprefs.setting = 'creatureloc'
							AND $objprefs.value = '" . get_module_pref('lastloc') . "'
							AND $creatures.creaturelevel = " . $args['creaturelevel'] . "
							AND $creatures.forest = 1"; // ORDER BY RAND() is bad apparently so dump to array and shuffle. :)
				$result = db_query($sql);
				$id_array = array();
				while( $row = db_fetch_assoc($result) ) $id_array[] = $row['id'];
				shuffle($id_array); // Randomise the order.
				foreach( $id_array as $id )
				{
					$sql = "SELECT *
							FROM " . db_prefix('creatures') . "
							WHERE creatureid = " . $id;
					$result = db_query($sql);
					$badguy = db_fetch_assoc($result);
					if( get_module_setting('usestats') || get_module_objpref('creatures',$badguy['creatureid'],'usestats') )
					{
						debug("Replacing fully: {$args['creaturename']} with {$badguy['creaturename']}. Module: citythemedcreatures.php");
						$args = $badguy;
					}
					else
					{
						debug("Replacing partial: {$args['creaturename']} with {$badguy['creaturename']}. Module: citythemedcreatures.php");
						$args['creaturename'] = $badguy['creaturename'];
						$args['creatureweapon'] = $badguy['creatureweapon'];
						$args['creaturewin'] = $badguy['creaturewin'];
						$args['creaturelose'] = $badguy['creaturelose'];
						$args['creatureaiscript'] = $badguy['creatureaiscript']; // Do AI script code as well.
					}
				}
			}
        break;      
	}
	return $args;
}

function citythemedcreatures_run(){}
?>