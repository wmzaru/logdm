<?php
function comedit_getmoduleinfo(){
	$info = array(
		"name"=>"Commentary Editor",
		"version"=>"1.2",
		"author"=>"`@KaosKaizer",
		"category"=>"Commentary",
		"override_forced_nav"=>TRUE,
		"description"=>"Allows staff with SU_EDIT_COMMENTS can go in and edit comment texts. `QFor use with popup links in commentary.",
		"settings"=>array(
			"Commentary Editor Settings,title",
			"recent"=>"Number of comments to show in most recent:,int|30",
			"persec"=>"Number of comments to display per section:,int|50",
			"cmjcom"=>"Is CMJ's commentary system installed?,bool|",
			"`^This is so the code can be able to accurately switch over names on posts as well.,note",
			"`\$WARNING! DO NOT SET THIS TO YES IF YOU HAVE NOT INSTALLED IT!`0,note",
			"`#Flags that can edit comments:`n`6(only one flag condition has to be met...),note",
			"SU_MEGAUSER"=>"Megausers,bool|1",
			"SU_EDIT_COMMENTS"=>"Comment moderators,bool|1",
			"SU_EDIT_USERS"=>"User editors,bool|",
			"SU_EDIT_CONFIG"=>"Edit game settings,bool|",
			"SU_DEVELOPER"=>"Developers,bool|",
			"SU_MANAGE_MODULES"=>"Module Managers,bool|",
			"SU_AUDIT_MODERATION"=>"Can audit moderated comments,bool|1",
			"SU_RAW_SQL"=>"Can run raw SQL/PHP. Included because if done right&#44; they can change commentary too.,bool|1",
			"SU_IS_GAMEMASTER"=>"Gamemasters... can post anonymous comments basically.,bool|",
		),
		"prefs"=>array(
			"pro"=>"Is this user prohibited from editing comment texts?,bool|",
		),
	);
	return $info;
}

function comedit_install(){
	module_addhook("superuser");
	module_addhook("village");
	return true;
}

function comedit_uninstall(){
	return true;
}

function comedit_dohook($hook,$args){
	global $session;
	switch($hook){
		case "superuser":
				addnav("Actions");
				comedit_check();
		break;
		case "village":
				addnav("Superuser");
				comedit_check();
		break;
	}
	return $args;
}

function comedit_run(){
	global $session;
	$op = httpget('op');
	if ($op == "editpop" || $op == "savepop"){
		popup_header("Commentary Editor");
		$id = httpget('id');
		if ($op == "savepop"){
			$comment = httppost('comment');
			$author = httppost('author');
			$section = httppost('section');
			$reason = httppost('reason');
				$oldcomment = httppost('oldcomment');
				$oldsection = httppost('oldsection');
				$date = httppost('date');
			$allow = 1;
			if ($reason == ""){
				$allow = 0;
				output("`\$I'm sorry, but you have to insert a reason to edit comments.`0`n");
			}
			if ($section == ""){
				$allow = 0;
				output("`\$I'm sorry, but you have to insert a section to edit comments.`0`n");
			}
			if ($allow){
				// Let's first send the mail...
				require_once("lib/systemmail.php");
				$row = db_fetch_assoc(db_query("SELECT name FROM ".db_prefix("accounts")." WHERE acctid=$author"));
				$name = $row['name'];
				$yom_body = "`QDear ".$row['name']."`Q,`n".$session['user']['name']."`Q has edited one of your comments for the following reason:`n";
					$yom_body .= "`^".$reason."`Q`n`n";
					$yom_body .= "If you wish to dispute this edit for the above reason, then please YOM your head admin with a copy of the reason, the comment, and the altered comment.`n`n";
					$yom_body .= "The comment changed was:`n";
					$yom_body .= "Where: `^".$oldsection." `Qon `^".$date."`Q`n";
					$yom_body .= "Original Comment: `@".$oldcomment."`Q`n";
					$yom_body .= "New comment(where: `^".$section."`Q): `@".$comment."`Q`n`n";
					$yom_body .= "This is an automated message. If you have any inquiries, please direct them to your head administrator.";
				systemmail($author,"Comment Canged",$yom_body);
				
				// Now, let's change the comment in the database.
				if (get_module_setting("cmjcom") == 0)
					$sql = "UPDATE ".db_prefix("commentary")." SET comment='".$comment."', author=".$author.", section='".$section."' WHERE commentid=$id";
				else
					$sql = "UPDATE ".db_prefix("commentary")." SET comment='".$comment."', author=".$author.", section='".$section."', name='".$name."' WHERE commentid=$id";
				db_query($sql);
				output("Comment updated.`n`n");
			}
		}
		$res = db_query("SELECT comment,author,section,postdate FROM ".db_prefix("commentary")." WHERE commentid=$id");
		$row = db_fetch_assoc($res);
		$c = appoencode("`@");
		output("`%Edit:`n");
		rawoutput("<form action='runmodule.php?module=comedit&op=savepop&id=$id' method='POST'>");
			addnav("","runmodule.php?module=comedit&op=savepop&id=$id");
		rawoutput("$c Author: <input type='text' size=4 name='author' value='".$row['author']."'><br>");
		rawoutput("$c Section: <input type='text' size=20 name='section' value='".$row['section']."'><br>");
		rawoutput("$c Reason: <input type='text' size=20 name='reason' value=''><br>");
		rawoutput("$c Comment: <textarea rows=3 cols=25 name='comment'>".$row['comment']."</textarea><br>");
			rawoutput("<input type='hidden' name='oldcomment' value='".$row['comment']."'>");
			rawoutput("<input type='hidden' name='date' value='".$row['postdate']."'>");
			rawoutput("<input type='hidden' name='oldsection' value='".$row['section']."'>");
		rawoutput("<input type='submit' value='Save'>");
		popup_footer();
	}else{
		page_header("Commentary Editor");
		comedit_check(false);
		
		addnav("Navigation");
		addnav("Grotto","superuser.php");
		addnav("Mundane","village.php");
		addnav("Sections");
		addnav("Most Recent","runmodule.php?module=comedit&op=enter");
			$r = "runmodule.php?module=comedit&op=browse&sec=";
		// do it this way so it only lists those areas with comments.
		$secs = comedit_sections();
		foreach ($secs as $key){
			addnav(array("%s",$key),$r."".$key);
		}
		
		if ($op == "enter"){
			// Intro
			$limit = get_module_setting("recent");
			output("`%Welcome! For quick edits, we have a list of the %s most recent comments and what sections they were made in. Or you can browse by section.`n",$limit);
			output("`n`c________________________________________________________________________________________`c`n`n");
			// Most Recent Comments
			$limit = get_module_setting("recent");
			$sql = "SELECT commentid,author,postdate,comment,section FROM ".db_prefix("commentary")." ORDER BY postdate DESC LIMIT $limit";
			$res = db_query($sql);
			while ($row = db_fetch_assoc($res)){
				$sql = "SELECT name FROM ".db_prefix("accounts")." WHERE acctid=".$row['author'];
				$r = db_fetch_assoc(db_query($sql));
				rawoutput("<a href='runmodule.php?module=comedit&op=edit&id={$row['commentid']}'>Edit</a> ");
					addnav("","runmodule.php?module=comedit&op=edit&id=".$row['commentid']);
				output("`@comment by `^%s`@ on `^%s`@ in the `^%s`@.`n",$r['name'],$row['postdate'],$row['section']);
				output("`#%s`0`n`n",$row['comment']);
			}
		}
		
		if ($op == "browse"){
			$sec = httpget('sec');
			$limit = get_module_setting("persec");
			$sql = "SELECT commentid,author,postdate,comment,section FROM ".db_prefix("commentary")." WHERE section='".$sec."' ORDER BY postdate DESC LIMIT $limit";
			$res = db_query($sql);
			while ($row = db_fetch_assoc($res)){
				$sql = "SELECT name FROM ".db_prefix("accounts")." WHERE acctid=".$row['author'];
				$r = db_fetch_assoc(db_query($sql));
				rawoutput("<a href='runmodule.php?module=comedit&op=edit&id={$row['commentid']}'>Edit</a> ");
					addnav("","runmodule.php?module=comedit&op=edit&id=".$row['commentid']);
				output("`@comment by `^%s`@ on `^%s`@ in the `^%s`@.`n",$r['name'],$row['postdate'],$row['section']);
				output("`#%s`0`n`n",$row['comment']);
			}
		}
		
		if ($op == "edit"){
			$id = httpget('id');
			$sql = "SELECT comment,author,section,postdate FROM ".db_prefix("commentary")." WHERE commentid=$id";
			$res = db_query($sql);
			$row = db_fetch_assoc($res);
			$c = appoencode("`@");
			output("`%Edit:`n");
			rawoutput("<form action='runmodule.php?module=comedit&op=save&id=$id' method='POST'>");
				addnav("","runmodule.php?module=comedit&op=save&id=$id");
			rawoutput("$c Author: <input type='text' size=4 name='author' value='".$row['author']."'><br>");
			rawoutput("$c Section: <input type='text' size=20 name='section' value='".$row['section']."'><br>");
			rawoutput("$c Reason: <input type='text' size=20 name='reason' value=''><br>");
			rawoutput("$c Comment: <textarea rows=3 cols=25 name='comment'>".$row['comment']."</textarea><br>");
				rawoutput("<input type='hidden' name='oldcomment' value='".$row['comment']."'>");
				rawoutput("<input type='hidden' name='date' value='".$row['postdate']."'>");
				rawoutput("<input type='hidden' name='oldsection' value='".$row['section']."'>");
			rawoutput("<input type='submit' value='Save'>");
		}
		
		if ($op == "save"){
			$id = httpget('id');
			$comment = httppost('comment');
			$author = httppost('author');
			$section = httppost('section');
			$reason = httppost('reason');
				$oldcomment = httppost('oldcomment');
				$oldsection = httppost('oldsection');
				$date = httppost('date');
			$allow = 1;
			if ($reason == ""){
				$allow = 0;
				output("`\$I'm sorry, but you have to insert a reason to edit comments.`0`n");
			}
			if ($section == ""){
				$allow = 0;
				output("`\$I'm sorry, but you have to insert a section to edit comments.`0`n");
			}
			if ($allow == 1){
				// Let's first send the mail...
				require_once("lib/systemmail.php");
				$row = db_fetch_assoc(db_query("SELECT name FROM ".db_prefix("accounts")." WHERE acctid=$author"));
				$name = $row['name'];
				$yom_body = "`QDear ".$row['name']."`Q,`n".$session['user']['name']."`Q has edited one of your comments for the following reason:`n";
					$yom_body .= "`^".$reason."`Q`n`n";
					$yom_body .= "If you wish to dispute this edit for the above reason, then please YOM your head admin with a copy of the reason, the comment, and the altered comment.`n`n";
					$yom_body .= "The comment changed was:`n";
					$yom_body .= "Where: `^".$oldsection." `Qon `^".$date."`Q`n";
					$yom_body .= "Original Comment: `@".$oldcomment."`Q`n";
					$yom_body .= "New comment(where: `^".$section."`Q): `@".$comment."`Q`n`n";
					$yom_body .= "This is an automated message. If you have any inquiries, please direct them to your head administrator.";
				$yom_who = $author;
				$yom_subj = "Comment Changed";
				systemmail($yom_who,$yom_subj,$yom_body);
				
				// Now, let's change the comment in the database.
				if (get_module_setting("cmjcom") == 0)
					$sql = "UPDATE ".db_prefix("commentary")." SET comment='".$comment."', author=".$author.", section='".$section."' WHERE commentid=$id";
				else
					$sql = "UPDATE ".db_prefix("commentary")." SET comment='".$comment."', author=".$author.", section='".$section."', name='".$name."' WHERE commentid=$id";
				db_query($sql);
				output("Comment updated.");
			}
		}
		page_footer();
	}
}

function comedit_sections(){
	$sql = "SELECT section FROM ".db_prefix("commentary");
	$res = db_query($sql);
	$secs = array();
	while ($row = db_fetch_assoc($res)){
		$section = $row['section'];
		if (!isset($secs[$section])){
			$secs[$section] = $section;
		}
	}
	return $secs;
}

function comedit_check($navs=true){
	global $session;
	$g = get_all_module_settings("comedit");
	$allow = 0;
	if ($g['SU_MEGAUSER'] == 1 && $session['user']['superuser'] & SU_MEGAUSER) $allow = 1;
	if ($g['SU_EDIT_COMMENTS'] == 1 && $session['user']['superuser'] & SU_EDIT_COMMENTS) $allow = 1;
	if ($g['SU_EDIT_USERS'] == 1 && $session['user']['superuser'] & SU_EDIT_USERS) $allow = 1;
	if ($g['SU_EDIT_CONFIG'] == 1 && $session['user']['superuser'] & SU_EDIT_CONFIG) $allow = 1;
	if ($g['SU_DEVELOPER'] == 1 && $session['user']['superuser'] & SU_DEVELOPER) $allow = 1;
	if ($g['SU_MANAGE_MODULES'] == 1 && $session['user']['superuser'] & SU_MANAGE_MODULES) $allow = 1;
	if ($g['SU_AUDIT_MODERATION'] == 1 && $session['user']['superuser'] & SU_AUDIT_MODERATION) $allow = 1;
	if ($g['SU_RAW_SQL'] == 1 && $session['user']['superuser'] & SU_RAW_SQL) $allow = 1;
	if ($g['SU_IS_GAMEMASTER'] == 1 && $session['user']['superuser'] & SU_IS_GAMEMASTER) $allow = 1;
	if (get_module_pref("pro") == 1) $allow = false;
	if ($navs === true && $allow == 1){
		addnav("Edit Commentary","runmodule.php?module=comedit&op=enter");
	}
	if ($navs === false){
		if ($allow == 0) redirect("village");
	}
}